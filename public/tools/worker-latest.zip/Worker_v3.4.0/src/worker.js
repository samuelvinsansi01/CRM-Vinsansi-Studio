import 'dotenv/config';
import { createServer } from 'node:http';
import { createHash, randomUUID, timingSafeEqual } from 'node:crypto';
import { readFile, stat } from 'node:fs/promises';
import { basename, resolve, sep } from 'node:path';
import { createClient } from '@supabase/supabase-js';

const VERSION = '3.4.0';
const cfg = {
  supabaseUrl: textEnv('SUPABASE_URL'),
  serviceRoleKey: textEnv('SUPABASE_SERVICE_ROLE_KEY'),
  httpHost: textEnv('WORKER_HTTP_HOST', '0.0.0.0'),
  httpPort: positiveIntEnv('WORKER_HTTP_PORT', 8787),
  httpToken: textEnv('WORKER_HTTP_TOKEN'),
  imagesDir: resolve(textEnv('WORKER_IMAGES_DIR', '/app/images')),
  maxImageBytes: positiveIntEnv('MAX_IMAGE_BYTES', 15 * 1024 * 1024),
  delayBetweenMessagesMs: positiveOrZeroIntEnv('DELAY_BETWEEN_TEXT_MESSAGES_SECONDS', 10) * 1000,
  delayTextToImageMs: positiveOrZeroIntEnv('DELAY_TEXT_TO_IMAGE_SECONDS', 5) * 1000,
  requestTimeoutMs: positiveIntEnv('EVOLUTION_REQUEST_TIMEOUT_MS', 15000),
  validationDelayMs: positiveOrZeroIntEnv('WHATSAPP_VALIDATION_DELAY_MS', 250),
  validationMaxLeads: positiveIntEnv('WHATSAPP_VALIDATION_MAX_LEADS', 200),
  schedulerTickMs: Math.max(2000, positiveIntEnv('SCHEDULER_TICK_SECONDS', 5) * 1000),
  batchPauseMs: Math.max(60000, positiveIntEnv('BATCH_PAUSE_SECONDS', 3600) * 1000),
  instanceSyncIntervalMs: Math.max(15000, positiveIntEnv('EVOLUTION_INSTANCE_SYNC_SECONDS', 60) * 1000),
  staleExecutionMs: Math.max(60000, positiveIntEnv('WORKER_STALE_EXECUTION_SECONDS', 900) * 1000),
  recoveryIntervalMs: Math.max(30000, positiveIntEnv('WORKER_RECOVERY_INTERVAL_SECONDS', 60) * 1000),
  workerId: textEnv('WORKER_INSTANCE_ID', `worker-${process.pid}-${randomUUID()}`),
  dryRun: boolEnv('DRY_RUN', false),
};

if (!cfg.supabaseUrl || !cfg.serviceRoleKey) throw new Error('SUPABASE_URL e SUPABASE_SERVICE_ROLE_KEY sao obrigatorios.');
if (!cfg.httpToken && !['127.0.0.1','localhost','::1'].includes(cfg.httpHost)) throw new Error('WORKER_HTTP_TOKEN e obrigatorio fora do localhost.');
if (cfg.httpToken && cfg.httpToken.length < 32) throw new Error('WORKER_HTTP_TOKEN deve ter no minimo 32 caracteres.');

const supabase = createClient(cfg.supabaseUrl, cfg.serviceRoleKey, { auth: { persistSession: false, autoRefreshToken: false } });
const inFlight = new Set();
let statusCache = null;
let leadStatusCache = null;
let instanceSyncRunning = false;
let schedulerRunning = false;
let recoveryRunning = false;

const CATALOG = {
  channels: { WHATSAPP: 1, INSTAGRAM: 2 },
  status: { ACTIVE: 1, INACTIVE: 2, PENDING: 3, PROCESSING: 4, COMPLETED: 5, ERROR: 6, CANCELED: 7, PAUSED: 8 },
  leadStatus: { IMPORTED: 1, VALIDATED: 2, PRE_SEND: 3, QUEUED: 4, SENT: 5, INVALID: 6, DUPLICATE: 7, ARCHIVED: 8 },
};
const QUEUE_STATUS_IDS = {
  queued: CATALOG.status.PENDING,
  sending: CATALOG.status.PROCESSING,
  sent: CATALOG.status.COMPLETED,
  paused: CATALOG.status.PAUSED,
  error: CATALOG.status.ERROR,
  invalid: CATALOG.status.ERROR,
};

function textEnv(key, fallback = '') { const value = process.env[key]; return value == null ? fallback : String(value).trim(); }
function boolEnv(key, fallback = false) { const value = process.env[key]; return value == null || String(value).trim() === '' ? fallback : ['true','1','yes','sim','on'].includes(String(value).trim().toLowerCase()); }
function positiveIntEnv(key, fallback) { const value = Number(process.env[key]); return Number.isFinite(value) && value > 0 ? Math.floor(value) : fallback; }
function positiveOrZeroIntEnv(key, fallback) { const value = Number(process.env[key]); return Number.isFinite(value) && value >= 0 ? Math.floor(value) : fallback; }
function sleep(ms) { return new Promise((resolvePromise) => setTimeout(resolvePromise, ms)); }
function normalize(value) { return String(value ?? '').normalize('NFD').replace(/[\u0300-\u036f]/g, '').trim().toLowerCase().replace(/[_-]+/g,' ').replace(/\s+/g,' '); }
function digits(value) { return String(value ?? '').replace(/\D/g, ''); }
function json(value) { return value && typeof value === 'object' && !Array.isArray(value) ? value : {}; }
function now() { return new Date().toISOString(); }
function log(...args) { console.log(now(), ...args); }


class EvolutionRequestError extends Error {
  constructor(message, { uncertain = false, status = 0 } = {}) {
    super(message);
    this.name = 'EvolutionRequestError';
    this.uncertain = uncertain;
    this.status = status;
  }
}

async function rpcOne(name, parameters = {}) {
  const response = await supabase.rpc(name, parameters);
  if (response.error) throw new Error(`${name}:${response.error.message}`);
  return Array.isArray(response.data) ? response.data[0] ?? null : response.data ?? null;
}

function contentHash(context, partKey, body) {
  return createHash('sha256')
    .update(`${context.item.queue_items_payload_hash ?? ''}:${partKey}:${String(body ?? '')}`)
    .digest('hex');
}

function safeTokenEqual(received) {
  if (!cfg.httpToken) return true;
  const a = Buffer.from(String(received ?? ''));
  const b = Buffer.from(cfg.httpToken);
  return a.length === b.length && timingSafeEqual(a, b);
}

async function readBody(req) {
  const chunks = [];
  for await (const chunk of req) chunks.push(chunk);
  if (!chunks.length) return {};
  return JSON.parse(Buffer.concat(chunks).toString('utf8'));
}

function reply(res, status, payload) {
  res.writeHead(status, { 'Content-Type': 'application/json; charset=utf-8', 'Cache-Control': 'no-store' });
  res.end(JSON.stringify(payload));
}

async function fetchTimeout(url, init = {}) {
  const controller = new AbortController();
  const timer = setTimeout(() => controller.abort(), cfg.requestTimeoutMs);
  try { return await fetch(url, { ...init, signal: controller.signal }); }
  finally { clearTimeout(timer); }
}

async function statuses() {
  if (statusCache && statusCache.expires > Date.now()) return statusCache.value;
  const response = await supabase.from('status').select('status_id,status_name');
  if (response.error) throw new Error(`status_catalog_failed: ${response.error.message}`);
  const rows = response.data ?? [];
  const expected = new Map([
    [1, 'ativo'], [2, 'inativo'], [3, 'pendente'], [4, 'processando'],
    [5, 'concluido'], [6, 'erro'], [7, 'cancelado'], [8, 'pausado'],
  ]);
  for (const [id, name] of expected) {
    const row = rows.find((item) => Number(item.status_id) === id);
    if (!row || normalize(row.status_name) !== name) throw new Error(`status_catalog_contract_invalid:${id}:${name}`);
  }
  const value = {
    rows,
    nameById: new Map(rows.map((row) => [String(row.status_id), String(row.status_name)])),
    idFor(status) {
      const id = QUEUE_STATUS_IDS[status];
      if (!id) throw new Error(`status_not_mapped:${status}`);
      return id;
    },
  };
  statusCache = { expires: Date.now() + 30000, value };
  return value;
}


async function leadStatuses() {
  if (leadStatusCache && leadStatusCache.expires > Date.now()) return leadStatusCache.value;
  const response = await supabase.from('lead_status').select('lead_status_id,lead_status_name');
  if (response.error) throw new Error(`lead_status_catalog_failed: ${response.error.message}`);
  const rows = response.data ?? [];
  const expected = new Map([
    [1, 'importado'], [2, 'validado'], [3, 'pre envio'], [4, 'na fila'],
    [5, 'enviado'], [6, 'invalido'], [7, 'duplicado'], [8, 'arquivado'],
  ]);
  for (const [id, name] of expected) {
    const row = rows.find((item) => Number(item.lead_status_id) === id);
    if (!row || normalize(row.lead_status_name) !== name) throw new Error(`lead_status_catalog_contract_invalid:${id}:${name}`);
  }
  const value = {
    idFor(status) {
      if (status === 'queued') return CATALOG.leadStatus.QUEUED;
      if (status === 'sent') return CATALOG.leadStatus.SENT;
      if (status === 'invalid') return CATALOG.leadStatus.INVALID;
      throw new Error(`lead_status_not_mapped:${status}`);
    },
  };
  leadStatusCache = { expires: Date.now() + 30000, value };
  return value;
}


function semanticStatus(name) {
  const value = normalize(name);
  if (value === 'concluido' || value === 'sent' || value === 'completed') return 'sent';
  if (value === 'erro' || value === 'error' || value === 'failed' || value === 'cancelado') return 'error';
  if (value === 'pausado' || value === 'paused') return 'paused';
  if (value === 'processando' || value === 'processing' || value === 'sending') return 'sending';
  return 'queued';
}

async function channelId(name) {
  const expectedId = normalize(name) === 'whatsapp' ? CATALOG.channels.WHATSAPP : CATALOG.channels.INSTAGRAM;
  const response = await supabase.from('channels').select('channels_id,channels_name').eq('channels_id', expectedId).maybeSingle();
  if (response.error) throw new Error(response.error.message);
  if (!response.data || normalize(response.data.channels_name) !== normalize(name)) throw new Error(`channel_contract_invalid:${expectedId}:${name}`);
  return expectedId;
}

async function serviceEvolutionInstances({ userId = null, instanceId = null, instanceName = null } = {}) {
  const response = await supabase.rpc('service_get_evolution_instances', {
    p_users_id: userId == null ? null : Number(userId),
    p_instances_id: instanceId == null ? null : Number(instanceId),
    p_instance_name: instanceName == null ? null : String(instanceName),
  });
  if (response.error) throw new Error(`evolution_credentials_failed:${response.error.message}`);
  return response.data ?? [];
}

async function chipById(userId, chipId) {
  const chipResponse = await supabase.from('chips').select('chips_id,chips_name,chips_phone,instances_id').eq('users_id', Number(userId)).eq('chips_id', Number(chipId)).maybeSingle();
  if (chipResponse.error || !chipResponse.data) throw new Error(`chip_not_found:${chipResponse.error?.message ?? chipId}`);
  const instances = await serviceEvolutionInstances({ userId, instanceId: chipResponse.data.instances_id });
  const instance = instances[0];
  if (!instance) throw new Error(`instance_credentials_not_found:${chipResponse.data.instances_id}`);
  return {
    id: Number(chipResponse.data.chips_id),
    label: String(chipResponse.data.chips_name),
    phone: String(chipResponse.data.chips_phone),
    instance: String(instance.instances_name),
    baseUrl: String(instance.instances_url ?? '').replace(/\/$/, ''),
    apiKey: String(instance.api_key ?? ''),
  };
}

async function chipByInstance(userId, instanceName) {
  const instances = await serviceEvolutionInstances({ userId, instanceName });
  const instance = instances[0];
  if (!instance) throw new Error(`instance_credentials_not_found:${instanceName}`);
  const chip = await supabase.from('chips').select('chips_id,chips_name,chips_phone').eq('users_id', Number(userId)).eq('instances_id', instance.instances_id).maybeSingle();
  if (chip.error || !chip.data) throw new Error(`chip_not_found_for_instance:${instanceName}`);
  return {
    id: Number(chip.data.chips_id), label: String(chip.data.chips_name), phone: String(chip.data.chips_phone),
    instance: String(instance.instances_name), baseUrl: String(instance.instances_url ?? '').replace(/\/$/, ''), apiKey: String(instance.api_key ?? ''),
  };
}

async function evolutionRequest(chip, method, endpoint, body) {
  if (!chip.baseUrl || !chip.apiKey) throw new Error(`chip_credentials_missing:${chip.instance}`);
  if (cfg.dryRun && endpoint.includes('/message/')) return { dryRun: true, id: `dry-${Date.now()}` };
  let response;
  try {
    response = await fetchTimeout(`${chip.baseUrl}${endpoint}`, {
      method,
      headers: { 'Content-Type': 'application/json', apikey: chip.apiKey, Authorization: `Bearer ${chip.apiKey}` },
      ...(body ? { body: JSON.stringify(body) } : {}),
    });
  } catch (error) {
    throw new EvolutionRequestError(error instanceof Error ? error.message : String(error), { uncertain: true });
  }
  const raw = await response.text();
  let payload = {};
  try { payload = raw ? JSON.parse(raw) : {}; } catch { payload = { raw }; }
  if (!response.ok) {
    const message = String(payload?.message ?? payload?.error ?? raw ?? `Evolution HTTP ${response.status}`);
    throw new EvolutionRequestError(message, { uncertain: response.status === 408 || response.status === 429 || response.status >= 500, status: response.status });
  }
  return payload;
}

async function assertConnected(chip) {
  const response = await evolutionRequest(chip, 'GET', `/instance/connectionState/${encodeURIComponent(chip.instance)}`);
  const state = normalize(response?.state ?? response?.instance?.state ?? response?.connection ?? response?.status);
  if (!['open','opened','connected','connectado','conectado','online','ready'].includes(state)) throw new Error(`chip_disconnected:${chip.instance}`);
}

async function syncEvolutionInstanceStatuses() {
  if (instanceSyncRunning) return;
  instanceSyncRunning = true;
  try {
    const instances = await serviceEvolutionInstances();

    for (const instance of instances) {
      const instanceId = Number(instance.instances_id);
      const instanceName = String(instance.instances_name ?? '').trim();
      const baseUrl = String(instance.instances_url ?? '').trim().replace(/\/$/, '');
      const apiKey = String(instance.api_key ?? '').trim();
      let active = false;
      let state = 'unavailable';

      try {
        if (!instanceName || !baseUrl || !apiKey) throw new Error('credentials_missing');
        const result = await fetchTimeout(`${baseUrl}/instance/connectionState/${encodeURIComponent(instanceName)}`, {
          method: 'GET',
          headers: { Accept: 'application/json', apikey: apiKey, Authorization: `Bearer ${apiKey}` },
        });
        const raw = await result.text();
        let payload = {};
        try { payload = raw ? JSON.parse(raw) : {}; } catch { payload = { raw }; }
        if (!result.ok) throw new Error(String(payload?.message ?? payload?.error ?? raw ?? `Evolution HTTP ${result.status}`));
        state = normalize(payload?.state ?? payload?.instance?.state ?? payload?.data?.state ?? payload?.connection ?? payload?.status);
        active = ['open','opened','connected','connectado','conectado','online','ready'].includes(state);
      } catch (error) {
        active = false;
        log('[instance-sync-check]', instanceName || instanceId, error instanceof Error ? error.message : String(error));
      }

      const nextStatus = active ? CATALOG.status.ACTIVE : CATALOG.status.INACTIVE;
      if (Number(instance.status_id) === nextStatus) continue;

      const updated = await supabase
        .from('instances')
        .update({ status_id: nextStatus, instances_updated_at: now() })
        .eq('instances_id', instanceId)
        .eq('users_id', Number(instance.users_id));
      if (updated.error) throw new Error(`instance_sync_update_failed:${instanceId}:${updated.error.message}`);
      log('[instance-status]', instanceName || instanceId, `=> ${active ? 'active' : 'inactive'} (${state})`);
    }
  } finally {
    instanceSyncRunning = false;
  }
}

async function sendText(chip, phone, message) {
  return evolutionRequest(chip, 'POST', `/message/sendText/${encodeURIComponent(chip.instance)}`, { number: phone, options: { delay: 1000 }, textMessage: { text: message } });
}

async function sendImage(chip, phone, image) {
  return evolutionRequest(chip, 'POST', `/message/sendMedia/${encodeURIComponent(chip.instance)}`, { number: phone, options: { delay: 1000 }, mediaMessage: { mediatype: 'image', media: image.base64, mimetype: image.mime, fileName: image.fileName, caption: '' } });
}

async function loadImage(metadata) {
  const imageName = String(metadata.name ?? metadata.imageName ?? metadata.image_name ?? '').trim();
  const required = Boolean(metadata.required ?? metadata.imageRequired ?? metadata.image_required);
  const expectedSha256 = String(metadata.sha256 ?? metadata.imageSha256 ?? metadata.image_sha256 ?? '').trim().toLowerCase();
  if (!imageName) {
    if (required) throw new Error('required_branch_image_missing');
    return null;
  }
  const safe = basename(imageName);
  if (safe !== imageName) throw new Error('invalid_image_name');
  const absolute = resolve(cfg.imagesDir, safe);
  if (!absolute.startsWith(`${cfg.imagesDir}${sep}`) && absolute !== resolve(cfg.imagesDir, safe)) throw new Error('invalid_image_path');
  const info = await stat(absolute).catch(() => null);
  if (!info?.isFile() || info.size <= 0) { if (required) throw new Error(`required_image_not_found:${safe}`); return null; }
  if (info.size > cfg.maxImageBytes) throw new Error(`image_too_large:${safe}`);
  const buffer = await readFile(absolute);
  const sha256 = createHash('sha256').update(buffer).digest('hex');
  if (expectedSha256 && expectedSha256 !== sha256) throw new Error(`image_snapshot_hash_mismatch:${safe}`);
  const extension = safe.toLowerCase().split('.').pop();
  const mime = extension === 'png' ? 'image/png' : extension === 'webp' ? 'image/webp' : 'image/jpeg';
  return { fileName: safe, mime, sha256, base64: buffer.toString('base64') };
}

async function queueItem(userId, id) {
  const itemResponse = await supabase.from('queue_items').select('*').eq('users_id', Number(userId)).eq('queue_items_id', Number(id)).maybeSingle();
  if (itemResponse.error || !itemResponse.data) throw new Error(`queue_item_not_found:${id}`);
  const item = itemResponse.data;
  const [lead, template, status] = await Promise.all([
    supabase.from('leads').select('*').eq('users_id', Number(userId)).eq('leads_id', item.leads_id).maybeSingle(),
    item.templates_id ? supabase.from('templates').select('*').eq('users_id', Number(userId)).eq('templates_id', item.templates_id).maybeSingle() : Promise.resolve({ data: null, error: null }),
    statuses(),
  ]);
  if (lead.error || !lead.data) throw new Error(`lead_not_found:${item.leads_id}`);
  const branchResponse = await supabase.from('branches').select('*').eq('users_id', Number(userId)).eq('branches_id', lead.data.branches_id).maybeSingle();
  return {
    item,
    lead: lead.data,
    template: template.data,
    branch: branchResponse.data,
    snapshot: json(item.queue_items_payload_snapshot),
    status: semanticStatus(status.nameById.get(String(item.status_id)) ?? item.status_id),
    chip: await chipById(userId, item.chips_id),
  };
}

async function claim(userId, id) {
  const context = await queueItem(userId, id);
  if (context.status === 'sent') return { context, alreadySent: true };
  if (!['queued','paused','error'].includes(context.status)) throw new Error(`queue_item_not_dispatchable:${id}:${context.status}`);
  const catalog = await statuses();
  const response = await supabase.from('queue_items').update({
    status_id: catalog.idFor('sending'),
    queue_items_started_at: now(),
    queue_items_finished_at: null,
    queue_items_attempts: Number(context.item.queue_items_attempts ?? 0) + 1,
    queue_items_error_message: null,
    queue_items_updated_at: now(),
  }).eq('users_id', Number(userId)).eq('queue_items_id', Number(id)).eq('status_id', Number(context.item.status_id)).select('queue_items_id').maybeSingle();
  if (response.error) throw new Error(response.error.message);
  if (!response.data) throw new Error(`queue_claim_conflict:${id}`);
  return { context: await queueItem(userId, id), alreadySent: false };
}

async function claimDispatchPart(userId, context, partKey, body) {
  const row = await rpcOne('worker_claim_dispatch_part', {
    p_users_id: Number(userId),
    p_queue_items_id: Number(context.item.queue_items_id),
    p_part_key: partKey,
    p_content_hash: contentHash(context, partKey, body),
    p_body: String(body ?? ''),
  });
  if (!row) throw new Error(`dispatch_part_claim_empty:${partKey}`);
  return {
    id: Number(row.part_id),
    state: String(row.part_state),
    shouldSend: row.should_send === true,
    claimToken: row.claim_token ? String(row.claim_token) : '',
    externalId: row.external_id ? String(row.external_id) : null,
    attempt: Number(row.attempt ?? 0),
  };
}

async function completeDispatchPart(userId, context, partKey, claimToken, outcome, externalId = null, errorMessage = null) {
  await rpcOne('worker_complete_dispatch_part', {
    p_users_id: Number(userId),
    p_queue_items_id: Number(context.item.queue_items_id),
    p_part_key: partKey,
    p_claim_token: claimToken,
    p_outcome: outcome,
    p_external_id: externalId,
    p_error_message: errorMessage,
  });
}

async function sendIdempotentPart({ userId, context, partKey, body, send }) {
  const part = await claimDispatchPart(userId, context, partKey, body);
  if (!part.shouldSend) {
    if (part.state === 'sent') return { skipped: true, externalId: part.externalId, attempt: part.attempt };
    if (part.state === 'reconciliation_required') throw new Error(`dispatch_reconciliation_required:${partKey}`);
    throw new Error(`dispatch_part_in_progress:${partKey}`);
  }

  let providerAccepted = false;
  try {
    const response = await send();
    providerAccepted = true;
    const externalId = response?.key?.id ?? response?.id ?? response?.messageId ?? null;
    await completeDispatchPart(userId, context, partKey, part.claimToken, 'sent', externalId, null);
    return { skipped: false, externalId, attempt: part.attempt };
  } catch (error) {
    if (providerAccepted) {
      throw new Error(`dispatch_part_persistence_uncertain:${partKey}:${error instanceof Error ? error.message : String(error)}`);
    }
    const uncertain = error instanceof EvolutionRequestError ? error.uncertain : true;
    const outcome = uncertain ? 'reconciliation_required' : 'failed';
    try {
      await completeDispatchPart(
        userId,
        context,
        partKey,
        part.claimToken,
        outcome,
        null,
        error instanceof Error ? error.message : String(error),
      );
    } catch (persistenceError) {
      log('[part-error-persistence]', partKey, persistenceError instanceof Error ? persistenceError.message : String(persistenceError));
    }
    throw error;
  }
}

async function dispatchOne(userId, id) {
  const key = `${userId}:${id}`;
  if (inFlight.has(key)) throw new Error(`queue_item_in_flight:${id}`);
  inFlight.add(key);
  let claimed;
  try {
    claimed = await claim(userId, id);
    if (claimed.alreadySent) return { id: String(id), leadId: String(id), status: 'sent', already_sent: true };
    const context = claimed.context;
    const hasSnapshot = Object.keys(context.snapshot).length > 0;
    const recipient = json(context.snapshot.recipient);
    const frozenMessages = json(context.snapshot.messages);
    const frozenMedia = json(context.snapshot.media);
    const phone = digits(recipient.phone ?? context.lead.leads_phone);
    if (phone.length < 10) throw new Error('invalid_phone');
    if (!hasSnapshot && !context.template) throw new Error('template_not_found');
    const messages = [1,2,3,4].map((part) => String(
      hasSnapshot ? frozenMessages[`message_${part}`] : context.template?.[`templates_message_${part}`] ?? ''
    ).trim());
    if (messages.some((message) => !message)) throw new Error(hasSnapshot ? 'snapshot_requires_four_messages' : 'template_requires_four_messages');
    if (!hasSnapshot) log('[legacy-content-fallback]', context.item.queue_items_id);

    await assertConnected(context.chip);
    const results = [];
    for (let index = 0; index < messages.length; index += 1) {
      const partKey = `message_${index + 1}`;
      const result = await sendIdempotentPart({
        userId,
        context,
        partKey,
        body: messages[index],
        send: () => sendText(context.chip, phone, messages[index]),
      });
      results.push({ part: index + 1, external_id: result.externalId, reused: result.skipped, attempt: result.attempt });
      if (!result.skipped && index < messages.length - 1 && cfg.delayBetweenMessagesMs) await sleep(cfg.delayBetweenMessagesMs);
    }

    const image = await loadImage(hasSnapshot ? frozenMedia : json(context.branch?.branches_categories));
    if (image) {
      if (cfg.delayTextToImageMs) await sleep(cfg.delayTextToImageMs);
      await sendIdempotentPart({
        userId,
        context,
        partKey: 'image',
        body: `${image.fileName}:${image.sha256}`,
        send: () => sendImage(context.chip, phone, image),
      });
    }

    await rpcOne('worker_finalize_whatsapp_queue_item', {
      p_users_id: Number(userId),
      p_queue_items_id: Number(id),
    });

    return {
      id: String(id),
      leadId: String(id),
      status: 'sent',
      messages: results,
      image: image?.fileName ?? null,
      image_sha256: image?.sha256 ?? null,
      payload_hash: context.item.queue_items_payload_hash ?? null,
    };
  } catch (error) {
    const message = error instanceof Error ? error.message : String(error);
    try {
      await rpcOne('worker_fail_whatsapp_queue_item', {
        p_users_id: Number(userId),
        p_queue_items_id: Number(id),
        p_error_message: message,
      });
    } catch (persistenceError) {
      log('[queue-error-persistence]', id, persistenceError instanceof Error ? persistenceError.message : String(persistenceError));
    }
    return { id: String(id), leadId: String(id), status: 'error', error: message, errorMessage: message };
  } finally { inFlight.delete(key); }
}

function validationItems(payload) {
  if (Array.isArray(payload)) return payload;
  const root = json(payload);
  for (const value of [root.response, root.data, root.result, root.results]) {
    if (Array.isArray(value)) return value;
    const nested = json(value);
    for (const child of [nested.response, nested.data, nested.result, nested.results]) if (Array.isArray(child)) return child;
  }
  return Object.keys(root).length ? [root] : [];
}

function validationDigits(item) { return digits(item?.number ?? item?.phone ?? item?.jid ?? item?.remoteJid ?? item?._serialized).split(':')[0]; }
function validationBoolean(value) { if (value === true || value === false) return value; const normalized = normalize(value); if (['true','1','yes','sim'].includes(normalized)) return true; if (['false','0','no','nao'].includes(normalized)) return false; return undefined; }

async function validateLeads(body) {
  const userId = Number(body.user_id ?? body.userId);
  const leads = Array.isArray(body.leads) ? body.leads : [];
  if (!Number.isSafeInteger(userId) || !leads.length || leads.length > cfg.validationMaxLeads) throw new Error('validation_request_invalid');
  const results = [];
  for (const lead of leads) {
    try {
      const chip = await chipByInstance(userId, String(lead.chip_instance ?? ''));
      await assertConnected(chip);
      const phone = digits(lead.normalized_phone ?? lead.phone);
      const payload = await evolutionRequest(chip, 'POST', `/chat/whatsappNumbers/${encodeURIComponent(chip.instance)}`, { numbers: [phone] });
      const exact = validationItems(payload).filter((item) => validationDigits(item) === phone);
      if (exact.length !== 1) throw new Error(exact.length ? 'validation_ambiguous_provider_result' : 'validation_exact_match_missing');
      const item = exact[0];
      const explicit = validationBoolean(item.exists ?? item.valid ?? item.isWhatsapp ?? item.hasWhatsapp ?? item.isValid ?? item.registered);
      const valid = explicit === true || String(item.jid ?? item.remoteJid ?? '').endsWith('@s.whatsapp.net');
      const invalid = explicit === false || ['invalid','not_found','no_whatsapp','not_on_whatsapp'].includes(normalize(item.status ?? item.result));
      if (!valid && !invalid) throw new Error('validation_provider_confirmation_missing');
      results.push({ leadId: String(lead.id ?? lead.lead_id), lead_id: String(lead.lead_id ?? lead.id), status: valid ? 'valid' : 'invalid', valid });
    } catch (error) {
      results.push({ leadId: String(lead.id ?? lead.lead_id), lead_id: String(lead.lead_id ?? lead.id), status: 'error', valid: false, errorMessage: error instanceof Error ? error.message : String(error) });
    }
    if (cfg.validationDelayMs) await sleep(cfg.validationDelayMs);
  }
  return { ok: true, meta: { operation: body.operation ?? 'validate', mode: body.mode ?? 'initial' }, results };
}

function batchStateFromRow(row, chip) {
  if (!row) return { ok: true, status: 'idle', enabled: false, chip, total: 0, remaining: 0, processed: 0, sent: 0, failed: 0 };
  return {
    ok: true,
    batch_id: Number(row.batch_id ?? row.worker_batches_id ?? 0),
    status: String(row.batch_status ?? 'idle'),
    enabled: row.enabled === true,
    chip: String(row.chip ?? chip ?? ''),
    total: Number(row.total ?? 0),
    remaining: Number(row.remaining ?? 0),
    processed: Number(row.processed ?? 0),
    sent: Number(row.sent ?? 0),
    failed: Number(row.failed ?? 0),
    next_run_at: row.next_run_at ?? '',
    started_at: row.started_at ?? '',
    last_error: String(row.last_error ?? ''),
    already_running: row.already_running === true,
  };
}

async function startBatch(body) {
  const userId = Number(body.user_id ?? body.userId);
  const ids = [...new Set((body.queue_item_ids ?? []).map(Number).filter(Number.isSafeInteger))];
  const chip = String(body.chip_instance ?? '');
  if (!userId || !ids.length || !chip) throw new Error('batch_request_invalid');
  const row = await rpcOne('worker_start_whatsapp_batch', {
    p_users_id: userId,
    p_chip_instance: chip,
    p_queue_item_ids: ids,
    p_worker_id: cfg.workerId,
  });
  return batchStateFromRow(row, chip);
}

async function setControl(body, action) {
  const userId = Number(body.user_id ?? body.userId);
  const chip = String(body.chip_instance ?? body.chip ?? '');
  if (!userId || !chip) throw new Error('batch_request_invalid');
  const row = await rpcOne('worker_set_whatsapp_batch_state', {
    p_users_id: userId,
    p_chip_instance: chip,
    p_action: action,
    p_worker_id: cfg.workerId,
  });
  return batchStateFromRow(row, chip);
}

async function batchState(body) {
  return setControl(body, 'state');
}

async function recoverStaleExecution() {
  if (recoveryRunning) return;
  recoveryRunning = true;
  try {
    const staleBefore = new Date(Date.now() - cfg.staleExecutionMs).toISOString();
    const row = await rpcOne('worker_recover_stale_whatsapp', { p_stale_before: staleBefore });
    if (row && (Number(row.recovered_items) || Number(row.reconciliation_items))) {
      log('[recovery]', row);
    }
  } finally {
    recoveryRunning = false;
  }
}

async function schedulerTick() {
  if (schedulerRunning) return;
  schedulerRunning = true;
  try {
    const batches = await supabase
      .from('worker_batches')
      .select('worker_batches_id,worker_batches_next_run_at')
      .eq('status_id', CATALOG.status.PROCESSING)
      .order('worker_batches_id');
    if (batches.error) throw new Error(`worker_batches_list_failed:${batches.error.message}`);

    for (const batch of batches.data ?? []) {
      const nextRunAt = batch.worker_batches_next_run_at ? new Date(batch.worker_batches_next_run_at).getTime() : 0;
      if (Number.isFinite(nextRunAt) && nextRunAt > Date.now()) continue;
      const claimed = await rpcOne('worker_claim_next_batch_item', {
        p_worker_batches_id: Number(batch.worker_batches_id),
        p_worker_id: cfg.workerId,
      });
      if (!claimed?.queue_item_id) continue;

      const result = await dispatchOne(
        Number((await queueItemOwner(Number(claimed.queue_item_id))).users_id),
        Number(claimed.queue_item_id),
      );
      const position = Number(claimed.item_position ?? 0);
      const nextDelay = position > 0 && position % 60 === 0 ? cfg.batchPauseMs : cfg.delayBetweenMessagesMs;
      await rpcOne('worker_complete_batch_item', {
        p_worker_batch_items_id: Number(claimed.batch_item_id),
        p_result: result.status,
        p_error_message: result.error ?? result.errorMessage ?? null,
        p_next_run_at: new Date(Date.now() + nextDelay).toISOString(),
      });
    }
  } finally {
    schedulerRunning = false;
  }
}

async function queueItemOwner(queueItemId) {
  const response = await supabase.from('queue_items').select('users_id').eq('queue_items_id', queueItemId).maybeSingle();
  if (response.error || !response.data) throw new Error(`queue_item_owner_not_found:${queueItemId}`);
  return response.data;
}

setInterval(() => { void schedulerTick().catch((error) => log('[scheduler]', error)); }, cfg.schedulerTickMs).unref();
setTimeout(() => { void recoverStaleExecution().catch((error) => log('[recovery]', error)); }, 1000).unref();
setInterval(() => { void recoverStaleExecution().catch((error) => log('[recovery]', error)); }, cfg.recoveryIntervalMs).unref();
setTimeout(() => { void syncEvolutionInstanceStatuses().catch((error) => log('[instance-sync]', error)); }, 2000).unref();
setInterval(() => { void syncEvolutionInstanceStatuses().catch((error) => log('[instance-sync]', error)); }, cfg.instanceSyncIntervalMs).unref();

const server = createServer(async (req, res) => {
  try {
    if (req.method === 'GET' && req.url === '/health') return reply(res, 200, { ok: true, version: VERSION, schema: 'vault_credentials+worker_batches+dispatch_parts', evolutionInstanceSyncSeconds: Math.round(cfg.instanceSyncIntervalMs / 1000) });
    if (!safeTokenEqual(req.headers['x-worker-token'])) return reply(res, 401, { ok: false, error: 'unauthorized' });
    const body = await readBody(req);
    if (req.method === 'POST' && req.url === '/validation/whatsapp') return reply(res, 200, await validateLeads(body));
    if (req.method === 'POST' && req.url === '/dispatch/whatsapp') {
      const userId = Number(body.user_id ?? body.userId); const ids = [...new Set((body.queue_item_ids ?? []).map(Number).filter(Number.isSafeInteger))];
      if (!userId || !ids.length) return reply(res, 400, { ok: false, error: 'dispatch_request_invalid' });
      const results = []; for (const id of ids) results.push(await dispatchOne(userId, id));
      return reply(res, results.some((item) => item.status === 'error') ? 207 : 200, { ok: !results.some((item) => item.status === 'error'), results });
    }
    if (req.method === 'POST' && req.url === '/batch/whatsapp/start') return reply(res, 202, await startBatch(body));
    if (req.method === 'POST' && req.url === '/batch/whatsapp/pause') return reply(res, 200, await setControl(body, 'pause'));
    if (req.method === 'POST' && req.url === '/batch/whatsapp/resume') return reply(res, 200, await setControl(body, 'resume'));
    if (req.method === 'POST' && req.url === '/batch/whatsapp/stop') return reply(res, 200, await setControl(body, 'stop'));
    if (req.method === 'POST' && (req.url === '/batch/whatsapp/status' || req.url === '/batch/whatsapp/state')) return reply(res, 200, await batchState(body));
    return reply(res, 404, { ok: false, error: 'not_found' });
  } catch (error) {
    log('[http-error]', error);
    return reply(res, 500, { ok: false, error: error instanceof Error ? error.message : String(error) });
  }
});

server.listen(cfg.httpPort, cfg.httpHost, () => log(`[worker ${VERSION}] listening on ${cfg.httpHost}:${cfg.httpPort}`));
