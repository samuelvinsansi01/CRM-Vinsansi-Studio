import fs from 'node:fs';
const source = fs.readFileSync(new URL('../src/worker.js', import.meta.url), 'utf8');
const assert = (condition, message) => { if (!condition) throw new Error(message); };
assert(source.includes("const VERSION = '3.4.0'"), 'Versão 3.4.0 ausente.');
assert(source.includes("rpc('service_get_evolution_instances'"), 'Worker não obtém credenciais pelo RPC protegido.');
assert(!source.includes('instances_apikey'), 'Worker ainda consulta a coluna pública de API key.');
assert(source.includes('WORKER_HTTP_TOKEN deve ter no minimo 32 caracteres'), 'Token HTTP forte não é exigido.');
assert(source.includes("schema: 'vault_credentials+worker_batches+dispatch_parts'"), 'Health check não anuncia o contrato seguro.');
console.log('Worker 3.4.0: credenciais Evolution via Vault e token HTTP forte validados.');
