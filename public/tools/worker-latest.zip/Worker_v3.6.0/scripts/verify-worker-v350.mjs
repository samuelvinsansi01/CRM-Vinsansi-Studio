import { readFileSync } from 'node:fs';
const source = readFileSync(new URL('../src/worker.js', import.meta.url), 'utf8');
function assert(condition, message) { if (!condition) throw new Error(message); }
assert(/const VERSION = '3\.(?:[5-9]|[1-9]\d)\.0'/.test(source), 'Versão compatível com 3.5.0 ou superior ausente.');
assert(source.includes('service_get_operational_settings'), 'Worker não consulta configurações centralizadas.');
assert(source.includes('worker_defer_batch'), 'Worker não adia lote fora da janela operacional.');
assert(source.includes('nextBatchDelayMs(settings, position)'), 'Delays persistidos não controlam o lote.');
console.log('Worker 3.5.0: configurações centralizadas verificadas.');
