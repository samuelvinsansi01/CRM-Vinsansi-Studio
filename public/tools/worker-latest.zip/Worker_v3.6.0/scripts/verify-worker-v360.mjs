import fs from 'node:fs';
const source=fs.readFileSync(new URL('../src/worker.js',import.meta.url),'utf8');
const pkg=JSON.parse(fs.readFileSync(new URL('../package.json',import.meta.url),'utf8'));
for(const token of ['service_worker_heartbeat','service_claim_recovery_request','service_complete_recovery_request','refresh_operational_alerts','processRecoveryRequest']) if(!source.includes(token)) throw new Error(`worker_v360_missing:${token}`);
if(pkg.version!=='3.6.0') throw new Error('worker_version_not_3_6_0');
console.log('Worker 3.6.0 observability: OK');
