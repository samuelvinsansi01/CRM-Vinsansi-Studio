import fs from 'node:fs';
import { decideWhatsAppOperationalWindow } from '../src/operational-window.js';

const worker = fs.readFileSync(new URL('../src/worker.js', import.meta.url), 'utf8').replace(/\r\n/g, '\n');
const failures = [];
const assert = (condition, message) => { if (!condition) failures.push(message); };
const settings = (overrides = {}) => ({
  operationalTimezone: 'America/Sao_Paulo',
  activeDays: ['Segunda', 'Terca', 'Quarta', 'Quinta', 'Sexta'],
  startTime: '13:00',
  endTime: '18:00',
  cutoffHour: 22,
  ...overrides,
});
const decide = (instant, overrides) => decideWhatsAppOperationalWindow(settings(overrides), new Date(instant));

const inside = decide('2026-08-03T17:00:00.000Z');
assert(inside.allowed && inside.reason === 'inside_operational_window', 'Dia permitido dentro da janela foi bloqueado.');

const blockedDay = decide('2026-08-02T17:00:00.000Z');
assert(!blockedDay.allowed && blockedDay.reason === 'inactive_day', 'Dia inativo não foi bloqueado.');
assert(blockedDay.nextEligibleAt === '2026-08-03T16:00:00.000Z', 'Próximo instante após dia inativo está incorreto.');

const beforeStart = decide('2026-08-03T15:59:00.000Z');
assert(!beforeStart.allowed && beforeStart.reason === 'before_start', 'Instante anterior ao início não foi bloqueado.');
assert(beforeStart.nextEligibleAt === '2026-08-03T16:00:00.000Z', 'Próximo instante antes do início está incorreto.');

const afterEnd = decide('2026-08-03T21:00:00.000Z');
assert(!afterEnd.allowed && afterEnd.reason === 'at_or_after_effective_end', 'Instante no fim da janela não foi bloqueado.');
assert(afterEnd.nextEligibleAt === '2026-08-04T16:00:00.000Z', 'Próximo instante após o fim está incorreto.');

const missingCutoffAfter22 = decide('2026-08-04T01:00:00.000Z', { endTime: '23:30', cutoffHour: undefined });
assert(!missingCutoffAfter22.allowed && missingCutoffAfter22.effectiveEndTime === '22:00', 'cutoff ausente não aplicou o padrão de 22h com endTime 23:30.');

const invalidCutoffAfter22 = decide('2026-08-04T01:00:00.000Z', { endTime: '23:30', cutoffHour: 'inválido' });
assert(!invalidCutoffAfter22.allowed && invalidCutoffAfter22.effectiveEndTime === '22:00', 'cutoff inválido não aplicou o padrão de 22h com endTime 23:30.');

for (const invalidCutoff of ['', -1, 24, 22.5]) {
  const decision = decide('2026-08-04T01:00:00.000Z', { endTime: '23:30', cutoffHour: invalidCutoff });
  assert(!decision.allowed && decision.effectiveEndTime === '22:00', `cutoff fora do intervalo aceito não aplicou 22h: ${String(invalidCutoff)}.`);
}

const missingCutoffBefore22 = decide('2026-08-03T20:00:00.000Z', { endTime: '18:00', cutoffHour: undefined });
assert(missingCutoffBefore22.allowed && missingCutoffBefore22.effectiveEndTime === '18:00', 'cutoff ausente ampliou endTime 18:00.');

const beforeEarlyCutoff = decide('2026-08-03T18:59:00.000Z', { endTime: '18:00', cutoffHour: 16 });
const atEarlyCutoff = decide('2026-08-03T19:00:00.000Z', { endTime: '18:00', cutoffHour: 16 });
assert(beforeEarlyCutoff.allowed && !atEarlyCutoff.allowed && atEarlyCutoff.effectiveEndTime === '16:00', 'cutoff anterior ao endTime não restringiu o fim efetivo.');

const validCutoffAfterEnd = decide('2026-08-03T21:00:00.000Z', { endTime: '18:00', cutoffHour: 22 });
assert(!validCutoffAfterEnd.allowed && validCutoffAfterEnd.effectiveEndTime === '18:00', 'cutoff posterior ao endTime ampliou a janela.');

const saoPaulo = decideWhatsAppOperationalWindow(settings(), new Date('2026-08-03T16:00:00.000Z'));
const newYork = decideWhatsAppOperationalWindow(settings({ operationalTimezone: 'America/New_York' }), new Date('2026-08-03T16:00:00.000Z'));
assert(saoPaulo.allowed && !newYork.allowed && newYork.reason === 'before_start', 'Timezone não participa corretamente da decisão operacional.');

const schedulerStart = worker.indexOf('async function schedulerTick()');
const schedulerEnd = worker.indexOf('async function sendWorkerHeartbeat', schedulerStart);
const scheduler = worker.slice(schedulerStart, schedulerEnd);
const serverStart = worker.indexOf('const server = createServer');
const serverEnd = worker.indexOf('server.listen', serverStart);
const httpHandler = worker.slice(serverStart, serverEnd);
const dispatchCalls = worker.match(/dispatchOne\s*\(/g) ?? [];

assert(scheduler.includes('decideWhatsAppOperationalWindow('), 'schedulerTick não usa a decisão operacional central.');
assert(scheduler.includes('windowDecision.nextEligibleAt'), 'schedulerTick não persiste o próximo instante operacional.');
assert(!worker.includes('isOperationalWindow('), 'Cálculo operacional antigo continua duplicado no Worker.');
assert(dispatchCalls.length === 2 && scheduler.includes('dispatchOne('), 'dispatchOne possui chamador além do schedulerTick.');
assert(!httpHandler.includes('dispatchOne('), 'Handler HTTP chama dispatchOne diretamente.');

if (failures.length) {
  failures.forEach((failure) => console.error(`- ${failure}`));
  process.exit(1);
}

console.log('Worker operational window: OK');
