import { readFileSync } from 'node:fs';
import { normalizeWhatsAppRecipient } from '../src/contactIdentity.js';

const worker = readFileSync(new URL('../src/worker.js', import.meta.url), 'utf8').replace(/\r\n/g, '\n');
const idempotencySql = readFileSync(
  new URL('../../crm-novo/supabase/migrations/20260802090000_worker_persistence_idempotency.sql', import.meta.url),
  'utf8',
).replace(/\r\n/g, '\n');
const cadenceSql = readFileSync(
  new URL('../../crm-novo/supabase/migrations/20260806110000_preserve_whatsapp_batch_cadence.sql', import.meta.url),
  'utf8',
).replace(/\r\n/g, '\n');
const failures = [];
const assert = (condition, message) => { if (!condition) failures.push(message); };

const validCases = [
  ['(11) 99999-9999', '5511999999999'],
  ['11999999999', '5511999999999'],
  ['+55 11 99999-9999', '5511999999999'],
  ['0055 11 99999-9999', '5511999999999'],
  ['5511999999999', '5511999999999'],
  ['1133334444', '551133334444'],
];

for (const [input, canonical] of validCases) {
  const result = normalizeWhatsAppRecipient(input);
  assert(result.ok === true, `Destinatario valido foi rejeitado: ${input}.`);
  assert(result.canonical === canonical, `Canonical incorreto para ${input}: ${String(result.canonical)}.`);
  assert(result.inputDigits === String(input).replace(/\D/g, ''), `inputDigits incorreto para ${input}.`);
}

const invalidCases = [
  ['', 'empty_recipient'],
  ['---', 'empty_recipient'],
  ['123456789', 'recipient_too_short'],
  ['01199999999', 'national_recipient_starts_with_zero'],
  ['441234567890', 'brazil_country_code_required'],
  ['4412345678901', 'brazil_country_code_required'],
  [`0055${'1'.repeat(14)}`, 'recipient_too_long'],
  [null, 'empty_recipient'],
  [undefined, 'empty_recipient'],
];

for (const [input, reason] of invalidCases) {
  const result = normalizeWhatsAppRecipient(input);
  assert(result.ok === false, `Destinatario invalido foi aceito: ${String(input)}.`);
  assert(result.canonical === null, `Falha deveria retornar canonical null: ${String(input)}.`);
  assert(result.reason === reason, `Motivo incorreto para ${String(input)}: ${String(result.reason)}.`);
}

const dispatchStart = worker.indexOf('async function dispatchOne(');
const dispatchEnd = worker.indexOf('\nfunction validationItems(', dispatchStart);
const dispatch = worker.slice(dispatchStart, dispatchEnd);
const validationStart = worker.indexOf('async function validateLeads(');
const validationEnd = worker.indexOf('\nfunction batchStateFromRow(', validationStart);
const validation = worker.slice(validationStart, validationEnd);
const idempotentStart = worker.indexOf('async function sendIdempotentPart(');
const idempotentEnd = worker.indexOf('\nasync function dispatchOne(', idempotentStart);
const idempotent = worker.slice(idempotentStart, idempotentEnd);
const schedulerStart = worker.indexOf('async function schedulerTick()');
const schedulerEnd = worker.indexOf('\nasync function sendWorkerHeartbeat', schedulerStart);
const scheduler = worker.slice(schedulerStart, schedulerEnd);

assert(worker.includes("import { normalizeWhatsAppRecipient } from './contactIdentity.js';"), 'Worker nao importa o helper central de identidade.');
assert(dispatch.includes('normalizeWhatsAppRecipient(recipient.phone)'), 'Disparo nao canonicaliza exclusivamente o telefone do snapshot.');
assert(!dispatch.includes('context.lead.leads_phone'), 'Disparo ainda usa telefone bruto do lead como fallback.');
assert(dispatch.includes('const phone = normalizedRecipient.canonical;'), 'Disparo nao usa canonical como destinatario.');
assert(dispatch.indexOf('normalizeWhatsAppRecipient(recipient.phone)') < dispatch.indexOf('await assertConnected(context.chip)'), 'Disparo consulta a Evolution antes de validar o destinatario.');
assert(dispatch.indexOf('invalid_whatsapp_recipient_contract:') < dispatch.indexOf('sendIdempotentPart({'), 'Falha estrutural ocorre depois do claim de uma parte.');
assert(dispatch.includes('send: () => sendText(context.chip, phone, messages[index])'), 'Texto nao recebe exclusivamente o canonical.');
assert(dispatch.includes('send: () => sendImage(context.chip, phone, image)'), 'Midia nao recebe exclusivamente o canonical.');
assert(dispatch.includes("rpcOne('worker_fail_whatsapp_queue_item'"), 'Falha local do destinatario nao usa o caminho confirmado existente.');

assert(validation.includes('normalizeWhatsAppRecipient(lead.normalized_phone)'), 'Validacao nao usa o mesmo helper sobre normalized_phone.');
assert(!validation.includes('lead.normalized_phone ?? lead.phone'), 'Validacao ainda usa telefone bruto como fallback.');
assert(validation.includes('const phone = normalizedRecipient.canonical;'), 'Validacao nao envia o canonical.');
assert(validation.indexOf('normalizeWhatsAppRecipient(lead.normalized_phone)') < validation.indexOf('await assertConnected(chip)'), 'Validacao chama a Evolution antes de validar o destinatario.');
assert(validation.includes('{ numbers: [phone] }'), 'Validacao nao envia canonical no payload da Evolution.');
assert(validation.includes('validationDigits(item) === phone'), 'Resposta da Evolution nao e comparada exatamente com canonical.');
assert(!validation.includes('validationDigits(item).includes('), 'Validacao compara telefone retornado por substring.');
assert(!validation.includes('phone.includes(validationDigits(item))'), 'Validacao compara canonical por substring.');

assert(worker.includes("response.status === 408 || response.status === 429 || response.status >= 500"), 'Classificacao conservadora de 408, 429 e 5xx foi alterada.');
assert(idempotent.includes("const outcome = uncertain ? 'reconciliation_required' : 'failed';"), 'Resposta ambigua deixou de exigir reconciliacao.');
assert(idempotent.includes("if (part.state === 'sent') return { skipped: true"), 'Parte sent pode voltar a ser enviada.');

const dispatchCalls = worker.match(/dispatchOne\s*\(/g) ?? [];
assert(dispatchCalls.length === 2 && scheduler.includes('dispatchOne('), 'dispatchOne possui chamador alem do schedulerTick.');
assert(scheduler.includes('p_result: result.status'), 'Falha local nao termina o item persistente do lote.');

assert(idempotencySql.includes("IF v_part.queue_item_dispatch_parts_state = 'sent' THEN"), 'RPC nao reconhece parte sent antes de reivindicar.');
assert(idempotencySql.includes("WHERE public.queue_item_dispatch_parts.queue_item_dispatch_parts_state IN ('pending', 'failed')"), 'RPC pode reivindicar estado diferente de pending/failed.');
assert(cadenceSql.includes("v_status_id := CASE v_result WHEN 'sent' THEN 5 WHEN 'paused' THEN 8 WHEN 'stopped' THEN 7 ELSE 6 END;"), 'Erro estrutural nao permanece terminal no item do lote.');

if (failures.length) {
  failures.forEach((failure) => console.error(`- ${failure}`));
  process.exit(1);
}

console.log('Worker WhatsApp recipient identity contract: OK');
