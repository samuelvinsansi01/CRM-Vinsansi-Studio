import fs from 'node:fs';
const source = fs.readFileSync(new URL('../src/worker.js', import.meta.url), 'utf8');
const assert = (condition, message) => { if (!condition) throw new Error(message); };
assert(/const VERSION = '3\.(?:[4-9]|[1-9]\d)\.0'/.test(source), 'Versão compatível com 3.4.0 ou superior ausente.');
assert(source.includes("rpc('service_get_evolution_instances'"), 'Worker não obtém credenciais pelo RPC protegido.');
assert(!source.includes('instances_apikey'), 'Worker ainda consulta a coluna pública de API key.');
assert(source.includes('WORKER_HTTP_TOKEN deve ter no minimo 32 caracteres'), 'Token HTTP forte não é exigido.');
assert(source.includes('vault_credentials+worker_batches+dispatch_parts'), 'Health check não anuncia o contrato seguro.');
console.log('Worker 3.4.0: credenciais Evolution via Vault e token HTTP forte validados.');
