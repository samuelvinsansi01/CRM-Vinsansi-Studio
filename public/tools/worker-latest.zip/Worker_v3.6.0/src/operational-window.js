const DAY_NAMES = ['Domingo', 'Segunda', 'Terca', 'Quarta', 'Quinta', 'Sexta', 'Sabado'];
const DEFAULT_CUTOFF_MINUTES = 22 * 60;

function normalizeDay(value) {
  return String(value ?? '')
    .normalize('NFD')
    .replace(/[\u0300-\u036f]/g, '')
    .trim()
    .toLowerCase();
}

function timeMinutes(value) {
  const match = String(value ?? '').match(/^(\d{2}):(\d{2})$/);
  if (!match) return null;
  const hour = Number(match[1]);
  const minute = Number(match[2]);
  return hour <= 23 && minute <= 59 ? hour * 60 + minute : null;
}

function validCutoffMinutes(value) {
  if ((typeof value !== 'number' && typeof value !== 'string') || String(value).trim() === '') return DEFAULT_CUTOFF_MINUTES;
  const hour = Number(value);
  return Number.isInteger(hour) && hour >= 0 && hour <= 23 ? hour * 60 : DEFAULT_CUTOFF_MINUTES;
}

function formatter(timeZone) {
  return new Intl.DateTimeFormat('en-US', {
    timeZone,
    year: 'numeric',
    month: '2-digit',
    day: '2-digit',
    weekday: 'short',
    hour: '2-digit',
    minute: '2-digit',
    second: '2-digit',
    hourCycle: 'h23',
  });
}

function zonedParts(date, timeZone) {
  const parts = Object.fromEntries(formatter(timeZone).formatToParts(date).map((part) => [part.type, part.value]));
  return {
    year: Number(parts.year),
    month: Number(parts.month),
    dayOfMonth: Number(parts.day),
    day: DAY_NAMES[['Sun', 'Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat'].indexOf(parts.weekday)] ?? parts.weekday,
    hour: Number(parts.hour),
    minute: Number(parts.minute),
    second: Number(parts.second),
    minutes: Number(parts.hour) * 60 + Number(parts.minute),
  };
}

function addCalendarDays(parts, offset) {
  const date = new Date(Date.UTC(parts.year, parts.month - 1, parts.dayOfMonth + offset, 12));
  return { year: date.getUTCFullYear(), month: date.getUTCMonth() + 1, dayOfMonth: date.getUTCDate() };
}

function dayName(parts) {
  return DAY_NAMES[new Date(Date.UTC(parts.year, parts.month - 1, parts.dayOfMonth, 12)).getUTCDay()];
}

function zonedDateAtMinutes(parts, minutes, timeZone) {
  const hour = Math.floor(minutes / 60);
  const minute = minutes % 60;
  const desiredAsUtc = Date.UTC(parts.year, parts.month - 1, parts.dayOfMonth, hour, minute, 0, 0);
  let candidate = desiredAsUtc;

  for (let attempt = 0; attempt < 4; attempt += 1) {
    const actual = zonedParts(new Date(candidate), timeZone);
    const actualAsUtc = Date.UTC(actual.year, actual.month - 1, actual.dayOfMonth, actual.hour, actual.minute, actual.second, 0);
    const adjustment = desiredAsUtc - actualAsUtc;
    candidate += adjustment;
    if (!adjustment) break;
  }

  const result = new Date(candidate);
  const check = zonedParts(result, timeZone);
  return check.year === parts.year
    && check.month === parts.month
    && check.dayOfMonth === parts.dayOfMonth
    && check.hour === hour
    && check.minute === minute
    ? result
    : null;
}

function nextEligibleAt(clock, instant, timeZone, activeDays, start, effectiveEnd) {
  if (!activeDays.size || effectiveEnd <= start) return null;
  const todayIsActive = activeDays.has(normalizeDay(clock.day));
  const firstOffset = todayIsActive && clock.minutes < start ? 0 : 1;

  for (let offset = firstOffset; offset <= firstOffset + 7; offset += 1) {
    const candidateDay = addCalendarDays(clock, offset);
    if (!activeDays.has(normalizeDay(dayName(candidateDay)))) continue;
    const candidate = zonedDateAtMinutes(candidateDay, start, timeZone);
    if (candidate && candidate.getTime() > instant.getTime()) return candidate.toISOString();
  }

  return null;
}

export function decideWhatsAppOperationalWindow(configuration, currentInstant) {
  const instant = currentInstant instanceof Date ? new Date(currentInstant.getTime()) : new Date(currentInstant);
  const timeZone = String(configuration?.operationalTimezone ?? '').trim();
  const start = timeMinutes(configuration?.startTime);
  const end = timeMinutes(configuration?.endTime);
  const activeDays = new Set((Array.isArray(configuration?.activeDays) ? configuration.activeDays : []).map(normalizeDay).filter(Boolean));

  if (!Number.isFinite(instant.getTime())) return { allowed: false, reason: 'invalid_instant', nextEligibleAt: null };
  if (start == null || end == null || start >= end) return { allowed: false, reason: 'invalid_operational_window', nextEligibleAt: null };

  let clock;
  try {
    clock = zonedParts(instant, timeZone);
  } catch {
    return { allowed: false, reason: 'invalid_operational_timezone', nextEligibleAt: null };
  }

  const effectiveEnd = Math.min(end, validCutoffMinutes(configuration?.cutoffHour));
  const next = () => nextEligibleAt(clock, instant, timeZone, activeDays, start, effectiveEnd);
  const effectiveEndTime = `${String(Math.floor(effectiveEnd / 60)).padStart(2, '0')}:${String(effectiveEnd % 60).padStart(2, '0')}`;

  if (effectiveEnd <= start) return { allowed: false, reason: 'empty_effective_window', nextEligibleAt: null, effectiveEndTime };
  if (!activeDays.has(normalizeDay(clock.day))) return { allowed: false, reason: 'inactive_day', nextEligibleAt: next(), effectiveEndTime };
  if (clock.minutes < start) return { allowed: false, reason: 'before_start', nextEligibleAt: next(), effectiveEndTime };
  if (clock.minutes >= effectiveEnd) return { allowed: false, reason: 'at_or_after_effective_end', nextEligibleAt: next(), effectiveEndTime };
  return { allowed: true, reason: 'inside_operational_window', nextEligibleAt: null, effectiveEndTime };
}
