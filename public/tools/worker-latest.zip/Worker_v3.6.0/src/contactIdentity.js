export function normalizeWhatsAppRecipient(value) {
  const inputDigits = String(value ?? '').replace(/\D/g, '');

  if (!inputDigits) {
    return { ok: false, canonical: null, inputDigits, reason: 'empty_recipient' };
  }

  const digits = inputDigits.startsWith('0055')
    ? inputDigits.slice(2)
    : inputDigits;

  if (digits.length < 10) {
    return { ok: false, canonical: null, inputDigits, reason: 'recipient_too_short' };
  }

  if (digits.length > 13) {
    return { ok: false, canonical: null, inputDigits, reason: 'recipient_too_long' };
  }

  let canonical;
  if (digits.length === 10 || digits.length === 11) {
    if (digits.startsWith('0')) {
      return { ok: false, canonical: null, inputDigits, reason: 'national_recipient_starts_with_zero' };
    }
    canonical = `55${digits}`;
  } else if ((digits.length === 12 || digits.length === 13) && digits.startsWith('55')) {
    canonical = digits;
  } else {
    return { ok: false, canonical: null, inputDigits, reason: 'brazil_country_code_required' };
  }

  if (!canonical.startsWith('55') || (canonical.length !== 12 && canonical.length !== 13)) {
    return { ok: false, canonical: null, inputDigits, reason: 'invalid_canonical_recipient' };
  }

  return { ok: true, canonical, inputDigits };
}
