function normalizeText(value = '') {
  return String(value)
    .trim()
    .toLowerCase()
    .normalize('NFD')
    .replace(/[\u0300-\u036f]/g, '');
}

async function detectLoggedInstagramAccount() {
  try {
    const response = await fetch('/api/v1/accounts/edit/web_form_data/', {
      method: 'GET',
      credentials: 'include',
      headers: {
        'x-ig-app-id': '936619743392459',
        'x-requested-with': 'XMLHttpRequest'
      }
    });

    if (!response.ok) return { ok: true, loggedIn: false, username: null };

    const data = await response.json();
    const username = data?.form_data?.username || data?.username || null;
    return { ok: true, loggedIn: Boolean(username), username };
  } catch (_) {
    return { ok: false, loggedIn: false, username: null, message: 'Erro ao consultar a sessão do Instagram Web.' };
  }
}

function cleanText(value) { return String(value || '').replace(/\s+/g, ' ').trim(); }
function sleep(ms) { return new Promise((resolve) => setTimeout(resolve, ms)); }

function isVisible(el) {
  if (!el) return false;
  const rect = el.getBoundingClientRect();
  const style = window.getComputedStyle(el);
  return rect.width > 0 && rect.height > 0 && style.visibility !== 'hidden' && style.display !== 'none';
}

function humanClick(el) {
  if (!el) return false;
  try {
    el.scrollIntoView({ block: 'center', inline: 'center' });
    el.focus?.();
    const rect = el.getBoundingClientRect();
    const x = rect.left + rect.width / 2;
    const y = rect.top + rect.height / 2;
    for (const type of ['pointerdown','mousedown','pointerup','mouseup','click']) {
      const ev = type.startsWith('pointer')
        ? new PointerEvent(type, { bubbles: true, cancelable: true, pointerType: 'mouse', clientX: x, clientY: y, button: 0 })
        : new MouseEvent(type, { bubbles: true, cancelable: true, clientX: x, clientY: y, button: 0 });
      el.dispatchEvent(ev);
    }
    el.click?.();
    return true;
  } catch (_) {
    try { el.click(); return true; } catch (__) { return false; }
  }
}


function humanClickAt(x, y) {
  const stack = document.elementsFromPoint(x, y);
  for (const raw of stack) {
    const el = clickableFrom(raw);
    if (!el || !isVisible(el)) continue;
    try {
      el.focus?.();
      for (const type of ['pointerdown','mousedown','pointerup','mouseup','click']) {
        const ev = type.startsWith('pointer')
          ? new PointerEvent(type, { bubbles: true, cancelable: true, pointerType: 'mouse', clientX: x, clientY: y, button: 0 })
          : new MouseEvent(type, { bubbles: true, cancelable: true, clientX: x, clientY: y, button: 0 });
        el.dispatchEvent(ev);
      }
      el.click?.();
      return { ok: true, element: el };
    } catch (_) {}
  }
  return { ok: false };
}


async function waitFor(predicate, timeout = 12000, interval = 250) {
  const start = Date.now();
  while (Date.now() - start < timeout) {
    try {
      const value = predicate();
      if (value) return value;
    } catch (_) {}
    await sleep(interval);
  }
  return null;
}

function clickableFrom(el) {
  if (!el) return null;
  return el.closest('button, a, div[role="button"]') || el;
}



function singleClickElement(el) {
  if (!el) return false;
  try {
    el.scrollIntoView({ block: 'center', inline: 'center' });
    el.focus?.();
    const rect = el.getBoundingClientRect();
    const x = rect.left + rect.width / 2;
    const y = rect.top + rect.height / 2;
    for (const type of ['pointerdown','mousedown','pointerup','mouseup','click']) {
      const ev = type.startsWith('pointer')
        ? new PointerEvent(type, { bubbles: true, cancelable: true, pointerType: 'mouse', clientX: x, clientY: y, button: 0 })
        : new MouseEvent(type, { bubbles: true, cancelable: true, clientX: x, clientY: y, button: 0 });
      el.dispatchEvent(ev);
    }
    return true;
  } catch (_) {
    try {
      el.dispatchEvent(new MouseEvent('click', { bubbles: true, cancelable: true }));
      return true;
    } catch (__) {
      return false;
    }
  }
}

function singleClickAt(x, y) {
  const stack = document.elementsFromPoint(x, y);
  for (const raw of stack) {
    const el = clickableFrom(raw);
    if (!el || !isVisible(el)) continue;
    try {
      el.focus?.();
      for (const type of ['pointerdown','mousedown','pointerup','mouseup','click']) {
        const ev = type.startsWith('pointer')
          ? new PointerEvent(type, { bubbles: true, cancelable: true, pointerType: 'mouse', clientX: x, clientY: y, button: 0 })
          : new MouseEvent(type, { bubbles: true, cancelable: true, clientX: x, clientY: y, button: 0 });
        el.dispatchEvent(ev);
      }
      return { ok: true, element: el };
    } catch (_) {}
  }
  return { ok: false };
}

function findButtonByText(patterns) {
  const selectors = [
    'button',
    'div[role="button"]',
    'a[role="button"]',
    'a',
    'span'
  ];
  const all = Array.from(document.querySelectorAll(selectors.join(',')));
  for (const el of all) {
    if (!isVisible(el)) continue;
    const text = cleanText(el.innerText || el.textContent || el.getAttribute('aria-label') || '');
    const aria = cleanText(el.getAttribute('aria-label') || '');
    const value = `${text} ${aria}`.trim();
    if (!value || value.length > 100) continue;
    if (patterns.some((p) => p.test(value))) {
      const clickable = clickableFrom(el);
      if (clickable && isVisible(clickable)) return clickable;
    }
  }
  return null;
}

function findFollowButton() {
  return findButtonByText([/^seguir$/i, /^follow$/i, /^seguir de volta$/i, /^follow back$/i]);
}

function findFollowingStateButton() {
  return findButtonByText([/^seguindo$/i, /^following$/i, /^solicitado$/i, /^requested$/i]);
}

function findMessageProfileButton() {
  return findButtonByText([
    /^mensagem$/i,
    /^message$/i,
    /^enviar mensagem$/i,
    /^send message$/i,
    /enviar mensagem/i,
    /send message/i
  ]);
}

async function getProfileActionState(expectedUsername = '') {
  const expected = normalizeInstagramUsername(expectedUsername);
  if (!expected) return invalidInstagramRecipientResult();
  await waitFor(() => document.body && document.body.innerText && currentProfileUsername(), 8000);
  const profile = currentProfileUsername();
  if (profile !== expected) return { ok:false, expected, profile, recipientMismatch:true, message:`Perfil aberto é @${profile || 'desconhecido'}, mas o lead esperado é @${expected}.` };
  const notFound = isProfileNotFound();
  const privateProfile = isPrivateProfile();
  const body = cleanText(document.body.innerText || '');
  const isOwnProfile = /editar perfil|edit profile/i.test(body);

  await sleep(1200);

  const follow = findFollowButton();
  const following = findFollowingStateButton();
  const message = findMessageProfileButton();

  return {
    ok: true,
    profile,
    private: privateProfile,
    notFound,
    invalidInstagram: notFound || (!profile && !location.pathname.includes('/direct/')),
    ownProfile: isOwnProfile,
    hasFollow: Boolean(follow),
    hasFollowing: Boolean(following),
    hasMessage: Boolean(message),
    actionable: !notFound && !privateProfile && !isOwnProfile && (Boolean(follow) || Boolean(following) || Boolean(message)),
    noFollowAndNoMessage: !notFound && !privateProfile && !isOwnProfile && !follow && !following && !message,
    message: (!notFound && !privateProfile && !isOwnProfile && !follow && !following && !message)
      ? 'Perfil sem botão Seguir/Seguindo e sem botão Mensagem. Lead será invalidado como Outros.'
      : 'Estado do perfil verificado.'
  };
}

function currentProfileUsername() {
  return normalizeInstagramUsername(location.href);
}

function isPrivateProfile() {
  const text = cleanText(document.body.innerText || '');
  return /esta conta é privada|this account is private/i.test(text);
}

function isProfileNotFound() {
  const text = cleanText(document.body.innerText || '');
  return /página não disponível|page isn.?t available|sorry, this page isn.?t available|usuário não encontrado|user not found/i.test(text);
}

function isDirectInbox() {
  return /\/direct\/inbox/i.test(location.pathname || '');
}

async function clickFollowIfNeeded(expectedUsername = '') {
  const expected = normalizeInstagramUsername(expectedUsername);
  if (!expected) return invalidInstagramRecipientResult();
  await waitFor(() => document.body && document.body.innerText && currentProfileUsername(), 8000);
  const current = currentProfileUsername();
  if (current !== expected) return { ok:false, expected, profile:current, recipientMismatch:true, message:`Perfil aberto é @${current || 'desconhecido'}, mas o lead esperado é @${expected}.` };

  if (isProfileNotFound()) {
    return { ok: false, notFound: true, status: 'not_found', message: 'Perfil inexistente/indisponível. Lead deve ser invalidado.' };
  }

  if (isPrivateProfile()) {
    return { ok: false, private: true, status: 'private', message: 'Perfil privado. Não prospectar.' };
  }

  const following = findFollowingStateButton();
  if (following) {
    const text = cleanText(following.innerText || following.textContent || following.getAttribute('aria-label') || '');
    if (/solicitado|requested/i.test(text)) return { ok: false, status: 'requested', message: 'Perfil com solicitação pendente.' };
    return { ok: true, status: 'already_following', message: 'Já está seguindo.' };
  }

  const follow = await waitFor(() => findFollowButton(), 10000);
  if (!follow) return { ok: false, status: 'follow_not_found', message: 'Botão Seguir não encontrado.' };

  const clicked = humanClick(follow);
  if (!clicked) return { ok: false, status: 'follow_click_failed', message: 'Não consegui clicar em Seguir.' };

  const state = await waitFor(() => findFollowingStateButton(), 7000);
  if (state) {
    const text = cleanText(state.innerText || state.textContent || state.getAttribute('aria-label') || '');
    if (/solicitado|requested/i.test(text)) return { ok: false, status: 'requested', message: 'Solicitação de follow enviada. Perfil não será abordado agora.' };
    return { ok: true, status: 'followed', message: 'Perfil seguido com sucesso.' };
  }

  return { ok: false, status: 'follow_unconfirmed', message: 'Clique em Seguir executado, mas o Instagram não confirmou a mudança para Seguindo. Fluxo interrompido por segurança.' };
}



const RESERVED_INSTAGRAM_PATHS = new Set(['about','accounts','api','challenge','contact','developer','direct','directory','download','emails','explore','graphql','invites','legal','oauth','p','press','reel','reels','stories','tv','web']);
const INSTAGRAM_PROFILE_HOSTS = new Set(['instagram.com', 'www.instagram.com']);
function normalizeInstagramUsername(value) {
  const raw = String(value ?? '').trim();
  if (!raw) return '';
  const looksLikeInstagramUrl = /^https?:\/\//i.test(raw) || /^(www\.)?instagram\.com(?:\/|$)/i.test(raw);
  let candidate = raw;
  if (looksLikeInstagramUrl) {
    try {
      const url = new URL(/^https?:\/\//i.test(raw) ? raw : `https://${raw}`);
      if (!INSTAGRAM_PROFILE_HOSTS.has(url.hostname.toLowerCase()) || url.port || url.username || url.password) return '';
      const segments = url.pathname.split('/').filter(Boolean);
      if (segments.length !== 1) return '';
      [candidate] = segments;
    } catch (_) {
      return '';
    }
  } else if (candidate.startsWith('@')) {
    candidate = candidate.slice(1);
  }
  const username = candidate.toLowerCase();
  if (!/^[a-z0-9._]{1,30}$/.test(username) || RESERVED_INSTAGRAM_PATHS.has(username)) return '';
  return username;
}

function invalidInstagramRecipientResult(extra = {}) { return { ok:false, error:'invalid_instagram_recipient_contract', code:'invalid_instagram_recipient_contract', message:'invalid_instagram_recipient_contract', ...extra }; }

async function openDirectMessage(expectedUsername = '') {
  const expected = normalizeInstagramUsername(expectedUsername);
  if (!expected) return invalidInstagramRecipientResult();
  if (isProfileNotFound()) return { ok: false, notFound: true, profile: currentProfileUsername(), message: 'Perfil inexistente/indisponível. DM não será aberta.' };
  if (isPrivateProfile()) return { ok: false, private: true, profile: currentProfileUsername(), message: 'Perfil privado. DM não será aberta.' };

  await waitFor(() => currentProfileUsername(), 8000);
  const current = currentProfileUsername();

  if (!current || ['direct','explore','reels','stories','accounts','p'].includes(current)) {
    return { ok: false, profile: current, message: 'A extensão não está no perfil do lead. Abra o perfil antes de abrir a DM.' };
  }

  if (current !== expected) {
    return {
      ok: false,
      profile: current,
      expected,
      message: `Perfil aberto é @${current}, mas o lead esperado é @${expected}. A DM não será aberta.`
    };
  }

  const body = cleanText(document.body.innerText || '');
  const isOwnProfile = /editar perfil|edit profile/i.test(body);
  if (isOwnProfile) {
    return { ok: false, profile: current, ownProfile: true, message: 'Estou no seu próprio perfil. Abra o perfil do lead e tente novamente.' };
  }

  // Importante: NÃO clicar em links /direct/inbox. Isso abre a inbox geral.
  // A DM correta deve ser aberta pelo botão Mensagem do perfil do lead.
  const btn = await waitFor(() => findMessageProfileButton(), 12000);

  if (!btn) {
    return { ok: false, profile: current, message: 'Botão Mensagem não encontrado no perfil do lead.' };
  }

  humanClick(btn);

  const opened = await waitFor(() => {
    const path = location.pathname || '';
    const box = findMessageBox();
    if (path.includes('/direct/inbox')) return 'inbox';
    if (path.includes('/direct/t/') || path.includes('/direct/')) return 'direct';
    if (box) return 'box';
    return null;
  }, 12000, 300);

  if (opened === 'inbox') {
    return { ok: false, profile: current, message: 'Instagram abriu a inbox geral, não a DM do lead. Parei para evitar envio no lugar errado.' };
  }

  if (!opened) {
    return { ok: false, profile: current, message: 'Cliquei em Mensagem, mas a DM do lead não abriu.' };
  }

  const safety = await waitFor(() => {
    const state = getDirectSafetyState(expected || current);
    return state.ok ? state : null;
  }, 10000, 350);
  if (!safety) {
    const state = getDirectSafetyState(expected || current);
    return { ok:false, profile:current, ...state };
  }
  return { ok: true, profile: current, recipients:safety.recipients, message: `DM do perfil @${current} aberta e destinatário confirmado.` };
}

function directMessageRoot() {
  const box = findMessageBox();
  if (!box) return null;
  const roots = [];
  let node = box;
  while (node && node !== document.body) {
    if (node.matches?.('div[role="dialog"], section, main, article')) roots.push(node);
    node = node.parentElement;
  }
  roots.push(document.body);
  const unique = roots.filter((el, index, arr) => el && arr.indexOf(el) === index && isVisible(el));
  if (!unique.length) return null;
  return unique.sort((a, b) => {
    const ar = a.getBoundingClientRect();
    const br = b.getBoundingClientRect();
    const aArea = ar.width * ar.height;
    const bArea = br.width * br.height;
    const aDialog = a.getAttribute?.('role') === 'dialog' ? 100000000 : 0;
    const bDialog = b.getAttribute?.('role') === 'dialog' ? 100000000 : 0;
    // Prefere o menor painel visível que contém o composer, normalmente a janela flutuante da DM.
    return (aDialog + (1 / Math.max(1, aArea))) - (bDialog + (1 / Math.max(1, bArea)));
  }).at(-1) || unique[0];
}

function labelOfClickable(el) {
  return cleanText([
    el?.innerText,
    el?.textContent,
    el?.getAttribute?.('aria-label'),
    el?.getAttribute?.('title'),
    el?.querySelector?.('title')?.textContent,
    el?.querySelector?.('[aria-label]')?.getAttribute?.('aria-label')
  ].filter(Boolean).join(' '));
}

function findDmCloseButton() {
  const root = directMessageRoot();
  if (!root) return null;
  const rootRect = root.getBoundingClientRect();
  const candidates = Array.from(root.querySelectorAll('button, div[role="button"], a[role="button"], [aria-label]'))
    .map((el) => clickableFrom(el))
    .filter((el, index, arr) => el && arr.indexOf(el) === index && isVisible(el));

  const explicit = candidates.find((el) => {
    const label = labelOfClickable(el);
    if (!/(^|\b)(fechar|close|dismiss|sair|encerrar)(\b|$)/i.test(label)) return false;
    const r = el.getBoundingClientRect();
    // Evita fechar preview de imagem, menu ou outro modal longe do cabeçalho da conversa.
    return r.top <= rootRect.top + Math.max(90, rootRect.height * 0.22) && r.left >= rootRect.left + rootRect.width * 0.55;
  });
  if (explicit) return explicit;

  // Fallback visual: no layout flutuante do Instagram, o X fica no topo direito do painel da DM.
  const headerCandidates = candidates
    .map((el) => ({ el, rect: el.getBoundingClientRect(), label: labelOfClickable(el) }))
    .filter(({ el, rect, label }) => {
      if (!isVisible(el)) return false;
      if (rect.width < 12 || rect.height < 12 || rect.width > 90 || rect.height > 90) return false;
      if (rect.top > rootRect.top + Math.max(90, rootRect.height * 0.22)) return false;
      if (rect.left < rootRect.left + rootRect.width * 0.62) return false;
      if (/enviar|send|mensagem|message|foto|photo|imagem|image|emoji|microfone|microphone|sticker|figurinha|mais opções|more options|info/i.test(label)) return false;
      return true;
    })
    .sort((a, b) => (b.rect.right - a.rect.right) || (a.rect.top - b.rect.top));
  return headerCandidates[0]?.el || null;
}

async function closeDirectMessageWindow() {
  await sleep(900);
  const beforeBox = findMessageBox();
  if (!beforeBox) return { ok: true, closed: false, message: 'Nenhuma janela de DM aberta para fechar.' };
  const button = await waitFor(() => findDmCloseButton(), 5000, 250);
  if (!button) return { ok: false, closed: false, message: 'Não encontrei o botão X da janela da DM.' };
  singleClickElement(button);
  const closed = await waitFor(() => !findMessageBox(), 5000, 250);
  return closed
    ? { ok: true, closed: true, message: 'Janela da DM fechada após confirmação do envio.' }
    : { ok: false, closed: false, message: 'Cliquei no X, mas a janela da DM continuou aberta.' };
}

function findMessageBox() {
  // Instagram usa um composer contenteditable controlado por React. Sempre
  // relocalizamos o campo atual, priorizando o composer visível mais baixo da tela.
  const candidates = Array.from(document.querySelectorAll('[contenteditable="true"], textarea, div[role="textbox"]'))
    .filter((el) => {
      if (!isVisible(el)) return false;
      const rect = el.getBoundingClientRect();
      if (rect.width < 80 || rect.height < 18) return false;
      const aria = cleanText(el.getAttribute('aria-label') || '');
      const placeholder = cleanText(el.getAttribute('placeholder') || '');
      const role = cleanText(el.getAttribute('role') || '');
      const label = `${aria} ${placeholder} ${role}`;
      const text = cleanText(el.innerText || el.textContent || '');
      // Evita selecionar áreas grandes de conversa/mensagens antigas.
      if (text.length > 5000) return false;
      return /mensagem|message|digite|write|texto|textbox/i.test(label) || el.isContentEditable || el.tagName === 'TEXTAREA';
    });

  if (!candidates.length) return null;

  function score(el) {
    const rect = el.getBoundingClientRect();
    const aria = cleanText(el.getAttribute('aria-label') || '');
    const placeholder = cleanText(el.getAttribute('placeholder') || '');
    let value = 0;
    if (/mensagem|message|digite|write/i.test(`${aria} ${placeholder}`)) value += 1000;
    if (el.closest('div[role="dialog"]')) value += 500;
    if (el.getAttribute('role') === 'textbox') value += 300;
    // Composer da DM fica no rodapé da janela/modal.
    value += Math.max(0, rect.bottom);
    // Penaliza elementos gigantes que não parecem campo de input.
    if (rect.height > 220) value -= 500;
    return value;
  }

  return candidates.sort((a, b) => score(b) - score(a))[0] || null;
}

async function clickSendButton() {
  await sleep(450);

  const box = findMessageBox();
  if (!box) return { ok: false, message: 'Campo da DM não encontrado para enviar.' };

  const root = box.closest('div[role="dialog"], section, main') || document;
  const boxRect = box.getBoundingClientRect();

  function unique(list) {
    const out = [];
    const seen = new Set();
    for (const item of list) {
      if (!item || seen.has(item)) continue;
      seen.add(item);
      out.push(item);
    }
    return out;
  }

  function labelOf(el) {
    return cleanText([
      el.innerText,
      el.textContent,
      el.getAttribute?.('aria-label'),
      el.getAttribute?.('title')
    ].filter(Boolean).join(' '));
  }

  function isBadSendCandidate(el) {
    const text = labelOf(el);
    return /emoji|gif|sticker|figurinha|foto|photo|imagem|image|anexo|attach|microfone|microphone|like|curtir|mais opções|more options|voltar|back|perfil|profile/i.test(text);
  }

  async function clickedAndEmptied(label, clickFn) {
    clickFn();
    const emptied = await waitUntilBoxReadyForNext(4500);
    if (emptied) return { ok: true, message: label };
    return null;
  }

  // 1) Botões textuais/aria claramente de envio.
  const explicitList = unique(Array.from(root.querySelectorAll('button, div[role="button"], a[role="button"], [aria-label]'))
    .map((el) => clickableFrom(el)))
    .filter((el) => el && isVisible(el) && !isBadSendCandidate(el))
    .filter((el) => /^(enviar|send)$/i.test(labelOf(el)) || /\b(enviar|send)\b/i.test(labelOf(el)));

  for (const btn of explicitList) {
    const res = await clickedAndEmptied('Mensagem enviada pelo botão Enviar.', () => singleClickElement(btn));
    if (res) return res;
  }

  // 2) Fallback por coordenadas: clicar exatamente na área à direita do campo da DM,
  // onde fica o botão azul/paper-plane. Isso evita pegar inbox geral ou botões errados.
  const yPoints = [
    boxRect.top + boxRect.height / 2,
    boxRect.bottom - Math.min(18, boxRect.height / 3),
    boxRect.top + Math.min(18, boxRect.height / 3)
  ];
  const maxX = Math.min(window.innerWidth - 12, boxRect.right + 220);
  const minX = Math.max(boxRect.left + 80, boxRect.right - 8);
  const xPoints = [];
  for (let x = maxX; x >= minX; x -= 10) xPoints.push(x);

  for (const y of yPoints) {
    for (const x of xPoints) {
      const stack = document.elementsFromPoint(x, y);
      const target = stack.map((raw) => clickableFrom(raw)).find((el) => {
        if (!el || !isVisible(el) || el === box || el.contains(box)) return false;
        if (isBadSendCandidate(el)) return false;
        const r = el.getBoundingClientRect();
        if (r.width < 16 || r.height < 16) return false;
        // precisa estar perto da linha do campo e à direita do texto
        return r.bottom >= boxRect.top - 8 && r.top <= boxRect.bottom + 12 && r.left >= boxRect.left + 90;
      });
      if (target) {
        const res = await clickedAndEmptied('Mensagem enviada pelo botão visual.', () => {
          const r = target.getBoundingClientRect();
          singleClickAt(r.left + r.width / 2, r.top + r.height / 2);
        });
        if (res) return res;
      }
    }
  }

  // 3) Fallback: Enter real. No Instagram Web normalmente Enter envia a DM.
  box.focus();
  placeCaretAtEnd(box);
  for (const type of ['keydown', 'keypress', 'keyup']) {
    box.dispatchEvent(new KeyboardEvent(type, {
      bubbles: true,
      cancelable: true,
      key: 'Enter',
      code: 'Enter',
      keyCode: 13,
      which: 13
    }));
  }
  const emptiedByEnter = await waitUntilBoxReadyForNext(4500);
  if (emptiedByEnter) return { ok: true, message: 'Mensagem enviada via Enter.' };

  return { ok: false, message: 'Não consegui clicar no botão Enviar. A mensagem ficou no campo da DM.' };
}

function normalizeForCompare(value) {
  return String(value || '')
    .replace(/\r/g, '')
    .replace(/\u00a0/g, ' ')
    .replace(/[ \t]+/g, ' ')
    .replace(/\n[ \t]+/g, '\n')
    .trim();
}

function getBoxText(el) {
  if (!el) return '';
  if (el.tagName === 'TEXTAREA' || el.tagName === 'INPUT') return String(el.value || '');
  return String(el.innerText || el.textContent || '');
}

async function hardClearMessageBox(el) {
  if (!el) return false;

  for (let attempt = 0; attempt < 4; attempt++) {
    try { el.focus(); } catch (_) {}

    try {
      const selection = window.getSelection();
      const range = document.createRange();
      range.selectNodeContents(el);
      selection.removeAllRanges();
      selection.addRange(range);
      document.execCommand('delete', false, null);
      selection.removeAllRanges();
    } catch (_) {}

    try {
      if (el.tagName === 'TEXTAREA' || el.tagName === 'INPUT') {
        const proto = Object.getPrototypeOf(el);
        const desc = Object.getOwnPropertyDescriptor(proto, 'value');
        if (desc?.set) desc.set.call(el, ''); else el.value = '';
      } else if (cleanText(getBoxText(el)).length) {
        // Último recurso: só limpa se ainda houver texto no composer.
        el.replaceChildren();
      }
    } catch (_) {}

    try {
      el.dispatchEvent(new InputEvent('input', {
        bubbles: true,
        cancelable: true,
        inputType: 'deleteContentBackward',
        data: null
      }));
    } catch (_) {
      try { el.dispatchEvent(new Event('input', { bubbles: true })); } catch (_) {}
    }

    await sleep(250);
    if (cleanText(getBoxText(el)).length === 0) return true;
  }

  return cleanText(getBoxText(el)).length === 0;
}

function placeCaretAtEnd(el) {
  try {
    const range = document.createRange();
    range.selectNodeContents(el);
    range.collapse(false);
    const selection = window.getSelection();
    selection.removeAllRanges();
    selection.addRange(range);
  } catch (_) {}
}

async function insertTextOnce(el, text) {
  const original = String(text || '').trim();
  if (!original) return false;
  const expected = normalizeForCompare(original);

  function escapeHtml(value) {
    return String(value || '')
      .replace(/&/g, '&amp;')
      .replace(/</g, '&lt;')
      .replace(/>/g, '&gt;');
  }

  async function clearComposer(target) {
    if (!target) return false;
    for (let attempt = 0; attempt < 6; attempt++) {
      try { target.focus(); } catch (_) {}
      await sleep(80);

      // Ctrl+A / Backspace primeiro, pois é o caminho que o React do Instagram entende melhor.
      try {
        for (const ev of ['keydown', 'keyup']) {
          target.dispatchEvent(new KeyboardEvent(ev, { bubbles:true, cancelable:true, key:'a', code:'KeyA', ctrlKey:true, keyCode:65, which:65 }));
        }
        target.dispatchEvent(new KeyboardEvent('keydown', { bubbles:true, cancelable:true, key:'Backspace', code:'Backspace', keyCode:8, which:8 }));
        target.dispatchEvent(new KeyboardEvent('keyup', { bubbles:true, cancelable:true, key:'Backspace', code:'Backspace', keyCode:8, which:8 }));
      } catch (_) {}

      try {
        const sel = window.getSelection();
        const range = document.createRange();
        range.selectNodeContents(target);
        sel.removeAllRanges();
        sel.addRange(range);
        document.execCommand('delete', false, null);
        sel.removeAllRanges();
      } catch (_) {}

      try {
        if (target.tagName === 'TEXTAREA' || target.tagName === 'INPUT') {
          const proto = Object.getPrototypeOf(target);
          const desc = Object.getOwnPropertyDescriptor(proto, 'value');
          if (desc?.set) desc.set.call(target, ''); else target.value = '';
        } else {
          target.textContent = '';
        }
      } catch (_) {}

      try { target.dispatchEvent(new InputEvent('input', { bubbles:true, cancelable:true, inputType:'deleteContentBackward', data:null })); }
      catch (_) { try { target.dispatchEvent(new Event('input', { bubbles:true })); } catch (_) {} }

      await sleep(220);
      const current = normalizeForCompare(getBoxText(target));
      if (!current) return true;

      // Se o Instagram recriou o composer, use o novo na próxima tentativa.
      const fresh = findMessageBox();
      if (fresh && fresh !== target) target = fresh;
    }
    return !normalizeForCompare(getBoxText(target));
  }

  function makePasteEvent(value) {
    const dt = new DataTransfer();
    dt.setData('text/plain', value);
    return new ClipboardEvent('paste', { bubbles:true, cancelable:true, clipboardData: dt });
  }

  async function pasteInto(target) {
    try { target.focus(); } catch (_) {}
    placeCaretAtEnd(target);
    await sleep(120);

    // Método principal: evento paste único. Não combinar com insertText no mesmo ciclo,
    // porque isso foi a causa das mensagens duplicadas/concatenadas.
    try {
      const ev = makePasteEvent(original);
      const accepted = target.dispatchEvent(ev);
      await sleep(700);
      let got = normalizeForCompare(getBoxText(target));
      if (got === expected) return true;
    } catch (_) {}

    // Fallback 1: insertHTML com <br>, uma única vez.
    try {
      await clearComposer(target);
      target = findMessageBox() || target;
      target.focus();
      placeCaretAtEnd(target);
      const html = escapeHtml(original).replace(/\n/g, '<br>');
      document.execCommand('insertHTML', false, html);
      try { target.dispatchEvent(new InputEvent('input', { bubbles:true, cancelable:true, inputType:'insertText', data: original })); }
      catch (_) { try { target.dispatchEvent(new Event('input', { bubbles:true })); } catch (_) {} }
      await sleep(800);
      let got = normalizeForCompare(getBoxText(target));
      if (got === expected) return true;
    } catch (_) {}

    // Fallback 2: insertText, uma única vez. Não disparar input manual com data depois.
    try {
      await clearComposer(target);
      target = findMessageBox() || target;
      target.focus();
      placeCaretAtEnd(target);
      document.execCommand('insertText', false, original);
      await sleep(800);
      let got = normalizeForCompare(getBoxText(target));
      if (got === expected) return true;
    } catch (_) {}

    return false;
  }

  // Até duas tentativas completas. Se detectar qualquer sobra/concatenação, limpa tudo antes de tentar novamente.
  for (let attempt = 0; attempt < 2; attempt++) {
    el = findMessageBox() || el;
    if (!el) return false;

    const cleared = await clearComposer(el);
    if (!cleared) {
      await sleep(600);
      el = findMessageBox() || el;
      await clearComposer(el);
    }

    const ok = await pasteInto(el);
    if (ok) return true;

    // Não manda texto se a validação não bateu. Limpa para não deixar lixo no campo.
    el = findMessageBox() || el;
    await clearComposer(el);
    await sleep(500);
  }

  return false;
}
async function waitUntilBoxReadyForNext(timeout = 9000) {
  return await waitFor(() => {
    const box = findMessageBox();
    if (!box) return null;
    const current = cleanText(getBoxText(box));
    return current.length === 0 ? box : null;
  }, timeout, 250);
}

async function waitForTextSendLock(maxWait = 30000) {
  const start = Date.now();
  while (window.__crmInstagramSendingText) {
    const age = Date.now() - Number(window.__crmInstagramSendingStartedAt || 0);

    // Trava antiga/stale: limpa automaticamente. Não transformar isso em erro operacional.
    if (!window.__crmInstagramSendingStartedAt || age > 60000) {
      window.__crmInstagramSendingText = false;
      window.__crmInstagramSendingStartedAt = 0;
      break;
    }

    if (Date.now() - start > maxWait) {
      // Em vez de parar o lote, limpa a trava velha e deixa a etapa atual tentar seguir.
      window.__crmInstagramSendingText = false;
      window.__crmInstagramSendingStartedAt = 0;
      break;
    }

    await sleep(250);
  }
}

async function pasteTextIntoDm(text, send = false, expectedUsername = '') {
  if (!normalizeInstagramUsername(expectedUsername)) return invalidInstagramRecipientResult();
  await waitForTextSendLock(30000);

  const now = Date.now();
  const token = `${now}-${Math.random().toString(16).slice(2)}`;
  window.__crmInstagramSendingText = true;
  window.__crmInstagramSendingStartedAt = now;
  window.__crmInstagramSendingToken = token;

  try {
    const safetyBefore = getDirectSafetyState(expectedUsername);
    if (!safetyBefore.ok) return safetyBefore;
    const original = String(text || '').trim();
    if (!original) return { ok: false, message: 'Mensagem vazia.' };

    const expectedNow = normalizeForCompare(original);
    if (window.__crmInstagramLastSentText === expectedNow && window.__crmInstagramLastSentAt && Date.now() - window.__crmInstagramLastSentAt < 12000) {
      return { ok: true, message: 'Mensagem já tinha sido enviada agora. Evitei duplicar.' };
    }

    let box = await waitFor(() => findMessageBox(), 12000);
    if (!box) return { ok: false, message: 'Campo de mensagem não encontrado. Abra a DM e tente novamente.' };

    await hardClearMessageBox(box);
    const inserted = await insertTextOnce(box, original);
    await sleep(500);

    let after = cleanText(getBoxText(box));

    // Se falhou, relocaliza o composer e tenta UMA vez.
    // Não validar duplicidade por tamanho: o Instagram/React pode expor texto
    // do composer de forma inconsistente. A confirmação real será o campo
    // esvaziar após clicar em Enviar.
    if (!inserted || !after) {
      await sleep(1200);
      box = await waitFor(() => findMessageBox(), 10000);
      if (!box) return { ok: false, message: 'Campo da DM não reapareceu para nova tentativa.' };

      await hardClearMessageBox(box);
      const retryInserted = await insertTextOnce(box, original);
      await sleep(500);
      after = cleanText(getBoxText(box));

      if (!retryInserted || !after) {
        return { ok: false, message: 'Não consegui inserir a mensagem no campo da DM.' };
      }
    }

    if (send) {
      const safetyAtSend = getDirectSafetyState(expectedUsername);
      if (!safetyAtSend.ok) return safetyAtSend;
      const sent = await clickSendButton();
      if (!sent?.ok) return sent;
      const emptied = await waitUntilBoxReadyForNext(9000);
      if (!emptied) {
        return { ok: false, message: 'Cliquei para enviar, mas o campo não esvaziou. A mensagem pode não ter sido enviada.' };
      }
      const safetyAfter = getDirectSafetyState(expectedUsername);
      if (!safetyAfter.ok) return { ...safetyAfter, uncertain:true, message:'O campo esvaziou, mas a confirmação do destinatário se perdeu após o clique. Resultado incerto.' };
      window.__crmInstagramLastSentText = expectedNow;
      window.__crmInstagramLastSentAt = Date.now();
      return { ok: true, message: 'Mensagem enviada uma única vez.' };
    }

    return { ok: true, message: 'Mensagem colada uma única vez. Revise e envie manualmente.' };
  } finally {
    if (window.__crmInstagramSendingToken === token) {
      window.__crmInstagramSendingText = false;
      window.__crmInstagramSendingStartedAt = 0;
      window.__crmInstagramSendingToken = null;
    }
  }
}


function uncertainImageUploadResult(message, details = {}) {
  return {
    ...details,
    ok: false,
    mediaConfirmed: false,
    uncertain: true,
    doNotFallback: true,
    fallbackAllowed: false,
    message
  };
}

async function uploadImageFileToDm(payload = {}, send = true, expectedUsername = '') {
  if (!normalizeInstagramUsername(expectedUsername)) return invalidInstagramRecipientResult({ mediaConfirmed:false, doNotFallback:true, fallbackAllowed:false });
  const dataUrl = payload.dataUrl || '';
  const bytes = payload.bytes;
  const name = payload.name || 'imagem-ramo.png';
  const type = payload.type || payload.mimeType || 'image/png';
  const maxBytes = 8 * 1024 * 1024;

  if (window.__crmInstagramImageUploadRunning) {
    // v40: chamada duplicada durante o mesmo envio não deve pausar o lote.
    // Isso pode acontecer quando o popup/content dispara a rotina de mídia duas vezes.
    // Em vez de erro, aguardamos a rotina atual terminar e reutilizamos o resultado recente.
    await waitFor(() => !window.__crmInstagramImageUploadRunning, 65000, 500);
    if (window.__crmInstagramLastImageUploadConfirmedAt && Date.now() - window.__crmInstagramLastImageUploadConfirmedAt < 90000) {
      return { ok: true, mediaConfirmed: true, message: 'Imagem já havia sido enviada nesta etapa. Chamada duplicada ignorada com segurança.' };
    }
    return uncertainImageUploadResult('Já existia um envio de imagem em andamento e não consegui confirmar o resultado recente.');
  }
  window.__crmInstagramImageUploadRunning = true;
  let uploadPhase = 'before_effect';

  try {
    const safetyBefore = getDirectSafetyState(expectedUsername);
    if (!safetyBefore.ok) return { ...safetyBefore, mediaConfirmed:false, doNotFallback:true };
    if (!dataUrl && !bytes) return { ok: false, mediaConfirmed: false, fallbackAllowed:true, message: 'Imagem não recebida pela extensão.' };

    const box = await waitFor(() => findMessageBox(), 12000);
    if (!box) return { ok: false, mediaConfirmed: false, doNotFallback:true, message: 'Campo de mensagem não encontrado para enviar imagem.' };
    try { box.focus(); } catch (_) {}

    function safeText(el) {
      try {
        return cleanText([
          el?.innerText,
          el?.textContent,
          el?.getAttribute?.('aria-label'),
          el?.getAttribute?.('title'),
          el?.getAttribute?.('data-testid')
        ].filter(Boolean).join(' '));
      } catch (_) { return ''; }
    }

    function getDmRoot() {
      return box.closest('div[role="dialog"], section, main') || document;
    }

    function getSearchRoots() {
      const roots = [getDmRoot(), document];
      for (const el of Array.from(document.querySelectorAll('div[role="dialog"], section, main, article'))) {
        if (isVisible(el)) roots.push(el);
      }
      return roots.filter((el, idx, arr) => el && arr.indexOf(el) === idx);
    }

    function mediaSignature(el) {
      if (!el) return '';
      const tag = String(el.tagName || '').toLowerCase();
      if (tag === 'canvas') {
        const r = el.getBoundingClientRect?.();
        return `canvas:${Math.round(r?.left||0)}:${Math.round(r?.top||0)}:${Math.round(r?.width||0)}x${Math.round(r?.height||0)}`;
      }
      const src = String(el.currentSrc || el.src || el.getAttribute?.('src') || '');
      if (src) return `${tag}:${src}`;
      const bg = window.getComputedStyle(el).backgroundImage || '';
      return bg && bg !== 'none' ? `${tag}:bg:${bg}` : '';
    }

    function getVisibleMediaElements() {
      const selector = 'img, video, canvas, [style*="background-image"]';
      return Array.from(document.querySelectorAll(selector)).filter((el) => {
        if (!isVisible(el)) return false;
        const r = el.getBoundingClientRect?.();
        if (!r || r.width < 40 || r.height < 40) return false;
        const sig = mediaSignature(el);
        return !!sig;
      });
    }

    function getMediaSignatures() {
      return new Set(getVisibleMediaElements().map(mediaSignature).filter(Boolean));
    }

    function getNewMedia(beforeSignatures) {
      return getVisibleMediaElements().filter((el) => {
        const sig = mediaSignature(el);
        return sig && !beforeSignatures.has(sig);
      }).sort((a, b) => {
        const ra = a.getBoundingClientRect?.();
        const rb = b.getBoundingClientRect?.();
        const aa = (ra?.width || 0) * (ra?.height || 0);
        const ab = (rb?.width || 0) * (rb?.height || 0);
        return ab - aa;
      });
    }

    function findUploadPreviewRoot(newMedia) {
      const media = newMedia || getVisibleMediaElements()[0];
      if (!media) return null;
      let node = media;
      let best = media.parentElement || media;
      for (let i = 0; i < 8 && node && node !== document.body; i++) {
        const txt = safeText(node);
        const hasSend = /\b(enviar|send)\b/i.test(txt) || !!node.querySelector?.('button, div[role="button"]');
        const rect = node.getBoundingClientRect?.();
        if (rect && rect.width >= 120 && rect.height >= 80) best = node;
        if (hasSend && rect && rect.width >= 160 && rect.height >= 120) return node;
        node = node.parentElement;
      }
      return best || document;
    }

    function makeDataTransfer(file) {
      const dt = new DataTransfer();
      dt.items.add(file);
      return dt;
    }

    async function pasteFileOnceAndWait(file, beforeSignatures) {
      // v39: fonte única de upload.
      // Não usamos input + paste + drop, porque o Instagram pode processar eventos atrasados
      // e acabar criando 2 previews. O fluxo que funcionou no navegador foi Ctrl+C/Ctrl+V;
      // então simulamos apenas UM paste no composer.
      const dt = makeDataTransfer(file);
      try { box.focus(); } catch (_) {}

      let ev;
      try {
        ev = new ClipboardEvent('paste', { bubbles: true, cancelable: true, clipboardData: dt });
        try { Object.defineProperty(ev, 'clipboardData', { value: dt }); } catch (_) {}
      } catch (_) {
        ev = new Event('paste', { bubbles: true, cancelable: true });
        try { Object.defineProperty(ev, 'clipboardData', { value: dt }); } catch (_) {}
      }

      uploadPhase = 'preview_attempted';
      box.dispatchEvent(ev);

      const media = await waitFor(() => {
        const found = getNewMedia(beforeSignatures);
        return found[0] || null;
      }, 20000, 250);

      return media || null;
    }

    async function clickPreviewSendButton(previewRoot, newMedia) {
      const mediaRect = newMedia?.getBoundingClientRect?.() || null;
      const roots = [previewRoot, ...getSearchRoots(), document].filter((el, idx, arr) => el && arr.indexOf(el) === idx);
      const candidates = [];

      for (const area of roots) {
        for (const raw of Array.from(area.querySelectorAll('button, div[role="button"], [aria-label]'))) {
          const el = clickableFrom(raw);
          if (!el || !isVisible(el)) continue;
          const label = safeText(el);
          const r = el.getBoundingClientRect();
          let score = 0;
          if (/^(enviar|send)$/i.test(label)) score += 2000;
          if (/\b(enviar|send)\b/i.test(label)) score += 1200;
          if (previewRoot && previewRoot !== document && previewRoot.contains(el)) score += 600;
          if (mediaRect && r.top >= mediaRect.top - 80 && r.bottom <= mediaRect.bottom + 180) score += 250;
          if (r.width >= 35 && r.height >= 24 && r.width <= 220 && r.height <= 90) score += 120;
          if (/emoji|sticker|figurinha|microfone|microphone|foto|photo|imagem|image|anexo|attach|voltar|back|fechar|close|crop|recortar|editar|edit/i.test(label)) score -= 1000;
          if (score > 0) candidates.push({ el, score, label });
        }
      }

      candidates.sort((a,b) => b.score - a.score);
      if (candidates[0]) {
        singleClickElement(candidates[0].el);
        return true;
      }

      const rect = (previewRoot && previewRoot !== document ? previewRoot : document.body).getBoundingClientRect();
      const points = [
        [Math.min(window.innerWidth - 24, rect.right - 48), Math.min(window.innerHeight - 24, rect.bottom - 36)],
        [Math.min(window.innerWidth - 24, rect.right - 80), Math.min(window.innerHeight - 24, rect.bottom - 56)],
        [window.innerWidth - 72, window.innerHeight - 72]
      ];

      for (const [x, y] of points) {
        const clicked = singleClickAt(x, y);
        if (clicked?.ok) return true;
      }
      return false;
    }

    let file;
    if (dataUrl) {
      const blob = await fetch(dataUrl).then(r => r.blob());
      file = new File([blob], name, { type: blob.type || type || 'image/png' });
    } else {
      const array = bytes instanceof ArrayBuffer ? bytes : new Uint8Array(bytes).buffer;
      file = new File([array], name, { type });
    }

    if (!/^image\/(png|jpe?g|webp)$/i.test(file.type || type || '')) {
      return { ok: false, mediaConfirmed: false, fallbackAllowed:true, message: `Formato de imagem não permitido: ${file.type || type || 'sem tipo'}.` };
    }
    if (file.size > maxBytes) {
      return { ok:false, mediaConfirmed:false, fallbackAllowed:true, message:'Imagem acima de 8 MB.' };
    }

    const beforeMediaSignatures = getMediaSignatures();
    const confirmedMedia = await pasteFileOnceAndWait(file, beforeMediaSignatures);

    if (!confirmedMedia) {
      return uncertainImageUploadResult('O evento de upload foi disparado, mas o preview não pôde ser confirmado. Revisão manual necessária.', { uploadPhase });
    }

    // Guarda extra contra duplicação: após o primeiro preview, não executa nenhum fallback.
    // Se aparecer mais de um preview por algum motivo interno do Instagram, envia apenas o preview confirmado.
    uploadPhase = 'preview_created';
    const previewRoot = findUploadPreviewRoot(confirmedMedia);

    if (!send) return { ok: true, mediaConfirmed: false, message: 'Imagem anexada na DM.' };

    uploadPhase = 'click_attempted';
    const clicked = await clickPreviewSendButton(previewRoot, confirmedMedia);
    if (!clicked) return uncertainImageUploadResult('Preview apareceu, mas o botão Enviar não foi confirmado. Revisão manual necessária.', { uploadPhase });
    uploadPhase = 'clicked';

    const srcToWatch = mediaSignature(confirmedMedia);

    // v44: o Instagram pode manter a mesma imagem visível depois do clique porque
    // ela deixou de ser preview e virou a mídia enviada no histórico da conversa.
    // Por isso, NÃO usamos mais "imagem ainda visível" como falha automática.
    // Primeiro tentamos a confirmação forte: preview sumiu. Se não sumir, esperamos
    // mais tempo e aceitamos como confirmação suave quando não houver erro visível.
    const strongSent = await waitFor(() => {
      const stillThere = getVisibleMediaElements().some((el) => {
        const sig = mediaSignature(el);
        return sig && sig === srcToWatch && isVisible(el);
      });
      if (!stillThere) return true;
      return null;
    }, 90000, 500);

    if (!strongSent) {
      const pageText = safeText(document.body);
      const visibleError = /falha|erro|failed|couldn.?t|não foi possível|nao foi possivel|tente novamente|try again/i.test(pageText);
      return uncertainImageUploadResult(
        visibleError
          ? 'O Instagram exibiu erro após o clique de envio da imagem. Revisão manual necessária.'
          : 'O envio da imagem não pôde ser confirmado com segurança. Nenhum fallback será enviado para evitar duplicidade.',
        {
          uploadPhase,
          visibleError,
        }
      );
    }

    const safetyAfter = getDirectSafetyState(expectedUsername);
    if (!safetyAfter.ok) return uncertainImageUploadResult('A imagem parece ter sido enviada, mas o destinatário não pôde ser reconfirmado.', { ...safetyAfter, uploadPhase });
    window.__crmInstagramLastImageUploadConfirmedAt = Date.now();
    return { ok: true, mediaConfirmed: true, recipients:safetyAfter.recipients, message: 'Imagem enviada e confirmada. Estratégia usada: paste único.' };
  } catch (err) {
    const message = `Erro ao enviar imagem: ${err?.message || err}`;
    if (uploadPhase === 'before_effect') return { ok: false, mediaConfirmed: false, fallbackAllowed:true, message };
    return uncertainImageUploadResult(message, { uploadPhase });
  } finally {
    window.__crmInstagramImageUploadRunning = false;
  }
}


function getDmBlockReason() {
  const text = normalizeText(document.body?.innerText || '');
  const patterns = [
    /voce nao pode enviar mensagem para esta conta/i,
    /você não pode enviar mensagem para esta conta/i,
    /nao pode enviar mensagem para esta conta/i,
    /não pode enviar mensagem para esta conta/i,
    /esta conta nao aceita mensagens/i,
    /esta conta não aceita mensagens/i,
    /somente pessoas.*segu.*podem enviar/i,
    /apenas pessoas.*segu.*podem enviar/i,
    /nao e possivel enviar mensagem/i,
    /não é possível enviar mensagem/i,
    /you can.t message this account/i,
    /you cannot message this account/i,
    /this account can.t receive messages/i,
    /only people.*follow.*message/i
  ];
  for (const pattern of patterns) {
    if (pattern.test(text)) return 'DM bloqueada: conta não permite mensagens de quem ela não segue.';
  }
  return '';
}

function dmRecipientCandidates() {
  const root = directMessageRoot();
  if (!root) return [];
  const rootRect = root.getBoundingClientRect();
  const maxTop = rootRect.top + Math.max(170, rootRect.height * 0.28);
  const reserved = new Set(['direct','explore','reels','stories','accounts','p','about','legal','web']);
  const values = new Set();

  for (const anchor of Array.from(root.querySelectorAll('a[href]'))) {
    if (!isVisible(anchor)) continue;
    const rect = anchor.getBoundingClientRect();
    if (rect.top > maxTop) continue;
    let pathname = '';
    try { pathname = new URL(anchor.href, location.origin).pathname; } catch (_) { continue; }
    const parts = pathname.split('/').filter(Boolean);
    if (parts.length !== 1) continue;
    const username = normalizeInstagramUsername(parts[0]);
    if (!username || reserved.has(username)) continue;
    values.add(username);
  }

  return [...values];
}

function getDirectSafetyState(expectedUsername = '') {
  const expected = normalizeInstagramUsername(expectedUsername || '');
  const path = location.pathname || '';
  const box = findMessageBox();
  const blockReason = getDmBlockReason();
  if (!expected) return invalidInstagramRecipientResult({ expected, path });
  if (isDirectInbox()) return { ok:false, expected, path, message:'Instagram está em /direct/inbox. Envio bloqueado para evitar inbox geral.' };
  if (blockReason) return { ok:false, blocked:true, invalidated:true, expected, path, message:blockReason };
  if (!/\/direct\//i.test(path) && !box) return { ok:false, expected, path, message:'A aba não está em uma DM do Instagram.' };
  if (!box) return { ok:false, blocked:true, invalidated:true, expected, path, message:'Campo da DM não encontrado. Possível bloqueio de mensagem nesta conta.' };

  const recipients = dmRecipientCandidates();
  if (!recipients.length) {
    return { ok:false, expected, path, recipients, recipientUnconfirmed:true, message:'Não foi possível confirmar o destinatário no cabeçalho da DM. Envio bloqueado.' };
  }
  if (!recipients.includes(expected)) {
    return { ok:false, expected, path, recipients, recipientMismatch:true, message:`A DM aberta não confirma @${expected} como destinatário. Envio bloqueado.` };
  }
  return { ok:true, expected, path, recipients, message:`DM validada para @${expected}.` };
}

chrome.runtime.onMessage.addListener((message, sender, sendResponse) => {
  if (sender?.id && sender.id !== chrome.runtime.id) return false;
  if (message?.type === 'CRM_INSTAGRAM_CHECK_SESSION') {
    detectLoggedInstagramAccount().then(sendResponse);
    return true;
  }

  if (message?.type === 'CRM_INSTAGRAM_PROFILE_STATE') {
    sendResponse({ ok: true, username: currentProfileUsername(), private: isPrivateProfile() });
    return true;
  }

  if (message?.type === 'CRM_INSTAGRAM_PROFILE_ACTION_STATE') {
    getProfileActionState(message.expectedUsername || '').then(sendResponse);
    return true;
  }

  if (message?.type === 'CRM_INSTAGRAM_FOLLOW_IF_NEEDED') {
    clickFollowIfNeeded(message.expectedUsername || '').then(sendResponse);
    return true;
  }

  if (message?.type === 'CRM_INSTAGRAM_OPEN_DM') {
    openDirectMessage(message.expectedUsername || '').then(sendResponse);
    return true;
  }

  if (message?.type === 'CRM_INSTAGRAM_SAFE_TO_SEND') {
    sendResponse(getDirectSafetyState(message.expectedUsername || ''));
    return true;
  }

  if (message?.type === 'CRM_INSTAGRAM_RESET_LOCKS') {
    window.__crmInstagramSendingText = false;
    window.__crmInstagramSendingStartedAt = 0;
    sendResponse({ ok: true, message: 'Travas internas resetadas.' });
    return true;
  }

  if (message?.type === 'CRM_INSTAGRAM_PASTE_TEXT') {
    pasteTextIntoDm(message.text || '', Boolean(message.send), message.expectedUsername || '').then(sendResponse);
    return true;
  }

  if (message?.type === 'CRM_INSTAGRAM_UPLOAD_IMAGE') {
    uploadImageFileToDm({ dataUrl: message.dataUrl, bytes: message.bytes, name: message.name, type: message.type || message.mimeType }, Boolean(message.send), message.expectedUsername || '').then(sendResponse);
    return true;
  }

  if (message?.type === 'CRM_INSTAGRAM_CLOSE_DM') {
    closeDirectMessageWindow().then(sendResponse);
    return true;
  }

  if (message?.type === 'CRM_INSTAGRAM_PASTE_IMAGE') {
    sendResponse({ ok: false, message: 'Envio por clipboard foi removido. Use upload de arquivo.' });
    return true;
  }

  return false;
});
