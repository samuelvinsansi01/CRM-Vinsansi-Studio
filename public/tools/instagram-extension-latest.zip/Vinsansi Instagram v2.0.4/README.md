# Vinsansi Instagram 2.0.2

Executor oficial da Etapa 9.

## Conexão
1. Abra instagram.com e faça login no perfil que será usado.
2. Na extensão, abra Configurações e clique em **Conectar à plataforma**.
3. Autorize a organização na aba do CRM aberta automaticamente.
4. A extensão volta conectada e vinculada ao perfil detectado.

Não há token para copiar/colar. Para trocar de perfil ou organização, desconecte e conecte novamente.

## Mensagens
Para templates Instagram:
- Mensagem 1 é obrigatória;
- Mensagens 2, 3 e 4 são opcionais;
- quando usadas, devem ser preenchidas em sequência;
- o executor envia apenas as mensagens configuradas no snapshot da fila.

O fluxo WhatsApp não foi alterado.

## v2.0.3 — mídia opcional

A etapa de imagem só é executada quando o item da fila exige mídia ou possui mídia congelada no snapshot. Sem isso, o lead segue apenas com as mensagens configuradas.


## v2.0.4

Hotfix de sessão/pairing: descoberta automática da aba do Instagram e feedback visível em Configurações.
