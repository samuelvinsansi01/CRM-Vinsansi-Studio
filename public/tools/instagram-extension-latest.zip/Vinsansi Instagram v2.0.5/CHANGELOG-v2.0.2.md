# Vinsansi Instagram v2.0.2

- Mantém Mensagem 1 obrigatória e Mensagens 2–4 opcionais em sequência.
- Alinhada ao contrato global de templates do CRM R14.
