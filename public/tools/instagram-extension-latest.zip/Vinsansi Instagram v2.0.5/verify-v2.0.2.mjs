import fs from 'node:fs';
const pkg=JSON.parse(fs.readFileSync(new URL('./manifest.json', import.meta.url),'utf8'));
const js=fs.readFileSync(new URL('./popup.js', import.meta.url),'utf8');
if(pkg.version!=='2.0.2') throw new Error('version');
if(!js.includes('configuredMessageNumbers')) throw new Error('optional_message_sequence_missing');
console.log('Instagram 2.0.2 optional messages: OK');
