const STORAGE_KEY = 'crm_instagram_assist_config_v15';
const TOKEN_STORAGE_KEY = 'crm_instagram_assist_token_v2'; // legado; não usado no 2.0.2
const INSTALLATION_STORAGE_KEY = 'crm_instagram_installation_v1'; // legado; não usado no 2.0.2
const PLATFORM_API = () => globalThis.INSTAGRAM_PLATFORM_API;
const IMAGE_DB_NAME = 'crm_instagram_images';
const IMAGE_STORE = 'images_by_ramo';
const MESSAGE_STEP_DELAY_SECONDS = 5;
const QUEUE_AUTO_REFRESH_MS = 60 * 1000;
const CRM_API_BASE = 'https://painel.samuelvinsansi.com.br/api';
const CRM_API_TIMEOUT_MS = 20000;
const MAX_IMAGE_BYTES = 8 * 1024 * 1024;
let BROWSER_EXECUTION_ID = 'instagram-extension-uninitialized';

const CRM_DEFAULTS = {
  apiBase: CRM_API_BASE,
  extensionToken: '',
  scheduledDate: null,
  leadDelaySeconds: 120,
  autoSendText: 'yes'
};

const els = {
  status: document.getElementById('status'), account: document.getElementById('account'), hint: document.getElementById('hint'), refresh: document.getElementById('refresh'),
  apiBase: document.getElementById('apiBase'), extensionToken: document.getElementById('extensionToken'), platformConnectionStatus:document.getElementById('platformConnectionStatus'), connectPlatform:document.getElementById('connectPlatform'), disconnectPlatform:document.getElementById('disconnectPlatform'), configHint:document.getElementById('configHint'), extensionVersion:document.getElementById('extensionVersion'), profileUsername: document.getElementById('profileUsername'), organizationSelect:document.getElementById('organizationSelect'),organizationIdentity:document.getElementById('organizationIdentity'), scheduledDate: document.getElementById('scheduledDate'), leadDelaySeconds: document.getElementById('leadDelaySeconds'), autoSendText: document.getElementById('autoSendText'), saveConfig: document.getElementById('saveConfig'),
  loadQueue: document.getElementById('loadQueue'), fetchNext: document.getElementById('fetchNext'), queueList: document.getElementById('queueList'), queueHint: document.getElementById('queueHint'), startBatch: document.getElementById('startBatch'), autoRefreshInfo: document.getElementById('autoRefreshInfo'), pauseRun: document.getElementById('pauseRun'), stopRun: document.getElementById('stopRun'),
  mTotal: document.getElementById('mTotal'), mQueued: document.getElementById('mQueued'), mSent: document.getElementById('mSent'), mError: document.getElementById('mError'), mInvalid: document.getElementById('mInvalid'), configuredProfileInfo: document.getElementById('configuredProfileInfo'), progressBar: document.getElementById('progressBar'), progressText: document.getElementById('progressText'), opStatus: document.getElementById('opStatus'), opProfile: document.getElementById('opProfile'), opDate: document.getElementById('opDate'), opBlock: document.getElementById('opBlock'), opNextAction: document.getElementById('opNextAction'), opCountdown: document.getElementById('opCountdown'), leadPipeline: document.getElementById('leadPipeline'), opLog: document.getElementById('opLog'), sSent: document.getElementById('sSent'), sError: document.getElementById('sError'), sInvalid: document.getElementById('sInvalid'), sRuntime: document.getElementById('sRuntime'),
  leadBox: document.getElementById('leadBox'), leadName: document.getElementById('leadName'), leadInstagram: document.getElementById('leadInstagram'), leadRamo: document.getElementById('leadRamo'), leadTipo: document.getElementById('leadTipo'), leadStatus: document.getElementById('leadStatus'), message1: document.getElementById('message1'), message2: document.getElementById('message2'), message3: document.getElementById('message3'), message4: document.getElementById('message4'), imageInfo: document.getElementById('imageInfo'),
  openProfile: document.getElementById('openProfile'), followBtn: document.getElementById('followBtn'), dmBtn: document.getElementById('dmBtn'), pasteMsg1: document.getElementById('pasteMsg1'), pasteMsg2: document.getElementById('pasteMsg2'), pasteMsg3: document.getElementById('pasteMsg3'), pasteMsg4: document.getElementById('pasteMsg4'), runToMsg1: document.getElementById('runToMsg1'), markSent: document.getElementById('markSent'), errorBtn: document.getElementById('errorBtn'), invalidBtn: document.getElementById('invalidBtn'), sendImageBtn: document.getElementById('sendImageBtn'),
  manualUsername: document.getElementById('manualUsername'), manualOpen: document.getElementById('manualOpen'),
  loadQueue2: document.getElementById('loadQueue2'), fetchNext2: document.getElementById('fetchNext2'), imageList: document.getElementById('imageList'), refreshImages: document.getElementById('refreshImages'), copyImage: document.getElementById('copyImage')
};

let config = {};
let currentItem = null;
let instagramTabId = null;
let queueItems = [];
let selectedBlock = null;
let isRunning = false;
let isPaused = false;
let loggedInstagramUsername = '';
let sessionStats = { sent: 0, error: 0, invalid: 0, startedAt: null };
let opLog = [];
let runtimeTimer = null;
let leadSteps = [];
let currentNextAction = '—';
let queueAutoRefreshTimer = null;
let pendingAutoRefreshAfterLead = false;
let isLoadingQueueSilently = false;
let lastAutoRefreshAt = null;
const skippedInvalidRecipientKeys = new Set();

const sessionRamoFiles = new Map(); // arquivos reais selecionados nesta sessão da extensão

function ramoKey(value) {
  return String(value || 'sem-ramo').trim().toLowerCase()
    .normalize('NFD').replace(/[\u0300-\u036f]/g, '')
    .replace(/[^a-z0-9]+/g, '-').replace(/^-+|-+$/g, '') || 'sem-ramo';
}

function nowTime() {
  return new Date().toLocaleTimeString('pt-BR', { hour:'2-digit', minute:'2-digit', second:'2-digit' });
}

function formatDateBR(value) {
  const raw = String(value || '').trim();
  if (!raw) return 'Não carregada';
  const match = raw.match(/^(\d{4})-(\d{2})-(\d{2})/);
  if (!match) return raw;
  const [, year, month, day] = match;
  return `${day}/${month}/${year}`;
}

function configuredMessageNumbers(item = currentItem) {
  if (!item) return [];
  const values = [1, 2, 3, 4].map((number) => String(item[`message_${number}`] ?? item[`message${number}`] ?? '').trim());
  const configured = [];
  for (let index = 0; index < values.length; index += 1) {
    if (!values[index]) break;
    configured.push(index + 1);
  }
  return configured;
}

function itemRequiresImage(item = currentItem) {
  if (!item) return false;
  const value = item.imageRequired ?? item.image_required;
  if (value === true) return true;
  return String(value ?? '').trim().toLowerCase() === 'true';
}

function itemHasFrozenImage(item = currentItem) {
  if (!item) return false;
  return Boolean(
    String(item.image_name || item.imageName || item.image_url || '').trim() ||
    String(item.image_sha256 || item.image_id || '').trim()
  );
}

function itemShouldSendImage(item = currentItem) {
  return itemRequiresImage(item) || itemHasFrozenImage(item);
}

function syncMessageControls(item) {
  const configured = new Set(configuredMessageNumbers(item));
  for (const number of [1, 2, 3, 4]) {
    const field = els[`message${number}`];
    const button = els[`pasteMsg${number}`];
    if (field) field.placeholder = number === 1 ? 'Mensagem obrigatória' : 'Não configurada neste template';
    if (button) {
      button.disabled = !configured.has(number);
      button.title = configured.has(number) ? `Enviar Mensagem ${number}` : `Mensagem ${number} não configurada neste template`;
    }
  }
}

function addLog(text) {
  const line = `${nowTime()} ${text}`;
  opLog.unshift(line);
  opLog = opLog.slice(0, 30);
  if (els.opLog) els.opLog.innerHTML = opLog.map(escapeHtml).join('<br>') || 'Sem eventos ainda.';
}

function setOperationalStatus(status, nextAction = currentNextAction, countdown = '—') {
  currentNextAction = nextAction || '—';
  if (els.opStatus) els.opStatus.textContent = status || (isRunning ? 'Executando' : 'Parado');
  if (els.opNextAction) els.opNextAction.textContent = currentNextAction;
  if (els.opCountdown) els.opCountdown.textContent = countdown || '—';
  if (els.opProfile) els.opProfile.textContent = config.profileUsername ? `@${config.profileUsername}` : '—';
  if (els.opDate) els.opDate.textContent = formatDateBR(config.scheduledDate || today());
  if (els.opBlock) els.opBlock.textContent = selectedBlock ? String(selectedBlock) : '—';
}

function renderSessionStats() {
  if (els.sSent) els.sSent.textContent = sessionStats.sent;
  if (els.sError) els.sError.textContent = sessionStats.error;
  if (els.sInvalid) els.sInvalid.textContent = sessionStats.invalid;
  if (els.sRuntime) {
    const start = sessionStats.startedAt;
    const sec = start ? Math.max(0, Math.floor((Date.now() - start) / 1000)) : 0;
    const mm = String(Math.floor(sec / 60)).padStart(2, '0');
    const ss = String(sec % 60).padStart(2, '0');
    els.sRuntime.textContent = `${mm}:${ss}`;
  }
}

function startRuntimeTimer() {
  if (!sessionStats.startedAt) sessionStats.startedAt = Date.now();
  if (!runtimeTimer) runtimeTimer = setInterval(renderSessionStats, 1000);
  renderSessionStats();
}

function stopRuntimeTimerIfIdle() {
  if (runtimeTimer && !isRunning) {
    clearInterval(runtimeTimer);
    runtimeTimer = null;
  }
  renderSessionStats();
}

function setLeadSteps(steps = []) {
  leadSteps = steps;
  if (els.leadPipeline) {
    els.leadPipeline.innerHTML = steps.length ? steps.map(s => `<div>${escapeHtml(s)}</div>`).join('') : '<div class="mini">Aguardando lead.</div>';
  }
}

function addLeadStep(step) {
  leadSteps.push(step);
  setLeadSteps(leadSteps.slice(-12));
  addLog(step.replace(/^[✓✗⏳]\s*/, ''));
}

function openImageDb() {
  return new Promise((resolve, reject) => {
    const req = indexedDB.open(IMAGE_DB_NAME, 1);
    req.onupgradeneeded = () => {
      const db = req.result;
      if (!db.objectStoreNames.contains(IMAGE_STORE)) db.createObjectStore(IMAGE_STORE, { keyPath: 'key' });
    };
    req.onsuccess = () => resolve(req.result);
    req.onerror = () => reject(req.error || new Error('Erro ao abrir banco local de imagens.'));
  });
}

async function saveRamoImage(ramo, file) {
  const db = await openImageDb();
  const record = { key: ramoKey(ramo), ramo, name: file.name, type: file.type || 'image/png', size: file.size, blob: file, updatedAt: Date.now() };
  return new Promise((resolve, reject) => {
    const tx = db.transaction(IMAGE_STORE, 'readwrite');
    tx.objectStore(IMAGE_STORE).put(record);
    tx.oncomplete = () => resolve(record);
    tx.onerror = () => reject(tx.error || new Error('Erro ao salvar imagem.'));
  });
}

async function getRamoImage(ramo) {
  const db = await openImageDb();
  return new Promise((resolve, reject) => {
    const tx = db.transaction(IMAGE_STORE, 'readonly');
    const req = tx.objectStore(IMAGE_STORE).get(ramoKey(ramo));
    req.onsuccess = () => resolve(req.result || null);
    req.onerror = () => reject(req.error || new Error('Erro ao carregar imagem.'));
  });
}


function blobToDataUrl(blob) {
  return new Promise((resolve, reject) => {
    const reader = new FileReader();
    reader.onload = () => resolve(String(reader.result || ''));
    reader.onerror = () => reject(reader.error || new Error('Erro ao ler imagem.'));
    reader.readAsDataURL(blob);
  });
}

async function getRamoImagePayload(ramo) {
  const key = ramoKey(ramo);
  let file = sessionRamoFiles.get(key) || null;
  let record = null;
  if (!file) {
    record = await getRamoImage(ramo);
    file = record?.blob || null;
  }
  if (!file) return null;
  const dataUrl = await blobToDataUrl(file);
  return {
    dataUrl,
    name: file.name || record?.name || `imagem-${key}.png`,
    type: file.type || record?.type || 'image/png',
    size: file.size || record?.size || 0,
    source: sessionRamoFiles.has(key) ? 'session-file' : 'indexeddb-blob'
  };
}

async function blobSha256(blob) {
  const buffer = await blob.arrayBuffer();
  const digest = await crypto.subtle.digest('SHA-256', buffer);
  return [...new Uint8Array(digest)].map((value) => value.toString(16).padStart(2, '0')).join('');
}

async function validateFrozenImage(item, image) {
  if (!image?.blob) throw new Error(`Sem imagem cadastrada para ${item?.parent_category || 'o ramo'}.`);
  const expectedName = String(item?.image_name || item?.image_url || '').trim();
  const currentName = String(image.name || image.blob?.name || '').trim();
  if (expectedName && currentName && expectedName !== currentName) {
    throw new Error(`A fila foi preparada com ${expectedName}, mas a extensão possui ${currentName}. Atualize a imagem local antes de iniciar.`);
  }
  const expectedSha256 = String(item?.image_sha256 || '').trim().toLowerCase();
  if (expectedSha256) {
    const currentSha256 = await blobSha256(image.blob);
    if (currentSha256 !== expectedSha256) {
      throw new Error(`A imagem local de ${item?.parent_category || 'ramo'} não corresponde ao arquivo congelado na fila.`);
    }
  }
  return true;
}

async function deleteRamoImage(ramo) {
  const db = await openImageDb();
  return new Promise((resolve, reject) => {
    const tx = db.transaction(IMAGE_STORE, 'readwrite');
    tx.objectStore(IMAGE_STORE).delete(ramoKey(ramo));
    tx.oncomplete = () => resolve(true);
    tx.onerror = () => reject(tx.error || new Error('Erro ao remover imagem.'));
  });
}

async function copyBlobToClipboard(blob) {
  if (!navigator.clipboard || !window.ClipboardItem) throw new Error('Clipboard de imagem não disponível neste Chrome.');
  const originalType = blob.type || 'image/png';
  // Clipboard.write costuma aceitar PNG de forma mais estável que JPEG/WEBP.
  if (originalType === 'image/png') {
    await navigator.clipboard.write([new ClipboardItem({ [originalType]: blob })]);
    return;
  }
  throw new Error('Cópia por clipboard suporta apenas PNG. Para envio automático, a extensão usa upload direto.');
}

function switchTab(name) {
  document.querySelectorAll('.tab-btn').forEach(btn => btn.classList.toggle('active', btn.dataset.tab === name));
  document.querySelectorAll('.tab-panel').forEach(panel => panel.classList.toggle('active', panel.id === `tab-${name}`));
}

function today() { const d = new Date(); d.setMinutes(d.getMinutes() - d.getTimezoneOffset()); return d.toISOString().slice(0, 10); }
function sleep(ms) { return new Promise((resolve) => setTimeout(resolve, ms)); }
const RESERVED_INSTAGRAM_PATHS = new Set(['about','accounts','api','challenge','contact','developer','direct','directory','download','emails','explore','graphql','invites','legal','oauth','p','press','reel','reels','stories','tv','web']);
const INSTAGRAM_PROFILE_HOSTS = new Set(['instagram.com', 'www.instagram.com']);
function normalizeInstagramUsername(value) {
  const raw = String(value ?? '').trim();
  if (!raw) return '';
  const looksLikeInstagramUrl = /^https?:\/\//i.test(raw) || /^(www\.)?instagram\.com(?:\/|$)/i.test(raw);
  let candidate = raw;
  if (looksLikeInstagramUrl) {
    try {
      const url = new URL(/^https?:\/\//i.test(raw) ? raw : `https://${raw}`);
      if (!INSTAGRAM_PROFILE_HOSTS.has(url.hostname.toLowerCase()) || url.port || url.username || url.password) return '';
      const segments = url.pathname.split('/').filter(Boolean);
      if (segments.length !== 1) return '';
      [candidate] = segments;
    } catch (_) {
      return '';
    }
  } else if (candidate.startsWith('@')) {
    candidate = candidate.slice(1);
  }
  const username = candidate.toLowerCase();
  if (!/^[a-z0-9._]{1,30}$/.test(username) || RESERVED_INSTAGRAM_PATHS.has(username)) return '';
  return username;
}
function invalidInstagramRecipientResult() { return { ok:false, error:'invalid_instagram_recipient_contract', code:'invalid_instagram_recipient_contract', message:'invalid_instagram_recipient_contract' }; }
function invalidInstagramRecipientError() { const error = new Error('invalid_instagram_recipient_contract'); error.code = 'invalid_instagram_recipient_contract'; return error; }
function showHint(message, isError = false) { els.queueHint.textContent = message; els.queueHint.style.color = isError ? '#fecaca' : '#94a3b8'; }
function showConfigHint(message, isError = false) {
  if (!els.configHint) return;
  els.configHint.textContent = message || '';
  els.configHint.style.display = message ? 'block' : 'none';
  els.configHint.style.color = isError ? '#fecaca' : '#94a3b8';
}
function setAutoRefreshInfo(message, isError = false) {
  if (!els.autoRefreshInfo) return;
  els.autoRefreshInfo.textContent = message || '';
  els.autoRefreshInfo.style.color = isError ? '#fecaca' : '#94a3b8';
}
function itemKey(item) {
  return String(item?.id || item?.item_id || item?.queue_item_id || item?.lead_id || `${item?.profile_username || item?.instagram_username || ''}|${item?.block_number || ''}|${item?.company_name || ''}`);
}
function queuedItemsForSelectedBlock() {
  return queueItems.filter(i => Number(i.block_number || 1) === Number(selectedBlock) && isQueuedStatus(i.status));
}
function hasInvalidInstagramRecipient(item) {
  return item?.recipient_error === 'invalid_instagram_recipient_contract' || !normalizeInstagramUsername(item?.instagram_username);
}
function validQueuedItemsForSelectedBlock() {
  return queuedItemsForSelectedBlock().filter(item => !hasInvalidInstagramRecipient(item));
}
function invalidQueuedItemsForSelectedBlock() {
  return queuedItemsForSelectedBlock().filter(hasInvalidInstagramRecipient);
}
function recordSkippedInvalidRecipients(items = []) {
  let added = 0;
  for (const item of items) {
    const key = itemKey(item);
    if (skippedInvalidRecipientKeys.has(key)) continue;
    skippedInvalidRecipientKeys.add(key);
    added += 1;
    addLog(`Destinatário inválido ignorado sem claim: ${item.company_name || item.lead_id || item.id || key}`);
  }
  return added;
}
function invalidRecipientIterationMessage(count) {
  return `invalid_instagram_recipient_contract: ${count} item(ns) inválido(s) permaneceram sem claim; não há candidato válido nesta iteração.`;
}
function startQueueAutoRefresh() {
  if (queueAutoRefreshTimer) clearInterval(queueAutoRefreshTimer);
  queueAutoRefreshTimer = setInterval(async () => {
    if (isRunning) {
      pendingAutoRefreshAfterLead = true;
      setAutoRefreshInfo('Autoatualização ativa: próxima checagem ao terminar o lead atual.');
      return;
    }
    await silentRefreshQueue('auto');
  }, QUEUE_AUTO_REFRESH_MS);
  setAutoRefreshInfo('Autoatualização ativa: a cada 60s.');
}
async function silentRefreshQueue(source = 'auto') {
  if (isLoadingQueueSilently) return { updated:false, added:0 };
  if (!config?.extensionToken || !config?.profileUsername) return { updated:false, added:0 };
  isLoadingQueueSilently = true;
  try {
    const previousKeys = new Set((queueItems || []).map(itemKey));
    const previousCount = (queueItems || []).length;
    const result = await crmApi('queue');
    const nextItems = result.items || [];
    const added = nextItems.filter(i => !previousKeys.has(itemKey(i))).length;
    queueItems = nextItems;
    const blocks = groupByBlock(queueItems).map(([block]) => block);
    if (!selectedBlock || !blocks.some(b => Number(b) === Number(selectedBlock))) {
      selectedBlock = blocks[0] || null;
    }
    if (currentItem) {
      const currentKey = itemKey(currentItem);
      const fresh = queueItems.find(i => itemKey(i) === currentKey);
      if (fresh) currentItem = { ...currentItem, ...fresh };
    }
    renderQueue();
    if (currentItem) renderLead(currentItem);
    lastAutoRefreshAt = new Date();
    const time = lastAutoRefreshAt.toLocaleTimeString('pt-BR', { hour:'2-digit', minute:'2-digit' });
    const label = source === 'manual' ? 'Fila carregada' : 'Autoatualização';
    const msg = added > 0
      ? `${label}: ${added} novo(s) lead(s) encontrado(s) às ${time}.`
      : `${label}: sem novos leads às ${time}.`;
    setAutoRefreshInfo(msg);
    if (added > 0) addLog(`${added} novo(s) lead(s) adicionados à fila`);
    return { updated: previousCount !== nextItems.length || added > 0, added, items: nextItems };
  } catch (err) {
    setAutoRefreshInfo(`Autoatualização falhou: ${err.message}`, true);
    return { updated:false, added:0, error:err };
  } finally {
    pendingAutoRefreshAfterLead = false;
    isLoadingQueueSilently = false;
  }
}
function escapeHtml(value) { return String(value || '').replaceAll('&','&amp;').replaceAll('<','&lt;').replaceAll('>','&gt;').replaceAll('"','&quot;').replaceAll("'",'&#039;'); }
function formatLeadType(type) { const t = String(type || '').toLowerCase(); if (t.includes('agreg')) return 'Agregador'; if (t.includes('com')) return 'Com site'; return 'Sem site'; }
function currentLeadUsername() { return normalizeInstagramUsername(currentItem?.instagram_username); }
function isQueuedStatus(status) { return ['queued','sending','fila','em_fila','ready','ready_to_dispatch','scheduled'].includes(String(status||'').toLowerCase()); }
function isSentStatus(status) { return ['sent','enviado'].includes(String(status||'').toLowerCase()); }
function isErrorStatus(status) { return ['error','erro'].includes(String(status||'').toLowerCase()); }
function isInvalidStatus(status) { return ['invalid','invalidated','invalido','invalidado'].includes(String(status||'').toLowerCase()); }

async function getActiveTab() { const [tab] = await chrome.tabs.query({ active: true, currentWindow: true }); return tab; }
function isInstagramUrl(url = '') { try { const host = new URL(url).hostname; return host === 'instagram.com' || host === 'www.instagram.com'; } catch (_) { return false; } }
async function findInstagramTab() {
  const tabs = await chrome.tabs.query({ url: ['https://www.instagram.com/*','https://instagram.com/*'] });
  if (!tabs.length) return null;
  const active = tabs.find(tab => tab.active);
  return active || tabs[0] || null;
}
async function injectContent(tabId) { await chrome.scripting.executeScript({ target: { tabId }, files: ['content.js'] }); }

const RECIPIENT_BOUND_COMMANDS = new Set([
  'CRM_INSTAGRAM_PROFILE_ACTION_STATE',
  'CRM_INSTAGRAM_FOLLOW_IF_NEEDED',
  'CRM_INSTAGRAM_OPEN_DM',
  'CRM_INSTAGRAM_SAFE_TO_SEND',
  'CRM_INSTAGRAM_PASTE_TEXT',
  'CRM_INSTAGRAM_UPLOAD_IMAGE',
  'CRM_INSTAGRAM_CLOSE_DM'
]);

const RETRYABLE_READ_COMMANDS = new Set([
  'CRM_INSTAGRAM_CHECK_SESSION',
  'CRM_INSTAGRAM_PROFILE_STATE',
  'CRM_INSTAGRAM_PROFILE_ACTION_STATE',
  'CRM_INSTAGRAM_SAFE_TO_SEND'
]);

function uncertainMediaTransportResult(message) {
  return {
    ok: false,
    mediaConfirmed: false,
    uncertain: true,
    doNotFallback: true,
    fallbackAllowed: false,
    message
  };
}

async function ensureInstagramContentAvailable(tabId) {
  try {
    const probe = await chrome.tabs.sendMessage(tabId, { type: 'CRM_INSTAGRAM_PROFILE_STATE' });
    if (probe?.ok) return;
  } catch (_) {}
  await injectContent(tabId);
  const probe = await chrome.tabs.sendMessage(tabId, { type: 'CRM_INSTAGRAM_PROFILE_STATE' });
  if (!probe?.ok) throw new Error('O content script do Instagram não respondeu à verificação segura.');
}

async function sendToInstagramTab(type, payload = {}) {
  if (RECIPIENT_BOUND_COMMANDS.has(type)) {
    const expectedUsername = normalizeInstagramUsername(payload.expectedUsername);
    if (!expectedUsername) return invalidInstagramRecipientResult();
    payload = { ...payload, expectedUsername };
  }
  let tab = await getActiveTab();
  if (!tab?.id || !isInstagramUrl(tab.url)) {
    if (instagramTabId) { try { tab = await chrome.tabs.get(instagramTabId); } catch (_) { tab = null; } }
  }
  if (!tab?.id || !isInstagramUrl(tab.url)) {
    tab = await findInstagramTab();
  }
  if (!tab?.id || !isInstagramUrl(tab.url)) return { ok: false, message: 'Nenhuma aba do Instagram foi encontrada. Abra instagram.com, faça login e tente novamente.' };
  instagramTabId = tab.id;
  if (type === 'CRM_INSTAGRAM_UPLOAD_IMAGE') {
    await ensureInstagramContentAvailable(tab.id);
    try {
      const response = await chrome.tabs.sendMessage(tab.id, { type, ...payload });
      return response || uncertainMediaTransportResult('A tentativa de upload começou, mas o content script não devolveu uma confirmação.');
    } catch (err) {
      return uncertainMediaTransportResult(`A tentativa de upload começou, mas a resposta do content script foi perdida: ${err?.message || err}`);
    }
  }
  try { return await chrome.tabs.sendMessage(tab.id, { type, ...payload }); }
  catch (err) {
    if (!RETRYABLE_READ_COMMANDS.has(type)) throw err;
    await injectContent(tab.id);
    return await chrome.tabs.sendMessage(tab.id, { type, ...payload });
  }
}

async function openOrFocusInstagram(username) {
  const canonicalUsername = normalizeInstagramUsername(username);
  if (!canonicalUsername) throw invalidInstagramRecipientError();
  const url = `https://www.instagram.com/${canonicalUsername}/`;
  const tabs = await chrome.tabs.query({ url: ['https://www.instagram.com/*','https://instagram.com/*'] });
  const existing = tabs[0];
  if (existing?.id) { instagramTabId = existing.id; await chrome.tabs.update(existing.id, { active: true, url }); if (existing.windowId) await chrome.windows.update(existing.windowId, { focused: true }); return existing.id; }
  const tab = await chrome.tabs.create({ url, active: true }); instagramTabId = tab.id; return tab.id;
}

async function getInstagramProfileStateSafe() {
  try {
    const res = await sendToInstagramTab('CRM_INSTAGRAM_PROFILE_STATE');
    return res || null;
  } catch (_) {
    return null;
  }
}

async function ensureLeadProfileOpen() {
  const username = currentLeadUsername();
  if (!username) throw invalidInstagramRecipientError();

  const state = await getInstagramProfileStateSafe();
  const current = normalizeInstagramUsername(state?.username || '');
  if (current === username) {
    return username;
  }

  await openOrFocusInstagram(username);
  await sleep(2600);
  try { await injectContent(instagramTabId); } catch (_) {}

  const loaded = await waitForProfile(username, 12000);
  if (!loaded) throw new Error(`O perfil @${username} não terminou de carregar.`);
  return username;
}

async function waitForProfile(username, timeout = 12000) {
  const expected = normalizeInstagramUsername(username);
  if (!expected) return false;
  const start = Date.now();
  while (Date.now() - start < timeout) {
    const state = await getInstagramProfileStateSafe();
    if (normalizeInstagramUsername(state?.username || '') === expected) return true;
    await sleep(500);
  }
  return false;
}

async function checkSession() {
  els.status.textContent = 'Verificando...'; els.account.textContent = '—'; els.refresh.disabled = true;
  showConfigHint('Verificando a sessão do Instagram…');
  try {
    const response = await sendToInstagramTab('CRM_INSTAGRAM_CHECK_SESSION');
    if (response?.ok && response.loggedIn) {
      loggedInstagramUsername = normalizeInstagramUsername(response.username || '');
      els.status.textContent = '🟢 Logado';
      els.account.textContent = loggedInstagramUsername ? `@${loggedInstagramUsername}` : '@não identificado';
      showConfigHint(loggedInstagramUsername ? `Sessão detectada em @${loggedInstagramUsername}.` : 'Sessão detectada.');
      if (response.username && !normalizeInstagramUsername(els.profileUsername.value)) { els.profileUsername.value = loggedInstagramUsername; await saveConfig(false); }
      if (normalizeInstagramUsername(els.profileUsername.value) && loggedInstagramUsername && normalizeInstagramUsername(els.profileUsername.value) !== loggedInstagramUsername) {
        showConfigHint('Perfil logado diferente do perfil configurado.', true);
      }
    } else {
      loggedInstagramUsername = '';
      els.status.textContent = '🔴 Não logado';
      showConfigHint(response?.message || 'Abra instagram.com e faça login.', true);
    }
  } catch (error) {
    loggedInstagramUsername = '';
    els.status.textContent = '🔴 Não logado';
    showConfigHint(`Não consegui verificar a aba do Instagram: ${error?.message || error}`, true);
  } finally { els.refresh.disabled = false; }
}

function normalizeApiBase(value) {
  const raw = String(value || '').trim().replace(/\/$/, '');
  if (raw !== CRM_API_BASE) throw new Error('A API do CRM não corresponde ao domínio autorizado da extensão.');
  return raw;
}

function isValidUuid(value) {
  return /^[0-9a-f]{8}-[0-9a-f]{4}-[1-5][0-9a-f]{3}-[89ab][0-9a-f]{3}-[0-9a-f]{12}$/i.test(String(value || '').trim());
}

async function loadConfig() {
  const data = await chrome.storage.local.get(STORAGE_KEY);
  const platformSession = await PLATFORM_API().session();
  config = { ...CRM_DEFAULTS, ...(data[STORAGE_KEY] || {}) };
  config.apiBase = CRM_API_BASE;
  config.scheduledDate = today();
  config.extensionToken = platformSession?.userSession || '';
  config.installationCredential = platformSession?.installationCredential || '';
  config.organizationId = Number(platformSession?.organizationId || 0);
  config.externalInstallationId = platformSession?.externalInstallationId || platformSession?.installationId || '';
  config.profileUsername = normalizeInstagramUsername(platformSession?.instagramProfile || config.profileUsername || '');
  BROWSER_EXECUTION_ID = config.externalInstallationId ? `instagram-extension-${config.externalInstallationId}` : `instagram-extension-${crypto.randomUUID()}`;
  if (els.apiBase) els.apiBase.value = CRM_API_BASE;
  if (els.profileUsername) els.profileUsername.value = config.profileUsername || '';
  if (els.scheduledDate) els.scheduledDate.value = config.scheduledDate;
  if (els.leadDelaySeconds) els.leadDelaySeconds.value = Number(config.leadDelaySeconds || 120);
  if (els.autoSendText) els.autoSendText.value = config.autoSendText || 'yes';
  if (els.configuredProfileInfo) els.configuredProfileInfo.textContent = config.profileUsername ? '@' + config.profileUsername : '—';
  if (els.extensionVersion) els.extensionVersion.textContent = chrome.runtime.getManifest().version;
  if (platformSession?.userSession) {
    try {
      const refreshed = await PLATFORM_API().refreshContext(platformSession);
      config.extensionToken = refreshed.userSession;
      config.installationCredential = refreshed.installationCredential;
      config.organizationId = Number(refreshed.organizationId || 0);
      config.context = refreshed.context;
      config.effectiveConfig = refreshed.effectiveConfig;
      await refreshExecutorContext();
    } catch (error) {
      showHint(`A conexão com a plataforma precisa ser refeita: ${error.message || error}`, true);
      await PLATFORM_API().clearSession();
      config.extensionToken = '';
    }
  }
  renderPlatformConnection();
}

async function executorRequest(path,{method='GET',body,credential=false}={}) {
  const token = credential ? config.installationCredential : config.extensionToken;
  const headers = {'Content-Type':'application/json','X-Vinsansi-Organization-Id':String(config.organizationId||''),...(credential?{'X-Vinsansi-Installation-Credential':token}:{Authorization:`Bearer ${token}`})};
  const response=await fetch(`${config.apiBase}/tools/executor/${path}`,{method,headers,...(body?{body:JSON.stringify(body)}:{})});
  const data=await response.json().catch(()=>({}));
  if(!response.ok)throw new Error(data.error||data.message||`HTTP ${response.status}`);
  return data;
}

async function refreshExecutorContext() {
  if (!config.extensionToken) return null;
  const context=await executorRequest('context');
  config.context=context;config.organizationId=context.organizationId;
  if(els.organizationIdentity)els.organizationIdentity.textContent=`${context.organizationName} • ${context.memberName || 'Membro não identificado'}`;
  if(els.organizationSelect){
    els.organizationSelect.replaceChildren(...(context.eligibleOrganizations||[]).map(row=>{const option=document.createElement('option');option.value=row.organizationId;option.textContent=row.organizationName;return option;}));
    els.organizationSelect.value=String(context.organizationId);els.organizationSelect.disabled=true;
  }
  const effective=await executorRequest('config');config.effectiveConfig=effective.config;
  const dispatch=effective.config?.settings?.instagram||effective.config?.settings||{};
  if(Number.isFinite(Number(dispatch.delayMinSeconds)))config.leadDelaySeconds=Number(dispatch.delayMinSeconds);
  if(els.leadDelaySeconds){els.leadDelaySeconds.value=String(config.leadDelaySeconds);els.leadDelaySeconds.disabled=true;}
  return context;
}

function renderPlatformConnection() {
  const connected = Boolean(config.extensionToken && config.installationCredential && config.organizationId);
  if (els.platformConnectionStatus) els.platformConnectionStatus.textContent = connected ? `Conectado${config.profileUsername ? ` • @${config.profileUsername}` : ''}` : 'Desconectado';
  if (els.connectPlatform) els.connectPlatform.hidden = connected;
  if (els.disconnectPlatform) els.disconnectPlatform.hidden = !connected;
  if (!connected && els.organizationIdentity) els.organizationIdentity.textContent = '—';
}

async function connectPlatform() {
  if (isRunning) throw new Error('Pare a operação antes de reconectar a extensão.');
  if (els.connectPlatform) { els.connectPlatform.disabled = true; els.connectPlatform.textContent = 'Conectando…'; }
  showConfigHint('Verificando o perfil logado no Instagram…');
  try {
    const sessionState = await sendToInstagramTab('CRM_INSTAGRAM_CHECK_SESSION');
    const profile = normalizeInstagramUsername(sessionState?.username || '');
    if (!sessionState?.ok || !sessionState.loggedIn || !profile) {
      throw new Error(sessionState?.message || 'Abra o Instagram, faça login no perfil que será usado e tente novamente.');
    }
    loggedInstagramUsername = profile;
    els.status.textContent = '🟢 Logado';
    els.account.textContent = `@${profile}`;
    showConfigHint(`Abrindo autorização da plataforma para @${profile}…`);
    const pairing = await PLATFORM_API().beginPairing(profile);
    showConfigHint('Autorize a organização na aba do CRM que foi aberta. A extensão aguardará a confirmação…');
    const platformSession = await PLATFORM_API().exchangePairing(pairing);
    config.extensionToken = platformSession.userSession;
    config.installationCredential = platformSession.installationCredential;
    config.organizationId = Number(platformSession.organizationId || 0);
    config.externalInstallationId = platformSession.externalInstallationId || platformSession.installationId || pairing.installationId;
    config.profileUsername = profile;
    BROWSER_EXECUTION_ID = `instagram-extension-${config.externalInstallationId}`;
    if (els.profileUsername) els.profileUsername.value = profile;
    if (els.configuredProfileInfo) els.configuredProfileInfo.textContent = '@' + profile;
    await saveConfig(false);
    await refreshExecutorContext();
    renderPlatformConnection();
    showConfigHint(`Conectado à plataforma e vinculado a @${profile}.`);
  } catch (error) {
    showConfigHint(error?.message || String(error), true);
    throw error;
  } finally {
    if (els.connectPlatform) { els.connectPlatform.disabled = false; els.connectPlatform.textContent = 'Conectar à plataforma'; }
  }
}

async function disconnectPlatform() {
  if (isRunning) throw new Error('Pare a operação antes de desconectar.');
  await PLATFORM_API().disconnect();
  config.extensionToken='';config.installationCredential='';config.organizationId=0;config.context=null;config.effectiveConfig=null;config.profileUsername='';
  if (els.profileUsername) els.profileUsername.value='';
  if (els.configuredProfileInfo) els.configuredProfileInfo.textContent='—';
  renderPlatformConnection();
  showHint('Extensão desconectada da plataforma.');
}

async function saveConfig(show = true) {
  config = {
    ...config,
    apiBase: normalizeApiBase(CRM_API_BASE),
    profileUsername: normalizeInstagramUsername(config.profileUsername || els.profileUsername?.value),
    scheduledDate: els.scheduledDate.value || today(),
    leadDelaySeconds: Math.max(0, Number(els.leadDelaySeconds.value || 120) || 0),
    autoSendText: els.autoSendText.value || 'yes'
  };
  const persisted = { apiBase:config.apiBase, profileUsername:config.profileUsername, scheduledDate:config.scheduledDate, leadDelaySeconds:config.leadDelaySeconds, autoSendText:config.autoSendText };
  await chrome.storage.local.set({ [STORAGE_KEY]: persisted });
  if (els.profileUsername) els.profileUsername.value = config.profileUsername;
  if (els.configuredProfileInfo) els.configuredProfileInfo.textContent = config.profileUsername ? '@' + config.profileUsername : '—';
  if (show) showHint('Preferências operacionais salvas. A conexão é gerenciada pela plataforma.');
}

function requireConfig() {
  config.scheduledDate = els.scheduledDate.value || today();
  config.autoSendText = els.autoSendText.value || 'yes';
  if (!config.extensionToken || !config.installationCredential || !config.organizationId) throw new Error('Conecte a extensão à plataforma.');
  if (!config.profileUsername) throw new Error('A instalação não possui um perfil Instagram vinculado. Desconecte e conecte novamente.');
}


async function assertLoggedProfileMatchesConfig() {
  requireConfig();
  const response = await sendToInstagramTab('CRM_INSTAGRAM_CHECK_SESSION');
  if (!response?.ok || !response.loggedIn) throw new Error('Instagram não está logado nesta aba.');
  loggedInstagramUsername = normalizeInstagramUsername(response.username || '');
  if (!loggedInstagramUsername) throw new Error('Não consegui detectar o @perfil logado no Instagram.');
  if (loggedInstagramUsername !== config.profileUsername) {
    throw new Error(`Perfil logado @${loggedInstagramUsername} é diferente do perfil vinculado @${config.profileUsername}. Desconecte e conecte novamente para trocar de perfil.`);
  }
  return true;
}

async function crmApi(action, payload = {}) {
  requireConfig();
  const url = `${config.apiBase}/instagram/extension`;
  const headers = {
    'Content-Type': 'application/json',
    'Authorization': `Bearer ${config.extensionToken}`
  };
  const body = {
    action,
    request_id: crypto.randomUUID(),
    profile_username: config.profileUsername,
    scheduled_date: config.scheduledDate || today(),
    consumer_id: BROWSER_EXECUTION_ID,
    ...payload
  };
  const controller = new AbortController();
  const timer = setTimeout(() => controller.abort(), CRM_API_TIMEOUT_MS);
  try {
    const res = await fetch(url, {
      method:'POST',
      headers,
      body: JSON.stringify(body),
      signal: controller.signal,
      cache: 'no-store',
      credentials: 'omit'
    });
    const text = await res.text();
    let data = null;
    try { data = text ? JSON.parse(text) : null; } catch (_) { data = { raw:text }; }
    if (!res.ok || data?.ok === false) throw new Error(data?.error || data?.message || text || `Erro HTTP ${res.status}`);
    return data;
  } catch (error) {
    if (error?.name === 'AbortError') throw new Error('A API do CRM excedeu o tempo limite. Nenhum resultado foi presumido.');
    throw error;
  } finally {
    clearTimeout(timer);
  }
}

setInterval(()=>{if(config.installationCredential)void PLATFORM_API().heartbeat(null,false).catch(()=>{});},60_000);

function groupByBlock(items) {
  const map = new Map();
  for (const item of items || []) {
    const block = Number(item.block_number || 1) || 1;
    if (!map.has(block)) map.set(block, []);
    map.get(block).push(item);
  }
  return [...map.entries()].sort((a,b)=>a[0]-b[0]);
}

function renderQueue() {
  const total = queueItems.length;
  const queued = queueItems.filter(i => isQueuedStatus(i.status)).length;
  const sent = queueItems.filter(i => isSentStatus(i.status)).length;
  const err = queueItems.filter(i => isErrorStatus(i.status)).length;
  const invalid = queueItems.filter(i => isInvalidStatus(i.status)).length;
  els.mTotal.textContent = total; els.mQueued.textContent = queued; if (els.mSent) els.mSent.textContent = sent; els.mError.textContent = err; if (els.mInvalid) els.mInvalid.textContent = invalid;
  const pct = total ? Math.round((sent / total) * 100) : 0;
  if (els.progressBar) els.progressBar.style.width = `${pct}%`;
  if (els.progressText) els.progressText.textContent = `${sent} / ${total} enviados · ${pct}%`;
  setOperationalStatus(isRunning ? (isPaused ? 'Pausado' : `Executando lote ${selectedBlock || '—'}`) : 'Parado');
  els.queueList.innerHTML = '';
  const blocks = groupByBlock(queueItems);
  if (!blocks.length) { els.queueList.innerHTML = '<p class="muted">Nenhum lead em fila para este perfil/data.</p>'; els.startBatch.disabled = true; renderImages(); return; }
  for (const [block, items] of blocks) {
    const pending = items.filter(i => isQueuedStatus(i.status)).length;
    const sent = items.filter(i => isSentStatus(i.status)).length;
    const errors = items.filter(i => isErrorStatus(i.status)).length;
    const invalids = items.filter(i => isInvalidStatus(i.status)).length;
    const details = document.createElement('details'); details.open = block === selectedBlock || (!selectedBlock && block === blocks[0][0]);
    details.innerHTML = `<summary>Lote ${block} — ${items.length} leads <span>${pending} fila · ${sent} env · ${errors} erro · ${invalids} inv</span></summary><div class="details-body"></div>`;
    const body = details.querySelector('.details-body');
    const start = document.createElement('button'); start.className = 'success'; start.textContent = `Selecionar lote ${block}`; start.addEventListener('click', () => { selectedBlock = block; els.startBatch.disabled = false; showHint(`Lote ${block} selecionado.`); renderQueue(); });
    body.appendChild(start);
    items.forEach((item, idx) => {
      const username = normalizeInstagramUsername(item.instagram_username);
      const row = document.createElement('div'); row.className = 'lead-row' + (currentItem?.id === item.id ? ' active' : '');
      row.innerHTML = `<div class="lead-title"><span>${idx+1}. ${escapeHtml(item.company_name || 'Lead')}</span><span class="badge ${isErrorStatus(item.status)?'err':isSentStatus(item.status)?'ok':isInvalidStatus(item.status)?'err':'wait'}">${escapeHtml(item.status || 'queued')}</span></div><div class="lead-sub">@${escapeHtml(username || 'sem instagram')} · ${escapeHtml(item.parent_category || 'Ramo')} · ${escapeHtml(formatLeadType(item.lead_type))}</div>`;
      row.addEventListener('click', () => { currentItem = item; selectedBlock = block; renderLead(item); renderQueue(); });
      body.appendChild(row);
    });
    els.queueList.appendChild(details);
  }
  renderImages();
}

async function loadQueue() {
  els.loadQueue.disabled = true; if (els.loadQueue2) els.loadQueue2.disabled = true; showHint('Carregando lotes da fila Instagram...');
  try {
    await saveConfig(false);
    await assertLoggedProfileMatchesConfig();
    const result = await crmApi('queue');
    queueItems = result.items || [];
    selectedBlock = selectedBlock || (groupByBlock(queueItems)[0]?.[0] || null);
    renderQueue();
    showHint(queueItems.length ? `Fila carregada: ${queueItems.length} leads em ${groupByBlock(queueItems).length} lote(s).` : 'Nenhum lead em fila para este perfil/data.');
    const time = new Date().toLocaleTimeString('pt-BR', { hour:'2-digit', minute:'2-digit' });
    setAutoRefreshInfo(`Autoatualização ativa: próxima checagem em até 60s. Última atualização às ${time}.`);
    startQueueAutoRefresh();
  } catch (err) { showHint(`Erro ao carregar fila: ${err.message}`, true); }
  finally { els.loadQueue.disabled = false; if (els.loadQueue2) els.loadQueue2.disabled = false; }
}

async function fetchNextLead() {
  els.fetchNext.disabled = true; if (els.fetchNext2) els.fetchNext2.disabled = true; showHint('Buscando próximo lead...');
  try {
    await saveConfig(false);
    await assertLoggedProfileMatchesConfig();
    const result = await crmApi('claim_next', selectedBlock ? { block_number: selectedBlock } : {});
    const skippedInvalid = Array.isArray(result?.skipped_invalid_recipient) ? result.skipped_invalid_recipient : [];
    recordSkippedInvalidRecipients(skippedInvalid);
    if (!result?.item) {
      currentItem = null;
      renderLead(null);
      if (result?.iteration_status === 'invalid_instagram_recipients_only') {
        showHint(invalidRecipientIterationMessage(skippedInvalid.length), true);
        return { terminal:true, iterationStatus:result.iteration_status, skippedInvalidRecipient:skippedInvalid };
      }
      showHint(result?.iteration_status === 'claim_unavailable' ? 'O candidato válido deixou de estar disponível antes da claim.' : 'Nenhum lead em fila para este perfil/data.');
      return { terminal:true, iterationStatus:result?.iteration_status || 'empty', skippedInvalidRecipient:skippedInvalid };
    }
    currentItem = result.item; renderLead(currentItem); showHint('Lead carregado. Abrindo perfil...');
    const username = await ensureLeadProfileOpen(); showHint(`Perfil @${username} aberto.`);
    return { terminal:false, item:currentItem, skippedInvalidRecipient:skippedInvalid };
  } catch (err) { showHint(`Erro ao buscar fila: ${err.message}`, true); }
  finally { els.fetchNext.disabled = false; if (els.fetchNext2) els.fetchNext2.disabled = false; }
}

function renderLead(item) {
  if (!item) {
    els.leadBox.style.display='none';
    els.openProfile.disabled=true;
    for (const number of [1, 2, 3, 4]) {
      const field = els[`message${number}`];
      if (field) field.value = '';
    }
    syncMessageControls(null);
    return;
  }
  const username = normalizeInstagramUsername(item.instagram_username);
  els.leadBox.style.display='block'; els.openProfile.disabled=!username;
  els.leadName.textContent = item.company_name || 'Lead sem nome';
  els.leadInstagram.textContent = username ? `@${username}` : 'Sem Instagram';
  els.leadRamo.textContent = item.parent_category || 'Ramo não informado';
  els.leadTipo.textContent = formatLeadType(item.lead_type); els.leadStatus.textContent = item.status || 'queued'; setLeadSteps(['⏳ Lead carregado']);
  els.message1.value = item.message_1 || '';
  els.message2.value = item.message_2 || '';
  els.message3.value = item.message_3 || '';
  els.message4.value = item.message_4 || '';
  syncMessageControls(item);
  els.imageInfo.textContent = 'Verificando imagem do ramo na extensão...';
  if (els.copyImage) els.copyImage.disabled = true;
  updateLeadImageInfo(item);
}

async function updateLeadImageInfo(item) {
  const ramo = item?.parent_category || 'Ramo não informado';
  const required = itemRequiresImage(item);
  const frozen = itemHasFrozenImage(item);
  try {
    const img = await getRamoImage(ramo);
    if (img?.blob) {
      if (required || frozen) await validateFrozenImage(item, img);
      els.imageInfo.textContent = required || frozen
        ? `Imagem congelada confirmada: ${img.name} (${Math.round((img.size || 0) / 1024)} KB)`
        : `Imagem opcional disponível: ${img.name} (${Math.round((img.size || 0) / 1024)} KB)`;
      if (els.copyImage) els.copyImage.disabled = false;
      if (els.sendImageBtn) els.sendImageBtn.disabled = false;
      return;
    }
    els.imageInfo.textContent = required || frozen
      ? 'Imagem exigida para este item. Cadastre a imagem correta na aba Imagens antes de iniciar.'
      : 'Imagem opcional. Este lead será enviado somente com as mensagens configuradas.';
    if (els.copyImage) els.copyImage.disabled = true;
    if (els.sendImageBtn) els.sendImageBtn.disabled = true;
  } catch (err) {
    els.imageInfo.textContent = required || frozen
      ? `Não consegui validar a imagem exigida: ${err?.message || err}`
      : 'Imagem opcional não disponível. O envio seguirá somente com texto.';
    if (els.copyImage) els.copyImage.disabled = true;
    if (els.sendImageBtn) els.sendImageBtn.disabled = true;
  }
}

async function copyCurrentRamoImage() {
  if (!currentItem) return showHint('Nenhum lead carregado.', true);
  const ramo = currentItem.parent_category || 'Ramo não informado';
  try {
    const img = await getRamoImage(ramo);
    if (!img?.blob) return showHint(`Sem imagem cadastrada para ${ramo}.`, true);
    await copyBlobToClipboard(img.blob);
    showHint(`Imagem de ${ramo} copiada. Cole na DM do Instagram.`);
    return { ok: true };
  } catch (err) {
    showHint(err.message || 'Erro ao copiar imagem.', true);
    return { ok: false, message: err.message };
  }
}

async function sendCurrentRamoImage() {
  if (!currentItem) throw new Error('Nenhum lead carregado.');
  const ramo = currentItem.parent_category || 'Ramo não informado';
  const img = await getRamoImage(ramo);
  if (!img?.blob) throw new Error(`Sem imagem cadastrada para ${ramo}. Vá na aba Imagens e insira a imagem do ramo.`);
  await validateFrozenImage(currentItem, img);

  // Envio automático NÃO usa clipboard. Enviamos a imagem como DataURL para o
  // content script reconstruir um File real dentro da página e anexar no input[type=file].
  const payload = await getRamoImagePayload(ramo);
  if (!payload?.dataUrl) throw new Error(`Imagem de ${ramo} não pôde ser preparada para upload.`);
  const res = await sendToInstagramTab('CRM_INSTAGRAM_UPLOAD_IMAGE', {
    expectedUsername: currentLeadUsername(),
    dataUrl: payload.dataUrl,
    name: payload.name,
    mimeType: payload.type,
    size: payload.size,
    source: payload.source,
    send: true
  });

  if (!res?.ok || !res?.mediaConfirmed) {
    return {
      ...(res || {}),
      ok: false,
      mediaConfirmed: false,
      message: res?.message || 'Não consegui confirmar o envio da imagem automaticamente.'
    };
  }
  showHint(res.message || 'Imagem enviada e confirmada.');
  return res;
}

async function renderImages() {
  if (!els.imageList) return;
  const ramos = [...new Set((queueItems || []).map(i => i.parent_category || 'Ramo não informado'))].sort();
  if (!ramos.length) {
    els.imageList.innerHTML = '<p class="muted">Carregue a fila para listar os ramos presentes.</p>';
    return;
  }
  els.imageList.innerHTML = '';
  for (const ramo of ramos) {
    const ramoNeedsImage = (queueItems || []).some((item) => (item.parent_category || 'Ramo não informado') === ramo && itemShouldSendImage(item));
    const row = document.createElement('div');
    row.className = 'image-row';
    row.innerHTML = `
      <div class="lead-title"><span>${escapeHtml(ramo)}</span><span class="badge wait" data-status>Verificando</span></div>
      <input type="file" accept="image/png,image/jpeg,image/jpg,image/webp" data-file>
      <img class="image-preview" data-preview>
      <div class="grid2"><button class="secondary" data-copy>Copiar imagem</button><button class="danger" data-remove>Remover</button></div>
      <p class="mini" data-info></p>`;
    const status = row.querySelector('[data-status]');
    const info = row.querySelector('[data-info]');
    const preview = row.querySelector('[data-preview]');
    const fileInput = row.querySelector('[data-file]');
    const copyBtn = row.querySelector('[data-copy]');
    const removeBtn = row.querySelector('[data-remove]');
    async function refreshRow() {
      const img = await getRamoImage(ramo);
      if (img?.blob) {
        status.textContent = 'Configurada'; status.className = 'badge ok';
        info.textContent = `${img.name} · ${Math.round((img.size || 0) / 1024)} KB`;
        preview.src = URL.createObjectURL(img.blob); preview.style.display = 'block'; copyBtn.disabled = false; removeBtn.disabled = false;
      } else {
        status.textContent = ramoNeedsImage ? 'Imagem exigida' : 'Opcional';
        status.className = ramoNeedsImage ? 'badge err' : 'badge wait';
        info.textContent = ramoNeedsImage
          ? 'Este lote possui item que exige imagem para este ramo.'
          : 'Nenhuma imagem exigida. O lote seguirá somente com as mensagens configuradas.';
        preview.removeAttribute('src'); preview.style.display = 'none'; copyBtn.disabled = true; removeBtn.disabled = true;
      }
    }
    fileInput.addEventListener('change', async () => {
      const file = fileInput.files?.[0];
      if (!file) return;
      if (!/^image\/(png|jpe?g|webp)$/i.test(file.type)) return showHint('Formato inválido. Use PNG, JPG, JPEG ou WEBP.', true);
      if (file.size > MAX_IMAGE_BYTES) return showHint('Imagem acima de 8 MB. Reduza o arquivo antes de salvar.', true);
      sessionRamoFiles.set(ramoKey(ramo), file);
      await saveRamoImage(ramo, file);
      await refreshRow();
      if (currentItem?.parent_category === ramo) await updateLeadImageInfo(currentItem);
      showHint(`Imagem de ${ramo} salva na extensão.`);
    });
    copyBtn.addEventListener('click', async () => {
      const img = await getRamoImage(ramo);
      if (!img?.blob) return;
      await copyBlobToClipboard(img.blob);
      showHint(`Imagem de ${ramo} copiada.`);
    });
    removeBtn.addEventListener('click', async () => {
      sessionRamoFiles.delete(ramoKey(ramo));
      await deleteRamoImage(ramo);
      await refreshRow();
      if (currentItem?.parent_category === ramo) await updateLeadImageInfo(currentItem);
      showHint(`Imagem de ${ramo} removida.`);
    });
    els.imageList.appendChild(row);
    refreshRow().catch(() => {});
  }
}

async function openCurrentProfile() { try { const username = await ensureLeadProfileOpen(); showHint(`Perfil @${username} aberto.`); } catch (err) { showHint(err.message || 'Não consegui abrir o perfil.', true); } }
async function followCurrent() { try { const username = await ensureLeadProfileOpen(); showHint(`Perfil @${username} aberto. Verificando seguir...`); setOperationalStatus(`Executando lote ${selectedBlock || '—'}`, 'Seguir'); const res = await sendToInstagramTab('CRM_INSTAGRAM_FOLLOW_IF_NEEDED', { expectedUsername: username }); showHint(res?.message || 'Ação de seguir executada.', !res?.ok && !String(res?.status||'').includes('already')); return res; } catch (err) { showHint(err.message || 'Erro ao seguir.', true); return { ok:false }; } }
async function openDm() { try { const username = await ensureLeadProfileOpen(); showHint(`Perfil @${username} aberto. Procurando DM...`); const res = await sendToInstagramTab('CRM_INSTAGRAM_OPEN_DM', { expectedUsername: username }); showHint(res?.message || 'Ação de DM executada.', !res?.ok); return res; } catch (err) { showHint(err.message || 'Erro ao abrir DM.', true); return { ok:false }; } }
async function pasteMessage(which, autoSend = null) {
  const field = els[`message${which}`];
  const text = String(field?.value || '');
  if (!text.trim()) { showHint(`Mensagem ${which} vazia.`, true); return { ok:false }; }
  const send = autoSend === null ? config.autoSendText === 'yes' : Boolean(autoSend);
  const res = await sendToInstagramTab('CRM_INSTAGRAM_PASTE_TEXT', { text, send, expectedUsername: currentLeadUsername() });
  showHint(res?.message || `Mensagem ${which} processada.`, !res?.ok);
  return res;
}

async function closeDmAfterSuccessfulLead(username = '') {
  try {
    await sleep(1200);
    const res = await sendToInstagramTab('CRM_INSTAGRAM_CLOSE_DM', { expectedUsername: username });
    if (res?.ok && res?.closed) {
      addLeadStep('✓ Janela da DM fechada');
      return res;
    }
    addLog(res?.message || 'Não foi possível fechar a janela da DM automaticamente.');
    return res || { ok:false };
  } catch (err) {
    addLog(`Falha ao fechar DM: ${err.message || err}`);
    return { ok:false, message: err.message || String(err) };
  }
}

async function runUntilMessage1() {
  if (!currentItem) return showHint('Nenhum lead carregado.', true);
  try {
    const username = await ensureLeadProfileOpen();
    showHint(`Perfil @${username} aberto. Verificando botões do perfil...`); addLeadStep('✓ Perfil aberto'); setOperationalStatus(`Executando lote ${selectedBlock || '—'}`, 'Verificar perfil');
    const actionState = await checkProfileActionOrInvalidate(username);
    if (actionState?.invalidated) return { ok: false, invalidated: true, message: 'Lead invalidado como Outros.' };
    if (actionState?.error) return { ok:false, message: actionState.reason || 'Erro de segurança de perfil.' };

    showHint(`Perfil @${username} aberto. Etapa 1/3: seguir.`);
    await reportProgress('following', { username });
  const follow = await followCurrent();
    if (follow?.private) throw new Error('Perfil privado. Não prospectar.');
    if (follow && follow.ok === false && !['already_following'].includes(String(follow.status || ''))) {
      showHint(follow.message || 'Não consegui seguir/verificar follow.', true);
      return follow;
    }
    showHint('Etapa 2/3: abrindo DM...');
    const dm = await openDm();
    if (!dm?.ok) {
      showHint(dm?.message || 'Não consegui abrir DM.', true);
      return dm;
    }
    showHint('Etapa 3/3: colando/enviando Mensagem 1...');
    await assertSafeDmForLead(username);
    const msg = await pasteMessage(1);
    if (!msg?.ok) return msg;
    showHint('Mensagem 1 concluída. Continue com as mensagens configuradas e, se aplicável, a imagem.');
    return { ok: true };
  } catch (err) {
    showHint(err.message || 'Erro no fluxo até Msg1.', true);
    return { ok: false, message: err.message };
  }
}

async function updateCurrentItem(payload, refresh = true) {
  if (!currentItem?.id) throw new Error('Nenhum lead carregado.');
  let targetStatus = String(payload.progress_step || '').trim();
  if (!targetStatus && isSentStatus(payload.status)) targetStatus = 'sent';
  else if (!targetStatus && isErrorStatus(payload.status)) targetStatus = 'error';
  else if (!targetStatus && (isInvalidStatus(payload.status) || payload.invalidated)) targetStatus = 'invalid';
  if (!targetStatus) return { ok: true, item: currentItem, unchanged: true };
  if (!currentItem.claim_token) throw new Error('Item sem token de execução. Recarregue a fila antes de continuar.');

  const result = await crmApi('transition', {
    id: currentItem.id,
    claim_token: currentItem.claim_token,
    step: targetStatus,
    target_status: targetStatus,
    reason: payload.invalid_reason || payload.error_message || payload.reason || '',
    invalid_reason: payload.invalid_reason || payload.reason || payload.error_message || 'Outros',
    metadata: payload.metadata || {}
  });
  currentItem = { ...currentItem, ...(result.item || payload) };
  const index = queueItems.findIndex((item) => String(item.id) === String(currentItem.id));
  if (index >= 0) queueItems[index] = currentItem;
  if (refresh) { renderLead(currentItem); await loadQueue(); }
  return result;
}
async function reportProgress(step, metadata = {}) { return updateCurrentItem({ progress_step: step, metadata }, false); }
async function markSent(refresh = true) { await updateCurrentItem({ status:'sent', update_action:'sent' }, refresh); showHint('Lead enviado e marcado no CRM.'); }
async function markError() { const reason = prompt('Motivo do erro:', 'erro operacional'); if (reason === null) return; try { await updateCurrentItem({ status:'error', update_action:'error', error_message:reason }); showHint('Lead marcado como erro.'); } catch (err) { showHint(`Erro ao marcar erro: ${err.message}`, true); } }

function canonicalResumeStep(value) {
  const step = String(value || '').trim().toLowerCase();
  if (['profile_opened','opening_profile'].includes(step)) return 'profile_opened';
  if (['dm_opened','opening_dm'].includes(step)) return 'dm_opened';
  if (['messages_sending','media_sending','sending'].includes(step)) return 'sending';
  if (['sent','completed'].includes(step)) return 'completed';
  return step || 'claimed';
}

function resumeStepRank(value) {
  return ['claimed','profile_opened','following','followed','dm_opened','sending','completed']
    .indexOf(canonicalResumeStep(value));
}

async function markInvalidOther(refresh = true, reason = 'Outros') {
  await updateCurrentItem({ status:'invalidated', update_action:'invalidated', invalidated:true, invalid_reason:reason || 'Outros', invalid_source:'instagram_extension' }, refresh);
  if (currentItem) {
    currentItem.status = 'invalidated';
    currentItem.error_message = reason || 'Outros';
  }
  showHint(`Lead invalidado como ${reason || 'Outros'}.`);
}

async function checkProfileActionOrInvalidate(expectedUsername = '') {
  const state = await sendToInstagramTab('CRM_INSTAGRAM_PROFILE_ACTION_STATE', { expectedUsername });
  if (state?.notFound || state?.invalidInstagram) {
    await markInvalidOther(false, 'Outros');
    return { ok:false, invalidated:true, reason:'Outros', state };
  }
  if (state?.profile && expectedUsername && normalizeInstagramUsername(state.profile) !== normalizeInstagramUsername(expectedUsername)) {
    await updateCurrentItem({ status:'error', update_action:'error', error_message:'Perfil aberto é diferente do lead esperado.' }, false);
    return { ok:false, error:true, reason:'Perfil aberto é diferente do lead esperado.', state };
  }
  if (state?.private || state?.ownProfile || state?.noFollowAndNoMessage) {
    await markInvalidOther(false, 'Outros');
    return { ok:false, invalidated:true, reason:'Outros', state };
  }
  return { ok:true, state };
}

async function assertSafeDmForLead(username) {
  const safe = await sendToInstagramTab('CRM_INSTAGRAM_SAFE_TO_SEND', { expectedUsername: username });
  if (!safe?.ok) {
    const err = new Error(safe?.message || 'DM insegura. Parei para evitar envio no lead errado.');
    err.invalidated = Boolean(safe?.invalidated || safe?.blocked);
    err.safeState = safe;
    throw err;
  }
  return safe;
}

async function waitStep(seconds, label) {
  const total = Math.max(0, Number(seconds || 0));
  for (let left = total; left > 0 && isRunning; left--) {
    while (isPaused && isRunning) await sleep(1000);
    setOperationalStatus(isPaused ? 'Pausado' : (isRunning ? `Executando lote ${selectedBlock || '—'}` : 'Parado'), label, `${left}s`); showHint(`${label} em ${left}s...`);
    await sleep(1000);
  }
}

async function processLead(item) {
  if (hasInvalidInstagramRecipient(item)) {
    recordSkippedInvalidRecipients([item]);
    return { status:'invalid_instagram_recipient_contract', delayAfter:false, messageSent:false, skippedInvalidRecipient:true };
  }
  if (isQueuedStatus(item?.status)) {
    const claimed = await crmApi('claim_item', { id: item.id });
    if (!claimed?.item) throw new Error('Este item já foi assumido por outro navegador ou não está mais disponível.');
    item = { ...item, ...claimed.item };
    const claimedIndex = queueItems.findIndex((row) => String(row.id) === String(item.id));
    if (claimedIndex >= 0) queueItems[claimedIndex] = item;
  }
  currentItem = item; renderLead(item); renderQueue();
  const label = item.company_name || '@' + normalizeInstagramUsername(item.instagram_username);
  showHint(`Processando ${label}...`); setOperationalStatus(`Executando lote ${selectedBlock || '—'}`, 'Abrir perfil'); setLeadSteps([]); addLeadStep('⏳ Processando lead');

  const resumeStep = canonicalResumeStep(item.resume_step || item.status);
  const resumeRank = Math.max(0, resumeStepRank(resumeStep));
  if (resumeStep === 'sending' || resumeStep === 'completed') {
    throw new Error('Checkpoint de envio não pode ser reclamado automaticamente; use a reconciliação para evitar reenvio.');
  }
  if (resumeRank > 0) addLeadStep(`↻ Retomando do checkpoint ${resumeStep}`);

  const username = await ensureLeadProfileOpen();
  if (resumeRank < resumeStepRank('profile_opened')) await reportProgress('profile_opened', { username });
  showHint(`Perfil @${username} aberto. Verificando botões do perfil...`); addLeadStep('✓ Perfil aberto'); setOperationalStatus(`Executando lote ${selectedBlock || '—'}`, 'Verificar perfil');
  const actionState = await checkProfileActionOrInvalidate(username);
  if (actionState?.invalidated) {
    item.status = 'invalidated';
    item.error_message = 'Outros';
    showHint(`Lead @${username} invalidado como Outros. Indo para o próximo.`); addLeadStep('✗ Lead invalidado como Outros'); sessionStats.invalid++; renderSessionStats();
    return { status: 'invalidated', delayAfter: false, messageSent: false };
  }
  if (actionState?.error) {
    item.status = 'error';
    item.error_message = actionState.reason || 'Erro de segurança de perfil';
    showHint(item.error_message, true); addLeadStep('✗ Erro de segurança'); sessionStats.error++; renderSessionStats();
    return { status: 'error', delayAfter: false, messageSent: false };
  }

  showHint(`Perfil @${username} aberto. Verificando seguir...`); setOperationalStatus(`Executando lote ${selectedBlock || '—'}`, 'Seguir');

  if (resumeRank < resumeStepRank('followed')) {
    if (resumeRank < resumeStepRank('following')) await reportProgress('following', { username });
    const follow = await followCurrent();
    if (follow?.private || follow?.notFound || follow?.status === 'requested') { await markInvalidOther(false, 'Outros'); item.status = 'invalidated'; addLeadStep('✗ Lead invalidado como Outros'); sessionStats.invalid++; renderSessionStats(); return { status: 'invalidated', delayAfter: false, messageSent: false }; }
    if (follow && follow.ok === false && !['already_following','followed','follow_clicked'].includes(String(follow.status || ''))) {
      throw new Error(follow.message || 'Não consegui seguir/verificar follow.');
    }
    await reportProgress('followed', { follow_status: String(follow?.status || '') });
    addLeadStep('✓ Seguir/verificação concluída');
  } else {
    addLeadStep('↷ Seguir já concluído — checkpoint preservado');
  }

  showHint('Abrindo DM do perfil...'); setOperationalStatus(`Executando lote ${selectedBlock || '—'}`, 'Abrir DM');
  const dm = await openDm();
  if (!dm?.ok) throw new Error(dm?.message || 'Não abriu DM.');
  try {
    await assertSafeDmForLead(username);
  } catch (err) {
    if (err?.invalidated) {
      await markInvalidOther(false, 'Outros');
      item.status = 'invalidated';
      addLeadStep('✗ DM bloqueada');
      sessionStats.invalid++; renderSessionStats();
      showHint('DM bloqueada. Lead invalidado como Outros. Indo para o próximo.');
      return { status: 'invalidated', delayAfter: false, messageSent: false };
    }
    throw err;
  }
  if (resumeRank < resumeStepRank('dm_opened')) await reportProgress('dm_opened', { username });
  addLeadStep('✓ DM aberta');
  const messageNumbers = configuredMessageNumbers(item);
  if (!messageNumbers.length || messageNumbers[0] !== 1) throw new Error('Template Instagram sem Mensagem 1 configurada.');
  await reportProgress('messages_sending', { total_messages: messageNumbers.length, configured_messages: messageNumbers });

  const progressMetadata = item.progress_metadata && typeof item.progress_metadata === 'object' ? item.progress_metadata : {};
  const confirmedMessageNumbers = new Set(
    (Array.isArray(progressMetadata.confirmed_message_numbers) ? progressMetadata.confirmed_message_numbers : [])
      .map(Number).filter((number) => messageNumbers.includes(number))
  );

  for (let index = 0; index < messageNumbers.length; index += 1) {
    const number = messageNumbers[index];
    if (confirmedMessageNumbers.has(number)) {
      addLeadStep(`↷ Msg${number} já confirmada — checkpoint preservado`);
      continue;
    }
    await sendToInstagramTab('CRM_INSTAGRAM_RESET_LOCKS', {});
    showHint(`Enviando Mensagem ${number}...`);
    setOperationalStatus(`Executando lote ${selectedBlock || '—'}`, `Enviar Msg${number}`);
    addLeadStep(`⏳ Enviando Msg${number}`);
    await assertSafeDmForLead(username);
    const messageResult = await pasteMessage(number, true);
    if (!messageResult?.ok) throw new Error(messageResult?.message || `Falha ao enviar Mensagem ${number}.`);
    confirmedMessageNumbers.add(number);
    await reportProgress('messages_sending', {
      total_messages: messageNumbers.length,
      configured_messages: messageNumbers,
      confirmed_message_numbers: [...confirmedMessageNumbers].sort((a, b) => a - b),
    });
    addLeadStep(`✓ Msg${number} enviada`);
    const nextNumber = messageNumbers[index + 1];
    if (nextNumber) await waitStep(MESSAGE_STEP_DELAY_SECONDS, `Mensagem ${nextNumber}`);
  }

  if (!itemShouldSendImage(item)) {
    addLeadStep('↷ Imagem não exigida — etapa ignorada');
    await markSent(false);
    item.status = 'sent';
    showHint(`Lead @${username} enviado somente com as mensagens configuradas e marcado no CRM.`);
    addLeadStep('✓ Lead enviado e marcado no CRM');
    sessionStats.sent++; renderSessionStats();
    await closeDmAfterSuccessfulLead(username);
    return { status: 'sent', delayAfter: true, messageSent: true, mediaSkipped: true };
  }

  await waitStep(MESSAGE_STEP_DELAY_SECONDS, 'Imagem');

  await reportProgress('media_sending', { image_name: item.image_name || item.imageName || item.image_url || '' });
  showHint('Enviando imagem do ramo...'); setOperationalStatus(`Executando lote ${selectedBlock || '—'}`, 'Enviar imagem'); addLeadStep('⏳ Enviando imagem');
  let media = null;
  try {
    await assertSafeDmForLead(username);
    media = await sendCurrentRamoImage();
  } catch (err) {
    media = { ok: false, mediaConfirmed: false, message: err?.message || String(err || '') };
  }

  if (!media?.ok || !media?.mediaConfirmed) {
    addLeadStep('✗ Imagem não confirmada');
    if (media?.uncertain === true) {
      const reason = media?.message || 'Não foi possível confirmar o envio da imagem.';
      await updateCurrentItem({
        progress_step:'reconciliation_required',
        error_message:reason,
        metadata:{ confirmed_messages:messageNumbers.length, media_confirmed:false, media_result:'uncertain' }
      }, false);
      item.status = 'reconciliation_required';
      item.error_message = reason;
      sessionStats.error++; renderSessionStats();
      showHint(`${reason} O lead exige reconciliação manual; nenhum fallback foi enviado.`, true);
      return { status:'reconciliation_required', delayAfter:false, messageSent:true, uncertainMedia:true };
    }
    if (media?.doNotFallback || !media?.fallbackAllowed) {
      const reason = media?.message || 'O envio da imagem falhou antes de ser confirmado.';
      await updateCurrentItem({ status:'error', update_action:'error', error_message:reason }, false);
      item.status = 'error';
      item.error_message = reason;
      sessionStats.error++; renderSessionStats();
      showHint(`${reason} O lead foi marcado como erro; nenhum fallback foi enviado.`, true);
      return { status:'error', delayAfter:false, messageSent:true, uncertainMedia:false };
    }
    showHint('A imagem não chegou a ser enviada. Iniciando fallback textual em 2 mensagens.');
    setOperationalStatus(`Executando lote ${selectedBlock || '—'}`, 'Fallback 1');
    await waitStep(MESSAGE_STEP_DELAY_SECONDS, 'Fallback 1');
    await sendToInstagramTab('CRM_INSTAGRAM_RESET_LOCKS', {});
    await assertSafeDmForLead(username);
    const fallbackText1 = 'Pelo que vi, não estou conseguindo enviar a imagem por aqui. Parece que o Instagram recusou o envio.';
    const fallback1 = await sendToInstagramTab('CRM_INSTAGRAM_PASTE_TEXT', { text: fallbackText1, send: true, expectedUsername: username });
    if (!fallback1?.ok) {
      throw new Error(fallback1?.message || media?.message || 'fallback_message_failed');
    }
    addLeadStep('✓ Fallback 1 enviado');
    setOperationalStatus(`Executando lote ${selectedBlock || '—'}`, 'Fallback 2');
    await waitStep(MESSAGE_STEP_DELAY_SECONDS, 'Fallback 2');
    await sendToInstagramTab('CRM_INSTAGRAM_RESET_LOCKS', {});
    await assertSafeDmForLead(username);
    const fallbackText2 = 'Teria algum outro contato da empresa para que eu envie essa amostra?';
    const fallback2 = await sendToInstagramTab('CRM_INSTAGRAM_PASTE_TEXT', { text: fallbackText2, send: true, expectedUsername: username });
    if (!fallback2?.ok) {
      throw new Error(fallback2?.message || 'fallback_message_failed');
    }
    addLeadStep('✓ Fallback 2 enviado');
    await markSent(false);
    item.status = 'sent';
    showHint(`Lead @${username} marcado como enviado com fallback em 2 mensagens.`);
    addLeadStep('✓ Lead enviado e marcado no CRM');
    sessionStats.sent++; renderSessionStats();
    await closeDmAfterSuccessfulLead(username);
    return { status: 'sent', delayAfter: true, messageSent: true, usedFallback: true };
  }

  addLeadStep('✓ Imagem enviada');
  await markSent(false);
  item.status = 'sent';
  showHint(`Lead @${username} enviado e marcado no CRM.`); addLeadStep('✓ Lead enviado e marcado no CRM'); sessionStats.sent++; renderSessionStats();
  await closeDmAfterSuccessfulLead(username);
  return { status: 'sent', delayAfter: true, messageSent: true, mediaConfirmed: true };
}



async function getMissingImagesForItems(items) {
  const missing = [];
  const checked = new Set();
  for (const item of items || []) {
    if (!itemShouldSendImage(item)) continue;
    const ramo = item?.parent_category || 'Ramo não informado';
    const key = `${ramo}|${item?.image_name || item?.image_url || ''}|${item?.image_sha256 || ''}`;
    if (checked.has(key)) continue;
    checked.add(key);
    try {
      const img = await getRamoImage(ramo);
      await validateFrozenImage(item, img);
    } catch (error) {
      missing.push(`${ramo}: ${error?.message || 'imagem incompatível'}`);
    }
  }
  return missing;
}

function templateSequenceIssue(item) {
  const values = [1, 2, 3, 4].map((number) => String(item?.[`message_${number}`] ?? item?.[`message${number}`] ?? '').trim());
  if (!values[0]) return 'Mensagem 1 não configurada.';
  let foundGap = false;
  for (let index = 1; index < values.length; index += 1) {
    if (!values[index]) foundGap = true;
    else if (foundGap) return `Mensagem ${index + 1} configurada sem a mensagem anterior.`;
  }
  return '';
}

function assertBatchTemplatesReady(items) {
  const invalid = (items || []).find((item) => templateSequenceIssue(item));
  if (!invalid) return true;
  const company = invalid.company_name || invalid.instagram_username || invalid.id || 'lead';
  const message = `Não é possível iniciar o lote. ${company}: ${templateSequenceIssue(invalid)}`;
  showHint(message, true);
  throw new Error(message);
}

async function assertBatchImagesReady(items) {
  const missing = await getMissingImagesForItems(items);
  if (missing.length) {
    switchTab('imagens');
    await renderImages();
    const msg = `Não é possível iniciar o lote. Falta imagem para: ${missing.join(', ')}.`;
    showHint(msg, true);
    throw new Error(msg);
  }
  return true;
}

async function startSelectedBatch() {
  if (!selectedBlock) return showHint('Selecione um lote antes de iniciar.', true);
  if (isRunning) return;
  const queuedItems = queuedItemsForSelectedBlock();
  const invalidItems = queuedItems.filter(hasInvalidInstagramRecipient);
  recordSkippedInvalidRecipients(invalidItems);
  let items = queuedItems.filter(item => !hasInvalidInstagramRecipient(item));
  if (!items.length) {
    if (invalidItems.length) return showHint(invalidRecipientIterationMessage(invalidItems.length), true);
    return showHint(`Lote ${selectedBlock} não possui leads em fila.`, true);
  }
  try {
    await assertLoggedProfileMatchesConfig();
    assertBatchTemplatesReady(items);
    // Pré-check de mídia: só bloqueia itens cuja fila realmente exige/congela imagem.
    await assertBatchImagesReady(items);
  } catch (err) {
    return;
  }
  isRunning = true; isPaused = false; startRuntimeTimer(); setOperationalStatus(`Executando lote ${selectedBlock || '—'}`, 'Iniciar'); addLog(`Lote ${selectedBlock} iniciado`); els.startBatch.disabled = true; els.pauseRun.disabled = false; els.stopRun.disabled = false;
  const processedKeys = new Set();
  try {
    while (isRunning) {
      while (isPaused && isRunning) { showHint('Pausado. Clique em retomar para continuar.'); await sleep(1000); }
      if (!isRunning) break;

      // Se a autoatualização encontrou oportunidade durante o lead anterior, atualiza agora,
      // sem mexer no lead que estava em execução.
      if (pendingAutoRefreshAfterLead) await silentRefreshQueue('auto');

      recordSkippedInvalidRecipients(invalidQueuedItemsForSelectedBlock());
      let pendingItems = validQueuedItemsForSelectedBlock().filter(i => !processedKeys.has(itemKey(i)));
      if (!pendingItems.length) {
        // Última checagem leve antes de concluir o lote. Assim, se o CRM completou um lote
        // enquanto a extensão estava aberta, ele entra sem precisar clicar em Carregar fila.
        await silentRefreshQueue('auto');
        recordSkippedInvalidRecipients(invalidQueuedItemsForSelectedBlock());
        pendingItems = validQueuedItemsForSelectedBlock().filter(i => !processedKeys.has(itemKey(i)));
        if (!pendingItems.length) break;
      }

      const item = pendingItems[0];
      processedKeys.add(itemKey(item));
      const outcome = await processLead(item);

      if (pendingAutoRefreshAfterLead) await silentRefreshQueue('auto');
      const hasMoreAfter = validQueuedItemsForSelectedBlock().some(i => !processedKeys.has(itemKey(i)));

      // v44/v50: intervalo entre leads só faz sentido quando houve envio real.
      // Lead inválido, não encontrado, perfil sem botão ou erro antes de mensagem
      // deve seguir para o próximo imediatamente.
      if (hasMoreAfter && outcome?.delayAfter === true) {
        const delay = Math.max(0, Number(config.leadDelaySeconds || 0));
        if (delay) {
          for (let left=delay; left>0 && isRunning; left--) {
            while (isPaused && isRunning) await sleep(1000);
            showHint(`Aguardando ${left}s para o próximo lead do lote ${selectedBlock}...`);
            setOperationalStatus(`Executando lote ${selectedBlock || '—'}`, 'Próximo lead', `${left}s`);
            await sleep(1000);
          }
        }
      } else if (hasMoreAfter) {
        setOperationalStatus(`Executando lote ${selectedBlock || '—'}`, 'Próximo lead'); showHint('Lead sem envio real. Indo para o próximo sem aguardar 2 minutos.');
        await sleep(1200);
      }
    }
    const invalidRemaining = isRunning ? invalidQueuedItemsForSelectedBlock() : [];
    recordSkippedInvalidRecipients(invalidRemaining);
    await loadQueue();
    if (isRunning) showHint(invalidRemaining.length
      ? `Iteração do lote ${selectedBlock} concluída com ${invalidRemaining.length} destinatário(s) inválido(s) sem claim.`
      : `Lote ${selectedBlock} concluído. Aguarde o intervalo configurado na plataforma antes do próximo lote.`,
    invalidRemaining.length > 0);
  } catch (err) { sessionStats.error++; renderSessionStats(); addLeadStep('✗ Erro operacional'); showHint(`Execução pausada por erro: ${err.message}`, true); }
  finally { isRunning = false; isPaused = false; setOperationalStatus('Parado', '—', '—'); stopRuntimeTimerIfIdle(); els.pauseRun.textContent = 'Pausar'; els.pauseRun.disabled = true; els.stopRun.disabled = true; els.startBatch.disabled = !selectedBlock; }
}

function togglePause() { if (!isRunning) return; isPaused = !isPaused; els.pauseRun.textContent = isPaused ? 'Retomar' : 'Pausar'; setOperationalStatus(isPaused ? 'Pausado' : `Executando lote ${selectedBlock || '—'}`); addLog(isPaused ? 'Execução pausada' : 'Execução retomada'); showHint(isPaused ? 'Execução pausada.' : 'Execução retomada.'); }
function stopRun() { isRunning = false; isPaused = false; setOperationalStatus('Parado', '—', '—'); addLog('Execução parada'); stopRuntimeTimerIfIdle(); showHint('Execução parada.'); }

document.querySelectorAll('.tab-btn').forEach(btn => btn.addEventListener('click', () => switchTab(btn.dataset.tab)));
els.refresh.addEventListener('click', checkSession);
els.saveConfig.addEventListener('click', saveConfig);
els.connectPlatform?.addEventListener('click',()=>{void connectPlatform().catch(error=>showConfigHint(error.message||String(error),true));});
els.disconnectPlatform?.addEventListener('click',()=>{void disconnectPlatform().catch(error=>showHint(error.message||String(error),true));});
els.organizationSelect?.addEventListener('change',()=>{ els.organizationSelect.value=String(config.organizationId||''); showHint('Para trocar de organização, desconecte e conecte novamente. O perfil Instagram é vinculado à instalação e à organização autorizada.'); });
els.loadQueue.addEventListener('click', loadQueue);
if (els.loadQueue2) els.loadQueue2.addEventListener('click', loadQueue);
els.fetchNext.addEventListener('click', fetchNextLead);
if (els.fetchNext2) els.fetchNext2.addEventListener('click', fetchNextLead);
els.openProfile.addEventListener('click', openCurrentProfile);
els.followBtn.addEventListener('click', followCurrent);
els.dmBtn.addEventListener('click', openDm);
els.pasteMsg1.addEventListener('click', () => pasteMessage(1));
if (els.runToMsg1) els.runToMsg1.addEventListener('click', runUntilMessage1);
els.pasteMsg2.addEventListener('click', () => pasteMessage(2));
els.pasteMsg3.addEventListener('click', () => pasteMessage(3));
els.pasteMsg4.addEventListener('click', () => pasteMessage(4));
if (els.copyImage) els.copyImage.addEventListener('click', copyCurrentRamoImage);
els.markSent.addEventListener('click', () => markSent(true));
els.errorBtn.addEventListener('click', markError);
if (els.invalidBtn) els.invalidBtn.addEventListener('click', () => markInvalidOther(true, 'Outros'));
if (els.sendImageBtn) els.sendImageBtn.addEventListener('click', sendCurrentRamoImage);
els.startBatch.addEventListener('click', startSelectedBatch);
els.pauseRun.addEventListener('click', togglePause);
els.stopRun.addEventListener('click', stopRun);
els.manualOpen.addEventListener('click', async () => { const username = normalizeInstagramUsername(els.manualUsername.value); if (!username) return showHint('invalid_instagram_recipient_contract', true); await openOrFocusInstagram(username); });
if (els.refreshImages) els.refreshImages.addEventListener('click', renderImages);

document.addEventListener('DOMContentLoaded', async () => { await loadConfig(); setOperationalStatus('Parado', '—', '—'); renderSessionStats(); await checkSession(); await renderImages(); startQueueAutoRefresh(); });
