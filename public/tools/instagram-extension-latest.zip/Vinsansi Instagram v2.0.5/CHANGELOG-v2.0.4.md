# Vinsansi Instagram v2.0.4

- Corrige recuperação da aba do Instagram após reload da extensão.
- A extensão agora procura automaticamente uma aba existente do Instagram quando o painel lateral não está sobre a aba do Instagram.
- Mantém reinjeção automática do content script para comandos de leitura.
- Adiciona feedback de sessão e pairing diretamente na aba Configurações.
- O botão Conectar deixa de falhar silenciosamente quando a sessão não é detectada.
- Preserva as regras da v2.0.3: imagem opcional conforme item da fila e templates com 1 a 4 mensagens em sequência.
