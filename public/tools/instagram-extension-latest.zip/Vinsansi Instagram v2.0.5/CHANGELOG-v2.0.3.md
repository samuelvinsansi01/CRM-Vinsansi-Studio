# Vinsansi Instagram v2.0.3

- Imagem passa a respeitar o contrato congelado da fila: é obrigatória apenas quando `imageRequired` ou mídia congelada indicar isso.
- Lotes sem imagem exigida seguem somente com as mensagens configuradas e são finalizados normalmente.
- Pré-check de imagens ignora itens sem mídia obrigatória.
- Corrige validação residual no início do lote para aceitar 1 a 4 mensagens em sequência, com Mensagem 1 obrigatória.
- A interface informa quando a imagem é opcional e quando a etapa será ignorada.
