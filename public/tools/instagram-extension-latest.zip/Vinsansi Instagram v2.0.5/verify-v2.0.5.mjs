import assert from 'node:assert/strict';
import fs from 'node:fs';

const root = new URL('.', import.meta.url);
const manifest = JSON.parse(fs.readFileSync(new URL('manifest.json', root), 'utf8'));
const popup = fs.readFileSync(new URL('popup.js', root), 'utf8');

assert.equal(manifest.version, '2.0.5');
assert.ok(popup.includes('function canonicalResumeStep'));
assert.ok(popup.includes('function resumeStepRank'));
assert.ok(popup.includes("if (resumeRank < resumeStepRank('followed'))"));
assert.ok(popup.includes('Seguir já concluído — checkpoint preservado'));
assert.ok(popup.includes('confirmed_message_numbers'));
assert.ok(popup.includes("resumeStep === 'sending' || resumeStep === 'completed'"));
assert.ok(popup.includes("await reportProgress('messages_sending'"));
assert.ok(!popup.includes('outside_operational_window'));

console.log('Vinsansi Instagram 2.0.5: recovery/checkpoints idempotentes OK');

