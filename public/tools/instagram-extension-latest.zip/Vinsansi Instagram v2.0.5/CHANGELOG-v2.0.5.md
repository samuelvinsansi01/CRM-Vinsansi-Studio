# Vinsansi Instagram v2.0.5

## Correções da Etapa 11

- preserva `resume_step` e metadata de checkpoint após recovery;
- não repete o follow quando o checkpoint `followed` já foi persistido;
- persiste `confirmed_message_numbers` após cada mensagem confirmada;
- bloqueia retomada automática a partir de `sending`, exigindo reconciliação para evitar reenvio cego;
- mantém o envio final idempotente no CRM/Supabase.

