# Vinsansi Instagram v2.0.1

## Etapa 9 — mensagens opcionais no Instagram
- Mensagem 1 continua obrigatória;
- Mensagens 2, 3 e 4 passam a ser opcionais no Instagram;
- mensagens opcionais precisam respeitar sequência contínua (não é permitido preencher Msg3 sem Msg2, nem Msg4 sem Msg2/Msg3);
- executor automático envia somente as mensagens realmente configuradas;
- progresso da execução passa a informar a quantidade real de mensagens do template;
- botões de envio manual de mensagens não configuradas ficam desabilitados;
- textos da interface deixam explícito quais mensagens são opcionais.

O contrato WhatsApp não foi alterado e continua exigindo quatro mensagens.
