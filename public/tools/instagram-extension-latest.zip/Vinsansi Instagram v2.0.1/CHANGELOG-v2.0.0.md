# Vinsansi Instagram v2.0.0

## Etapa 9 — executor oficial
- pairing genérico via `/api/tools/browser-pair`;
- remoção do token manual;
- instalação persistente e contexto organizacional;
- perfil Instagram detectado no navegador e vinculado durante a autorização;
- ações bloqueadas se o perfil logado divergir do perfil vinculado;
- heartbeat oficial com catálogo completo de capacidades;
- fila/claim/transições continuam usando o backend canônico da Etapa 9;
- versão exibida pela própria extensão.
