(() => {
  const SESSION_KEY = 'vinsansiInstagramPlatformSessionV2';
  const INSTALLATION_KEY = 'vinsansiInstagramInstallationIdV2';
  const PLATFORM_BASE_URL = 'https://painel.samuelvinsansi.com.br';
  const BROWSER_PAIR_URL = `${PLATFORM_BASE_URL}/api/tools/browser-pair`;
  const REQUEST_TIMEOUT_MS = 20000;
  const CAPABILITIES = [
    'settings.read','presence.heartbeat','activity.report','organization.context','member.context',
    'instagram.queue.execute','instagram.dm.send','instagram.media.send','instagram.result.report',
    'instagram.checkpoint','instagram.profile.bound'
  ];
  const text = (value) => String(value ?? '').trim();
  const sleep = (ms) => new Promise(resolve => setTimeout(resolve, ms));

  function apiError(code, message, status = 0) {
    const error = new Error(message || code);
    error.code = code;
    error.status = status;
    return error;
  }

  async function installationId() {
    const stored = await chrome.storage.local.get(INSTALLATION_KEY);
    if (text(stored[INSTALLATION_KEY]).length >= 16) return text(stored[INSTALLATION_KEY]);
    const id = `instagram-${crypto.randomUUID()}`;
    await chrome.storage.local.set({ [INSTALLATION_KEY]: id });
    return id;
  }

  async function session() {
    const stored = await chrome.storage.local.get(SESSION_KEY);
    const value = stored[SESSION_KEY];
    return value?.userSession && value?.installationCredential ? value : null;
  }
  async function storeSession(value) { await chrome.storage.local.set({ [SESSION_KEY]: value }); return value; }
  async function clearSession() { await chrome.storage.local.remove(SESSION_KEY); }

  async function fetchJson(url, options = {}, allow202 = false) {
    const controller = new AbortController();
    const timeout = setTimeout(() => controller.abort(), REQUEST_TIMEOUT_MS);
    try {
      const response = await fetch(url, { ...options, signal: controller.signal });
      const data = await response.json().catch(() => ({}));
      if (!response.ok && !(allow202 && response.status === 202)) {
        throw apiError(text(data.error) || 'platform_error', text(data.message || data.error) || `HTTP ${response.status}`, response.status);
      }
      return data;
    } catch (error) {
      if (error?.name === 'AbortError') throw apiError('platform_request_timeout','A plataforma não respondeu dentro do tempo esperado.');
      throw error;
    } finally { clearTimeout(timeout); }
  }

  async function browserPair(payload) {
    return fetchJson(BROWSER_PAIR_URL, {
      method:'POST', headers:{'Content-Type':'application/json'}, body:JSON.stringify(payload), cache:'no-store', credentials:'omit'
    }, true);
  }

  async function controlRequest(path, { method='GET', userSession='', installationCredential='', organizationId='', body } = {}) {
    return fetchJson(`${PLATFORM_BASE_URL}/api/tools/executor/${path}`, {
      method,
      headers:{
        'Content-Type':'application/json',
        ...(userSession ? { Authorization:`Bearer ${userSession}` } : {}),
        ...(installationCredential ? { 'X-Vinsansi-Installation-Credential':installationCredential } : {}),
        ...(organizationId ? { 'X-Vinsansi-Organization-Id':String(organizationId) } : {})
      },
      ...(body === undefined ? {} : { body:JSON.stringify(body) }),
      cache:'no-store', credentials:'omit'
    });
  }

  async function refreshContext(current = null) {
    current = current || await session();
    if (!current?.userSession) return null;
    const context = await controlRequest('context', { userSession:current.userSession, organizationId:current.organizationId });
    const effective = await controlRequest('config', { userSession:current.userSession, organizationId:context.organizationId });
    return storeSession({ ...current, organizationId:context.organizationId, memberId:context.memberId, context, effectiveConfig:effective.config });
  }

  async function beginPairing(instagramProfile) {
    const profile = text(instagramProfile).replace(/^@/,'').toLowerCase();
    if (!profile) throw apiError('instagram_profile_required','Entre no Instagram antes de conectar a extensão.');
    const id = await installationId();
    const pairing = await browserPair({
      action:'initiate', toolId:'vinsansi_instagram', externalInstallationId:id,
      version:chrome.runtime.getManifest().version, capabilities:CAPABILITIES,
      metadata:{ executor:'chrome_extension', source:'instagram', instagramProfile:profile }
    });
    if (!text(pairing.pairingId) || !text(pairing.pairingSecret) || !/^https:\/\//i.test(text(pairing.authorizationUrl))) {
      throw apiError('invalid_api_response','A plataforma retornou um vínculo incompleto.');
    }
    await chrome.tabs.create({ url:pairing.authorizationUrl, active:true });
    return { ...pairing, installationId:id, instagramProfile:profile };
  }

  async function exchangePairing(pairing, { attempts=120, intervalMs=2000 } = {}) {
    for (let i=0;i<attempts;i+=1) {
      const result = await browserPair({ action:'exchange', pairingId:pairing.pairingId, pairingSecret:pairing.pairingSecret, externalInstallationId:pairing.installationId });
      if (!result.pending && result.userSession && result.installationCredential) {
        return refreshContext(await storeSession({ ...result, instagramProfile:pairing.instagramProfile, installationId:pairing.installationId }));
      }
      await sleep(intervalMs);
    }
    throw apiError('pairing_timeout','A autorização não foi concluída dentro do prazo.');
  }

  async function heartbeat(current = null, meaningfulActivity = false) {
    current = current || await session();
    if (!current?.installationCredential) return null;
    return controlRequest('heartbeat', { method:'POST', installationCredential:current.installationCredential, body:{
      version:chrome.runtime.getManifest().version, capabilities:CAPABILITIES, meaningfulActivity:Boolean(meaningfulActivity),
      status:'online', metrics:{ profile:current.instagramProfile || '' }
    }});
  }

  async function disconnect() {
    const current = await session();
    if (current?.userSession) {
      await controlRequest('logout', { method:'POST', userSession:current.userSession, organizationId:current.organizationId }).catch(() => {});
    }
    await clearSession();
  }

  globalThis.INSTAGRAM_PLATFORM_API = { PLATFORM_BASE_URL, CAPABILITIES, session, storeSession, clearSession, installationId, beginPairing, exchangePairing, refreshContext, heartbeat, disconnect, controlRequest };
  setInterval(() => { void heartbeat().catch(() => {}); }, 60_000);
})();
